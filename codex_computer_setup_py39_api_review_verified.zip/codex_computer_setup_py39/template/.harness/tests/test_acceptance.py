"""Common acceptance and immutable-test regressions; no models or application-specific code."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from boundary_fixture import ready as ready_boundary, answered as answered_boundary

SOURCE = Path(__file__).resolve().parents[2]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


verification = load("acceptance_verification", SOURCE / ".harness/verification.py")
loop = load("acceptance_loop", SOURCE / "automation/codex-loop/run.py")
acceptance = verification.acceptance


class AcceptanceTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix="common acceptance ")
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.project = self.root / "project"
        (self.project / ".harness").mkdir(parents=True)
        (self.project / "tests").mkdir()
        for name in ("acceptance.py", "check_unittest.py"):
            shutil.copy2(SOURCE / ".harness" / name, self.project / ".harness" / name)
        subprocess.run(["git", "-c", "init.templateDir=", "init", "-q", str(self.project)], check=True, capture_output=True)
        self.write("SPEC.md", "Run the required acceptance test.\n")
        self.write("tests/test_required.py", "import unittest\nclass Required(unittest.TestCase):\n def test_one(self):\n  self.assertEqual(2+3,5)\n")
        self.argv = ["{python}", "-B", ".harness/check_unittest.py"]
        self.contract = {"version": 1, "checker_argv": self.argv,
                         "required_ids_manifest": "required_ids.json", "protected_paths": ["tests"]}
        self.required = "test_required.Required.test_one"
        self.json("required_ids.json", {"version": 1, "required_test_ids": [self.required]})
        self.json(".harness/acceptance.json", self.contract)
        self.json(".harness/checks.json", {"checks": [{"name": "acceptance", "command": self.argv}]})
        self.task = {"id": "T1", "goal": "Check required behavior",
                     "requirements": [{"id": "R1", "text": "Required behavior passes", "check_ids": ["acceptance"]}],
                     "checks": [{"id": "acceptance", "argv": self.argv, "success_regex": acceptance.SUCCESS_REGEX}]}
        self.json("tasks.json", [self.task])
        self.config = {"project": ".", "spec": "SPEC.md", "tasks_file": "tasks.json",
                       "builder_model": "unused-builder", "reviewer_model": "unused-reviewer", "run_root": "../runs"}
        self.json("config.json", self.config)
        ready_boundary(self.project)
        self.output = io.StringIO()
        stack = contextlib.ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(contextlib.redirect_stdout(self.output))
        stack.enter_context(contextlib.redirect_stderr(self.output))

    def write(self, name, text):
        path = self.project / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path

    def json(self, name, value):
        return self.write(name, json.dumps(value))

    def settings(self):
        return loop.load_settings(self.project / "config.json")

    def both(self, expected):
        self.assertEqual(verification.verify(self.project), 0 if expected else 1, self.output.getvalue())
        self.assertEqual(verification.status(self.project), 0 if expected else 1, self.output.getvalue())
        c = self.settings()
        worker = loop.Runner(c)
        worker.current_hash = loop.snapshot(self.project, c["exclude_dirs"] + [".harness/work"])
        c["exclude_dirs"].append(".harness/work")
        results = worker.run_checks(c["tasks"][0], worker.directory)
        self.assertEqual(results[0]["passed"], expected, results)

    def test_normal_required_and_additional_tests_pass_both_controllers(self):
        self.write("tests/test_extra.py", "import unittest\nclass Extra(unittest.TestCase):\n def test_extra(self): self.assertTrue(True)\n")
        self.both(True)

    def test_boundary_not_ready_blocks_both_controllers_before_checks(self):
        (self.project / ".harness/boundary.json").unlink()
        with mock.patch.object(verification, "run_check", side_effect=AssertionError("must not execute")):
            self.assertEqual(verification.verify(self.project), 1)
        with self.assertRaisesRegex(loop.StopRun, "boundary"):
            self.settings()

    def test_actual_answers_require_explicit_required_test_mapping(self):
        answered_boundary(self.project)
        self.assertEqual(verification.verify(self.project), 1)
        with self.assertRaisesRegex(loop.StopRun, "boundary_tests"):
            self.settings()
        for mapping in ({"Q-001": []}, {"Q-001": ["unknown.test"]},
                        {"Q-001": [self.required, self.required]},
                        {"Q-002": [self.required]}, {"Q-001": [self.required], "Q-002": [self.required]}):
            with self.subTest(mapping=mapping):
                self.json(".harness/acceptance.json", dict(self.contract, boundary_tests=mapping))
                self.assertEqual(verification.verify(self.project), 1)
                with self.assertRaises(loop.StopRun):
                    self.settings()
        self.json(".harness/acceptance.json", dict(self.contract, boundary_tests={"Q-001": [self.required]}))
        self.both(True)

    def test_boundary_documents_are_protected_even_in_excluded_directories(self):
        self.write("reference/rules.md", "Preserve the user's negative input decision.\n")
        ready = answered_boundary(self.project, references=["reference/rules.md"])
        self.json(".harness/acceptance.json", dict(self.contract, boundary_tests={"Q-001": [self.required]}))
        self.config["exclude_dirs"] = loop.DEFAULT_EXCLUDES + ["reference"]
        self.json("config.json", self.config)
        c = self.settings()
        self.assertIn("Reject a negative input", c["boundary"]["context"])
        for path in ready["protected_files"]:
            with self.subTest(path=path):
                self.assertIn(str(path), c["protected"])
                original = path.read_bytes()
                path.write_bytes(original + b"\nchanged")
                with self.assertRaisesRegex(loop.StopRun, "Protected file changed"):
                    loop.verify_protected(c)
                path.write_bytes(original)

    def test_zero_all_skipped_missing_required_and_extra_skip_fail_both(self):
        cases = ["", "import unittest\n@unittest.skip('not exercised')\nclass Required(unittest.TestCase):\n def test_one(self): pass\n",
                 "import unittest\nclass Required(unittest.TestCase):\n def test_other(self): self.assertTrue(True)\n",
                 "import unittest\nclass Required(unittest.TestCase):\n def test_one(self): self.assertTrue(True)\n @unittest.skip('extra')\n def test_extra(self): pass\n"]
        for body in cases:
            with self.subTest(body=body):
                self.write("tests/test_required.py", body)
                self.both(False)

    def test_empty_registration_is_still_rejected(self):
        self.json(".harness/checks.json", {"checks": []})
        self.assertEqual(verification.verify(self.project), 1)
        self.json("tasks.json", [])
        with self.assertRaises(loop.StopRun):
            self.settings()

    def test_contract_absence_blank_missing_path_and_command_mismatch_stop_preflight(self):
        cases = [None, {"version": 1, "checker_argv": [], "required_ids_manifest": "", "protected_paths": []},
                 dict(self.contract, protected_paths=["missing-tests"])]
        for value in cases:
            with self.subTest(value=value):
                if value is None:
                    (self.project / ".harness/acceptance.json").unlink()
                else:
                    self.json(".harness/acceptance.json", value)
                self.assertEqual(verification.verify(self.project), 1)
                with self.assertRaises(loop.StopRun):
                    self.settings()
                self.json(".harness/acceptance.json", self.contract)
        bad = ["{python}", "-B", ".harness/check_unittest.py", "--pattern", "other*.py"]
        self.json(".harness/checks.json", {"checks": [{"name": "acceptance", "command": bad}]})
        self.assertEqual(verification.verify(self.project), 1)
        self.task["checks"][0]["argv"] = bad
        self.json("tasks.json", [self.task])
        with self.assertRaisesRegex(loop.StopRun, "differs"):
            self.settings()

    def test_tests_checker_manifest_and_contract_are_automatically_protected(self):
        for name in ("tests/test_required.py", ".harness/check_unittest.py", "required_ids.json", ".harness/acceptance.json"):
            target = self.project / name
            original = target.read_bytes()
            c = self.settings()
            self.assertIn(str(target), c["protected"])
            for deletion in (False, True):
                with self.subTest(name=name, deletion=deletion):
                    if deletion:
                        target.unlink()
                    else:
                        target.write_bytes(original + b"\n ")
                    with self.assertRaisesRegex(loop.StopRun, "Protected file changed"):
                        loop.verify_protected(c)
                    target.write_bytes(original)

    def test_unregistered_unit_command_cannot_replace_the_common_checker(self):
        self.json(".harness/checks.json", {"checks": [{"name": "unit", "command": ["{python}", "-B", "-m", "unittest", "discover", "-s", "tests"]}]})
        self.write("tests/test_required.py", "")
        self.assertEqual(verification.verify(self.project), 1)
        receipt = verification.read_json(sorted((self.project / ".harness/work").glob("verify-*/receipt.json"))[-1])
        self.assertEqual(receipt["results"][0]["exit_code"], 0)
        self.assertFalse(receipt["passed"])

    def test_zero_exit_forged_or_missing_ids_and_duplicates_are_rejected(self):
        reports = [
            {"schema": acceptance.SCHEMA, "status": "passed", "test_results": []},
            {"schema": acceptance.SCHEMA, "status": "passed", "test_results": [{"id": "substitute", "status": "passed"}]},
            {"schema": acceptance.SCHEMA, "status": "passed", "test_results": [{"id": self.required, "status": "passed"}] * 2},
        ]
        self.contract["checker_argv"] = ["{python}", "-B", "checker.py"]
        self.json(".harness/acceptance.json", self.contract)
        self.json(".harness/checks.json", {"checks": [{"name": "acceptance", "command": self.contract["checker_argv"]}]})
        self.task["checks"][0]["argv"] = self.contract["checker_argv"]
        self.json("tasks.json", [self.task])
        for report in reports:
            self.write("checker.py", "import json\nprint(json.dumps(" + repr(report) + "))\n")
            self.both(False)

    def test_discovery_prints_go_to_stderr_and_do_not_corrupt_receipt(self):
        path = self.project / "tests/test_required.py"
        path.write_text("print('import diagnostic')\n" + path.read_text(encoding="utf-8"), encoding="utf-8")
        self.both(True)

    def test_manifest_cannot_use_empty_or_duplicate_required_ids(self):
        for ids in ([], [self.required, self.required]):
            self.json("required_ids.json", {"version": 1, "required_test_ids": ids})
            with self.assertRaises(loop.StopRun):
                self.settings()

    def test_acceptance_inputs_cannot_live_in_ignored_runtime_directories(self):
        for name in ("work/checker.py", ".harness/work/checker.py", ".git/checker.py"):
            with self.subTest(name=name):
                self.write(name, "print('should never run')\n")
                contract = dict(self.contract, checker_argv=["{python}", "-B", name])
                self.json(".harness/acceptance.json", contract)
                with self.assertRaises(ValueError):
                    acceptance.load_contract(self.project)

    def test_mixed_output_does_not_salvage_nested_receipts_from_invalid_json(self):
        contract = acceptance.load_contract(self.project)
        valid = json.dumps(dict(schema=acceptance.SCHEMA, status="passed",
                               test_results=[dict(id=self.required, status="passed")]))
        for text in ('{"schema":"bad","schema":"duplicate","payload":' + valid + '}',
                     '{"value":NaN,"payload":' + valid + '}',
                     '{"outer":\n' + valid + '\nBROKEN}',
                     '[\n' + valid + '\n]', '[NaN,\n' + valid + '\n]'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                acceptance.validate_output(text, contract, mixed=True)

    def test_independent_review_cannot_pass_an_invalid_acceptance_receipt(self):
        c = self.settings()
        task = c["tasks"][0]
        expected = dict(run_id="run", task_id="T1", round=0, source_hash="hash")
        command = task["checks"][0]["shell_command"]
        report = dict(expected, verdict="PASS", summary="Checked", repair_plan=[], checks=[dict(
            requirement_id="R1", status="PASS", expected="passes", actual="claims passed", verification_commands=[command])])
        invalid = dict(schema=acceptance.SCHEMA, status="passed", test_results=[])
        event = dict(command=command, exit_code=0, status="completed", aggregated_output=json.dumps(invalid))
        with self.assertRaisesRegex(loop.StopRun, "acceptance evidence"):
            loop.validate_report(report, expected, task, {"one": event}, c["acceptance"])
        invalid["test_results"] = [{"id": self.required, "status": "passed"}]
        event["aggregated_output"] = "diagnostics\n" + json.dumps(invalid)
        self.assertEqual(loop.validate_report(report, expected, task, {"one": event}, c["acceptance"]), "PASS")
        forged = dict(event, exit_code=False)
        incomplete = dict(event, aggregated_output='{"status":"passed"}')
        with self.assertRaisesRegex(loop.StopRun, "acceptance evidence"):
            loop.validate_report(report, expected, task, {"one": incomplete, "two": forged}, c["acceptance"])


if __name__ == "__main__":
    unittest.main()
