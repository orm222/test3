import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

SOURCE = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("harness_launcher", SOURCE / "run_harness.py")
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)


class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="harness launcher ")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.contexts = contextlib.ExitStack()
        self.addCleanup(self.contexts.close)
        self.contexts.enter_context(mock.patch.object(launcher, "ROOT", self.root))
        self.output = io.StringIO()
        self.contexts.enter_context(contextlib.redirect_stdout(self.output))
        self.contexts.enter_context(contextlib.redirect_stderr(self.output))
        self.execve = self.contexts.enter_context(mock.patch.object(launcher.os, "execve"))
        self.child = self.contexts.enter_context(mock.patch.object(launcher.subprocess, "call", return_value=0))
        self.chdir = self.contexts.enter_context(mock.patch.object(launcher.os, "chdir"))
        self.probe = self.contexts.enter_context(mock.patch.object(launcher.subprocess, "run"))

    def environment(self, platform, version=(3, 9, 25), tomli=True, prefix=None):
        python = launcher.venv_python(self.root, platform)
        python.parent.mkdir(parents=True, exist_ok=True)
        python.touch()
        self.probe.return_value = subprocess.CompletedProcess([], 0, json.dumps({
            "version": list(version), "prefix": str(prefix or self.root / ".venv"), "tomli": tomli}), "")
        return python

    def last_argv(self):
        return self.child.call_args.args[0] if sys.platform == "win32" else self.execve.call_args.args[1]

    def test_both_os_paths_forward_arguments_and_python_environment(self):
        arguments = ["review", "quoted prompt & literal %VALUE%", "--timeout", "45"]
        for platform in ("win32", "linux"):
            with self.subTest(platform=platform):
                python = self.environment(platform)
                self.assertEqual(python.relative_to(self.root).as_posix(),
                                 ".venv/Scripts/python.exe" if platform == "win32" else ".venv/bin/python")
                with mock.patch.object(launcher.sys, "platform", platform), \
                     mock.patch.dict(os.environ, {"PATH": "previous-path", "PYTHONHOME": "wrong-home",
                                                  "LAUNCHER_TEST_VALUE": "preserved"}):
                    self.assertEqual(launcher.main(arguments), 0)
                if platform == "win32":
                    argv = self.child.call_args.args[0]
                    environment = self.child.call_args.kwargs["env"]
                else:
                    executable, argv, environment = self.execve.call_args.args
                    self.assertEqual(executable, str(python))
                self.assertEqual(argv, [str(python), "-B", str(self.root / ".harness/harness.py")] + arguments)
                self.assertEqual(environment["PATH"], str(python.parent) + os.pathsep + "previous-path")
                self.assertEqual(environment["VIRTUAL_ENV"], str(self.root / ".venv"))
                self.assertNotIn("PYTHONHOME", environment)
                self.assertEqual(environment["LAUNCHER_TEST_VALUE"], "preserved")
                self.chdir.assert_called_with(self.root)
                self.assertEqual(self.probe.call_args.kwargs["env"], environment)
                self.assertEqual(self.probe.call_args.kwargs["cwd"], str(self.root))

    def test_missing_environment_does_not_fall_back_to_system_python(self):
        self.assertEqual(launcher.main(["verify"]), 1)
        self.probe.assert_not_called()
        self.execve.assert_not_called()
        self.child.assert_not_called()
        self.assertIn("environment not found", self.output.getvalue())

    def test_wrong_version_or_foreign_environment_is_rejected(self):
        for version, prefix in (((3, 14, 0), None), ((3, 9, 25), self.root / "other-venv")):
            with self.subTest(version=version, prefix=prefix):
                self.environment(sys.platform, version=version, prefix=prefix)
                self.assertEqual(launcher.main(["verify"]), 1)
                self.execve.assert_not_called()
                self.child.assert_not_called()

    def test_missing_tomli_has_installation_guidance(self):
        self.environment(sys.platform, tomli=False)
        self.assertEqual(launcher.main(["status"]), 1)
        self.execve.assert_not_called()
        self.child.assert_not_called()
        self.assertIn("requirements-harness.txt", self.output.getvalue())

    def test_probe_failures_do_not_launch_harness_or_print_stderr(self):
        self.environment(sys.platform)
        for error in (subprocess.TimeoutExpired("python", 15),
                      subprocess.CalledProcessError(1, "python", stderr="private-probe-stderr"),
                      OSError("Cannot execute this OS's interpreter")):
            with self.subTest(error=type(error).__name__):
                self.probe.side_effect = error
                self.assertEqual(launcher.main(["verify"]), 1)
                self.execve.assert_not_called()
                self.child.assert_not_called()
        self.assertNotIn("private-probe-stderr", self.output.getvalue())

    def test_help_requires_no_environment_or_codex(self):
        self.assertEqual(launcher.main(["--help"]), 0)
        self.probe.assert_not_called()
        self.execve.assert_not_called()
        self.child.assert_not_called()

    def test_verify_and_status_are_forwarded_without_cli_preflight(self):
        self.environment(sys.platform)
        for command in ("verify", "status"):
            with self.subTest(command=command):
                self.probe.reset_mock()
                self.assertEqual(launcher.main([command]), 0)
                self.assertEqual(self.probe.call_count, 1)
                self.assertEqual(self.last_argv()[-1], command)

    def test_loop_uses_its_own_entrypoint_and_default_config(self):
        python = self.environment(sys.platform)
        self.assertEqual(launcher.main(["loop", "--preflight"]), 0)
        entry = self.root / "automation/codex-loop/run.py"
        self.assertEqual(self.last_argv(), [str(python), "-B", str(entry),
            "--config", str(entry.parent / "config.json"), "--preflight"])
        self.assertEqual(launcher.main(["loop", "--config=custom.json", "--preflight"]), 0)
        self.assertEqual(self.last_argv()[-2:], ["--config=custom.json", "--preflight"])

    def test_windows_waits_and_preserves_child_failure_exit_code(self):
        self.environment("win32")
        self.child.return_value = 7
        with mock.patch.object(launcher.sys, "platform", "win32"):
            self.assertEqual(launcher.main(["verify"]), 7)
        self.child.assert_called_once()
        self.execve.assert_not_called()

    def test_linux_work_automatically_routes_to_tmux_start_script(self):
        python = self.environment("linux")
        with mock.patch.object(launcher.sys, "platform", "linux"), \
             mock.patch.object(launcher.shutil, "which", return_value="/bin/bash"):
            self.assertEqual(launcher.main(["loop"]), 0)
        executable, argv, env = self.execve.call_args.args
        folder = self.root / "automation/codex-loop"
        self.assertEqual(executable, "/bin/bash")
        self.assertEqual(argv, ["/bin/bash", str(folder / "start.sh"), "--config", str(folder / "config.json")])
        self.assertEqual(env["PYTHON_BIN"], str(python))
        self.assertEqual(env["VIRTUAL_ENV"], str(self.root / ".venv"))
        self.child.assert_not_called()
        self.assertEqual(self.probe.call_args.args[0], [str(python), "-B",
            str(self.root / ".harness/clarify.py"), "--root", str(self.root), "--check-ready",
            "--config", str(folder / "config.json")])

    def test_linux_explicit_config_is_forwarded_literally(self):
        self.environment("linux")
        config = "settings/space & 'literal' %VALUE% 한글.json"
        with mock.patch.object(launcher.sys, "platform", "linux"), \
             mock.patch.object(launcher.shutil, "which", return_value="/bin/bash"):
            for args in (["--config", config], ["--config=" + config]):
                self.assertEqual(launcher.main(["loop"] + args), 0)
                self.assertEqual(self.execve.call_args.args[1][2:], args)
                self.assertEqual(self.probe.call_args.args[0][-2:], ["--config", config])

    def test_linux_unanswered_boundary_stops_before_tmux_or_bash(self):
        self.environment("linux")
        info = self.probe.return_value
        self.probe.side_effect = [info, subprocess.CompletedProcess([], 2)]
        with mock.patch.object(launcher.sys, "platform", "linux"), \
             mock.patch.object(launcher.shutil, "which") as which:
            self.assertEqual(launcher.main(["loop"]), 2)
            which.assert_not_called()
        self.execve.assert_not_called()
        self.child.assert_not_called()

    def test_clarify_uses_its_own_entrypoint_without_tmux_or_loop_configuration(self):
        for platform in ("win32", "linux"):
            with self.subTest(platform=platform):
                python = self.environment(platform)
                self.probe.reset_mock()
                with mock.patch.object(launcher.sys, "platform", platform), \
                     mock.patch.object(launcher.shutil, "which") as which:
                    arguments = ["--answer", "Q-001", "--answer-file", "space & 답변.txt"]
                    self.assertEqual(launcher.main(["clarify"] + arguments), 0)
                    which.assert_not_called()
                    argv = self.child.call_args.args[0] if platform == "win32" else self.execve.call_args.args[1]
                self.assertEqual(argv, [str(python), "-B", str(self.root / ".harness/clarify.py"),
                                       "--root", str(self.root)] + arguments)
                self.assertEqual(self.probe.call_count, 1)

    def test_linux_diagnostics_do_not_start_tmux(self):
        python = self.environment("linux")
        with mock.patch.object(launcher.sys, "platform", "linux"), \
             mock.patch.object(launcher.shutil, "which") as which:
            for flag in ("--help", "-h", "--preflight", "--probe-models"):
                with self.subTest(flag=flag):
                    self.assertEqual(launcher.main(["loop", flag]), 0)
                    self.assertEqual(self.execve.call_args.args[0], str(python))
                    self.assertEqual(self.execve.call_args.args[1][2], str(self.root / "automation/codex-loop/run.py"))
            which.assert_not_called()

    def test_windows_work_stays_in_current_terminal_and_keeps_failure_code(self):
        python = self.environment("win32")
        self.child.return_value = 2
        with mock.patch.object(launcher.sys, "platform", "win32"), \
             mock.patch.object(launcher.shutil, "which") as which:
            self.assertEqual(launcher.main(["loop"]), 2)
            which.assert_not_called()
        self.assertEqual(self.child.call_args.args[0][:3], [str(python), "-B", str(self.root / "automation/codex-loop/run.py")])
        self.execve.assert_not_called()

    def test_linux_missing_bash_does_not_fall_back_to_plain_work(self):
        self.environment("linux")
        with mock.patch.object(launcher.sys, "platform", "linux"), \
             mock.patch.object(launcher.shutil, "which", return_value=None):
            self.assertEqual(launcher.main(["loop"]), 1)
        self.assertIn("requires Bash", self.output.getvalue())
        self.execve.assert_not_called()
        self.child.assert_not_called()


if __name__ == "__main__":
    unittest.main()
