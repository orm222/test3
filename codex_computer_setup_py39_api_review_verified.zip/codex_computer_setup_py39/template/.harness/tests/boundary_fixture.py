"""Only fake local analysis for controller tests; never calls a model."""
import importlib.util
from pathlib import Path
import shutil

SOURCE = Path(__file__).resolve().parents[2]
_spec = importlib.util.spec_from_file_location("fixture_boundary", SOURCE / ".harness/boundary.py")
boundary = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(boundary)


def ready(root, spec="SPEC.md"):
    root = Path(root).resolve()
    target = root / spec
    if not target.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("Fake fixture: the required local check must pass.\n", encoding="utf-8")
    template = root / "BOUNDARY_QUESTION_TEMPLATE.md"
    if not template.exists():
        shutil.copy2(SOURCE / template.name, template)
    for name in ("reports.py", "review_criteria.json"):
        target = root / ".harness" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            shutil.copy2(SOURCE / ".harness" / name, target)
    state = boundary.create_state(root, spec)
    boundary.complete_analysis(root, state, {"version": 1, "questions": [], "unresolved": [], "references": []})
    return boundary.require_ready(root, spec)


def answered(root, spec="SPEC.md", answer="Reject a negative input without saving state.", references=None):
    ready(root, spec)
    state = boundary.create_state(root, spec)
    references = references or []
    boundary.complete_analysis(root, state, {"version": 1, "questions": [{
        "template": "T01", "question": "How should a negative input be handled?",
        "decides": "Validation and persistence behavior", "follow_up_to": None}],
        "unresolved": ["Negative input behavior is not specified"], "references": references})
    state = boundary.submit_answer(root, "Q-001", answer)
    boundary.complete_analysis(root, state, {"version": 1, "questions": [], "unresolved": [], "references": references})
    return boundary.require_ready(root, spec)
