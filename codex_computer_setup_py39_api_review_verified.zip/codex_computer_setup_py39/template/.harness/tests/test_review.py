import contextlib
from concurrent.futures import ThreadPoolExecutor
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock
from boundary_fixture import ready as ready_boundary, answered as answered_boundary
import api_fixture


SOURCE = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("review_harness", SOURCE / ".harness/harness.py")
harness = importlib.util.module_from_spec(spec)
with mock.patch.object(sys, "path", [str(SOURCE / ".harness"), *sys.path]):
    spec.loader.exec_module(harness)


FAKE_CODEX = """
import json
import os
from pathlib import Path
import sys
import time

scenario = json.loads(Path(__file__).with_suffix('.json').read_text(encoding='utf-8'))
args = sys.argv[1:]
if args == ['login', 'status']:
    Path(__file__).with_suffix('.login.json').write_text(json.dumps({'argv': args, 'cwd': str(Path.cwd())}), encoding='utf-8')
    print('FAKE_AUTH_PRIVATE_OUTPUT', flush=True)
    print('FAKE_AUTH_PRIVATE_ERROR', file=sys.stderr, flush=True)
    time.sleep(scenario.get('login_sleep', 0))
    raise SystemExit(scenario.get('login_exit', 0))
answer = Path(args[args.index('--output-last-message') + 1])
capture = {'argv': args, 'stdin': sys.stdin.buffer.read().decode('utf-8'), 'pid': os.getpid(), 'cwd': str(Path.cwd())}
answer.with_name('capture.json').write_text(json.dumps(capture), encoding='utf-8')
print(json.dumps({'type':'item.completed','item':{'id':'message','type':'agent_message','text':'fake review child ran'}}), flush=True)
if scenario.get('write_output', True):
    text = scenario.get('raw_output', json.dumps(scenario['result']))
    answer.write_text(text, encoding='utf-8')
if scenario.get('mutate'):
    Path('src.py').write_text('value = 99\\nprint(value)\\n', encoding='utf-8')
if scenario.get('mutate_report'):
    Path('docs/progress.md').write_text('forged progress', encoding='utf-8')
time.sleep(scenario.get('sleep', 0))
for item in scenario.get('events', []):
    print(json.dumps({'type':'item.completed','item':item}), flush=True)
if not scenario.get('missing_turn'):
    print(json.dumps({'type':'turn.completed'}), flush=True)
raise SystemExit(scenario.get('exit_code', 0))
"""


class RetryingTemporaryDirectory(tempfile.TemporaryDirectory):
    def cleanup(self):
        # All child processes are waited for before cleanup. Windows may still
        # briefly deny deletion while releasing file handles; never hide a lock.
        deadline = time.monotonic() + 5
        while True:
            try:
                return super().cleanup()
            except PermissionError as exc:
                if (os.name != "nt" or getattr(exc, "winerror", None) not in (5, 32)
                        or time.monotonic() >= deadline):
                    raise
                time.sleep(0.05)


@unittest.skipUnless(os.name == "nt", "Windows npm batch wrapper behavior")
class CodexLaunchTests(unittest.TestCase):
    def test_npm_shim_is_bypassed_and_metacharacters_remain_literal(self):
        with RetryingTemporaryDirectory(prefix="codex-npm-") as temporary:
            base = Path(temporary).resolve()
            shim = base / "codex.cmd"
            shim.write_text("@echo off\nexit /b 99\n", encoding="utf-8")
            entry = base / "node_modules/@openai/codex/bin/codex.js"
            entry.parent.mkdir(parents=True)
            entry.write_text("import json,sys\nprint(json.dumps(sys.argv[1:]))\n", encoding="utf-8")
            lookup = {"codex": str(shim), "node.exe": sys.executable}
            with mock.patch.object(harness.shutil, "which", side_effect=lookup.get):
                command = harness.codex_command()
            self.assertEqual(command, [sys.executable, str(entry)])
            literal = r"D:\R&echo.BAD%PATH%"
            result = subprocess.run(command + [literal], capture_output=True, text=True, check=True)
            self.assertEqual(json.loads(result.stdout), [literal])
            with mock.patch.object(harness, "codex_command", return_value=command):
                self.assertEqual(harness.prepare_codex(base, 10), command)

    def test_unknown_batch_wrapper_fails_without_execution(self):
        with RetryingTemporaryDirectory(prefix="codex-wrapper-") as temporary:
            lookup = {"codex": str(Path(temporary) / "codex.cmd"), "node.exe": sys.executable}
            with mock.patch.object(harness.shutil, "which", side_effect=lookup.get):
                with self.assertRaises(ValueError):
                    harness.codex_command()


class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = RetryingTemporaryDirectory(prefix="harness-review-")
        self.addCleanup(self.temp.cleanup)
        self.project_number = 0
        self.new_project()
        self.fake = Path(self.temp.name) / "fake_codex.py"
        self.fake.write_text(FAKE_CODEX, encoding="utf-8")
        contexts = contextlib.ExitStack()
        self.addCleanup(contexts.close)
        contexts.enter_context(mock.patch.object(harness, "codex_command", return_value=[sys.executable, str(self.fake)]))
        self.output = io.StringIO()
        contexts.enter_context(contextlib.redirect_stdout(self.output))
        contexts.enter_context(contextlib.redirect_stderr(self.output))

    def new_project(self):
        self.project_number += 1
        self.root = (Path(self.temp.name) / f"project with spaces {self.project_number}").resolve()
        self.root.mkdir()
        subprocess.run(["git", "init", "-q", str(self.root)], check=True, capture_output=True)
        self.write("src.py", "value = 1\nprint(value)\n")
        self.write(".harness/checks.json", '{"checks": []}')
        self.write(".harness/review.schema.json", (SOURCE / ".harness/review.schema.json").read_text(encoding="utf-8"))
        self.write(".codex/agents/kty-reviewer.toml", 'developer_instructions = "ROLE_SENTINEL 독립 검수"\n')
        self.write(".harness/review_instructions.md", "PROCEDURE_SENTINEL 검수 절차")
        ready_boundary(self.root)

    def write(self, name, text):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path

    def result(self, severity=None):
        return {
            "summary": "현재 코드 검토 완료",
            "reviewed_files": ["src.py"],
            "findings": [] if severity is None else [{
                "severity": severity, "file": "src.py", "line": 2,
                "input": "value가 정의되지 않은 상태", "evidence": "print(value)에서 이름 조회 실패",
            }],
            "limitations": [],
            "criterion_scores": [{"criterion_id": prefix + "{:02d}".format(number),
                                 "status": "UNVERIFIED", "reason": "This fake reviewer did not exercise this criterion.",
                                 "evidence_refs": []}
                                for prefix in ("COR", "TEST", "REL", "MEAS", "HAND") for number in range(1, 5)],
        }

    def test_review_includes_actual_questions_and_answers(self):
        answered_boundary(self.root, answer="BOUNDARY_USER_SENTINEL Reject negative inputs without saving.")
        code, run, receipt = self.invoke()
        self.assertEqual(code, 0, self.output.getvalue())
        capture = json.loads((run / "capture.json").read_text(encoding="utf-8"))
        self.assertIn("How should a negative input be handled?", capture["stdin"])
        self.assertIn("BOUNDARY_USER_SENTINEL", capture["stdin"])
        self.assertIn("Q-001", capture["stdin"])

    def test_review_not_ready_stops_before_cli_or_claim(self):
        (self.root / ".harness/boundary.json").unlink()
        with mock.patch.object(harness, "prepare_codex") as prepare:
            with self.assertRaises(ValueError):
                harness.review(self.root, "review", remaining_seconds=1800, reserve_seconds=600)
            prepare.assert_not_called()
        self.assertFalse((self.root / ".harness/work").exists())

    def test_shared_score_uses_observed_files_and_completed_commands(self):
        result = self.result()
        for row in result["criterion_scores"]:
            if row["criterion_id"] == "COR01":
                row.update(status="PASS", reason="Observed the implementation.", evidence_refs=["file:src.py"])
            if row["criterion_id"] == "TEST01":
                row.update(status="PASS", reason="Executed the check.", evidence_refs=["command:python checks.py"])
        event = dict(id="check-one", type="command_execution", command="python checks.py",
                     exit_code=0, status="completed", aggregated_output="one check passed")
        code, run, receipt = self.invoke(result, events=[event])
        self.assertEqual(code, 0, self.output.getvalue())
        axes = {axis["id"]: axis["score"] for axis in receipt["review_score"]["axes"]}
        self.assertEqual(axes["intent"], 50.0)
        self.assertEqual(axes["technical"], 12.5)
        text = (self.root / "docs/review-score.md").read_text(encoding="utf-8")
        self.assertIn("| 의도 | 50.0 |", text)
        self.assertIn("command:python checks.py", text)
        self.assertIn("--json", json.loads((run / "capture.json").read_text(encoding="utf-8"))["argv"])

    def test_prior_api_execution_is_scoped_evidence_and_never_a_current_command(self):
        api_fixture.configure(self.root)
        harness.reports.initialize(self.root)
        api_fixture.record(self.root, harness.reports)
        result = self.result()
        next(row for row in result["criterion_scores"] if row["criterion_id"] == "TEST01").update(
            status="PARTIAL", reason="Prior API check covered a subset", evidence_refs=["api-check:schemathesis"])
        code, run, receipt = self.invoke(result)
        self.assertEqual(code, 0, self.output.getvalue())
        capture = json.loads((run / "capture.json").read_text(encoding="utf-8"))
        self.assertIn("Prior controller API execution; not commands executed by this reviewer", capture["stdin"])
        entry = receipt["review_score"]["evidence"]["api-check:schemathesis"]
        self.assertEqual(entry["status"], "PASS")
        self.assertEqual(len(entry["artifacts"]), 6)
        self.assertFalse(any(ref.startswith("command:") for ref in receipt["review_score"]["evidence"]))
        with mock.patch.object(harness, "prepare_codex", side_effect=AssertionError("one attempt only")):
            self.assertEqual(harness.review(self.root, "second", remaining_seconds=1800, reserve_seconds=600), 3)

    def test_false_or_missing_execution_evidence_cannot_receive_positive_score(self):
        for mode in ("file-only", "missing-command", "bool-exit", "missing-turn"):
            with self.subTest(mode=mode):
                self.new_project()
                result = self.result()
                row = next(row for row in result["criterion_scores"] if row["criterion_id"] == "TEST01")
                row.update(status="PASS", reason="Claimed execution.", evidence_refs=[
                    "file:src.py" if mode == "file-only" else "command:python checks.py"])
                event = dict(id="fake", type="command_execution", command="python checks.py",
                             exit_code=False, status="completed", aggregated_output="claimed")
                code, _, receipt = self.invoke(result, events=[event] if mode == "bool-exit" else [],
                                                missing_turn=mode == "missing-turn")
                self.assertEqual(code, 1)
                self.assertFalse(receipt["completed"])
                self.assertIn("점수 미산정", (self.root / "docs/review-score.md").read_text(encoding="utf-8"))

    def test_duplicate_or_missing_criteria_are_unscored(self):
        for duplicate in (False, True):
            self.new_project()
            result = self.result()
            result["criterion_scores"].pop()
            if duplicate:
                result["criterion_scores"].append(result["criterion_scores"][0])
            code, _, receipt = self.invoke(result)
            self.assertEqual(code, 1)
            self.assertFalse(receipt["completed"])

    def test_reviewer_cannot_edit_controller_documents(self):
        code, _, receipt = self.invoke(mutate_report=True)
        self.assertEqual(code, 1)
        self.assertFalse(receipt["completed"])
        self.assertEqual((self.root / "docs/progress.md").read_text(encoding="utf-8"), "forged progress")

    def test_source_change_marks_score_stale_without_rerunning_review(self):
        code, _, receipt = self.invoke()
        self.assertEqual(code, 0)
        self.assertTrue(receipt["completed"])
        self.write("src.py", "value = 2\nprint(value)\n")
        with mock.patch.object(harness, "codex_command", side_effect=AssertionError("status cannot rerun a model")):
            self.assertEqual(harness.status(self.root), 1)
        self.assertIn("오래됨", (self.root / "docs/review-score.md").read_text(encoding="utf-8"))

    def test_managed_document_score_uses_the_preserved_review_input(self):
        result = self.result()
        result["reviewed_files"].append("docs/progress.md")
        row = next(row for row in result["criterion_scores"] if row["criterion_id"] == "HAND01")
        row.update(status="PASS", reason="Read the captured progress report.",
                   evidence_refs=["file:docs/progress.md"])
        code, run, receipt = self.invoke(result)
        self.assertEqual(code, 0, self.output.getvalue())
        proof = receipt["review_score"]["evidence"]["file:docs/progress.md"]
        captured = self.root / proof["path"]
        self.assertEqual(captured, run / "report-inputs/progress.md")
        self.assertNotEqual(captured.read_bytes(), (self.root / "docs/progress.md").read_bytes())
        harness.reports.refresh(self.root)
        self.assertNotIn("점수 미산정", (self.root / "docs/review-score.md").read_text(encoding="utf-8").split("## 리뷰 이력")[0])
        captured.write_text("tampered archived evidence", encoding="utf-8")
        harness.status(self.root)
        self.assertIn("점수 미산정", (self.root / "docs/review-score.md").read_text(encoding="utf-8"))

    def test_na_requires_the_predetermined_project_criteria_map(self):
        result = self.result()
        row = next(row for row in result["criterion_scores"] if row["criterion_id"] == "REL01")
        row.update(status="NA", reason="No asynchronous upload or retry interface exists.")
        code, _, receipt = self.invoke(result)
        self.assertEqual(code, 1)
        self.assertFalse(receipt["completed"])
        self.new_project()
        self.write("automation/codex-loop/config.json", json.dumps({"spec": "SPEC.md",
            "review_not_applicable": {"REL01": "No asynchronous upload or retry interface exists."}}))
        code, _, receipt = self.invoke(result)
        self.assertEqual(code, 0, self.output.getvalue())
        axis = next(axis for axis in receipt["review_score"]["axes"] if axis["id"] == "technical")
        self.assertEqual(axis["possible"], 14)

    def invoke(self, result=None, timeout=30, model=None, **scenario):
        before = set((self.root / ".harness/work").glob("review-*"))
        scenario["result"] = self.result() if result is None else result
        self.fake.with_suffix(".json").write_text(json.dumps(scenario), encoding="utf-8")
        code = harness.review(self.root, "TASK_SENTINEL 현재 경계 입력 검토", timeout=timeout, model=model,
                              remaining_seconds=1800, reserve_seconds=600)
        added = set((self.root / ".harness/work").glob("review-*")) - before
        self.assertEqual(len(added), 1)
        run = added.pop()
        receipt = json.loads((run / "receipt.json").read_text(encoding="utf-8"))
        return code, run, receipt

    def test_fresh_read_only_child_receives_role_procedure_and_task_via_stdin(self):
        code, run, receipt = self.invoke(model="explicit-test-model")
        self.assertEqual(code, 0)
        self.assertTrue(receipt["completed"])
        self.assertEqual(receipt["exit_code"], 0)
        self.assertEqual(receipt["blocking_findings"], 0)
        self.assertEqual(receipt["fingerprint_before"], receipt["fingerprint_after"])
        capture = json.loads((run / "capture.json").read_text(encoding="utf-8"))
        self.assertNotEqual(capture["pid"], os.getpid())
        self.assertEqual(Path(capture["cwd"]), self.root)
        args = capture["argv"]
        self.assertEqual(args[0], "exec")
        self.assertEqual(args[-1], "-")
        self.assertIn("--ephemeral", args)
        for flag, expected in (
            ("--cd", str(self.root)), ("--sandbox", "read-only"),
            ("--config", 'approval_policy="never"'),
            ("--output-schema", str(self.root / ".harness/review.schema.json")),
            ("--output-last-message", str(run / "review.json")),
            ("--model", "explicit-test-model"),
        ):
            self.assertEqual(args[args.index(flag) + 1], expected)
        for sentinel in ("ROLE_SENTINEL 독립 검수", "PROCEDURE_SENTINEL 검수 절차", "TASK_SENTINEL 현재 경계 입력 검토"):
            self.assertIn(sentinel, capture["stdin"])
            self.assertNotIn(sentinel, args)
        self.assertIn("fake review child ran", (run / "process.log").read_text(encoding="utf-8"))
        login = json.loads(self.fake.with_suffix(".login.json").read_text(encoding="utf-8"))
        self.assertEqual(login, {"argv": ["login", "status"], "cwd": str(self.root)})
        self.assertNotIn("FAKE_AUTH_PRIVATE", self.output.getvalue())
        self.assertNotIn("FAKE_AUTH_PRIVATE", (run / "process.log").read_text(encoding="utf-8"))

    def test_severity_controls_blocking_exit_without_invalidating_completed_review(self):
        for severity, expected in (("LOW", 0), ("MEDIUM", 0), ("HIGH", 2), ("CRITICAL", 2)):
            with self.subTest(severity=severity):
                self.new_project()
                code, _, receipt = self.invoke(self.result(severity))
                self.assertEqual(code, expected)
                self.assertTrue(receipt["completed"])
                self.assertEqual(receipt["blocking_findings"], int(expected == 2))

    def test_second_review_is_skipped_without_changing_first_evidence(self):
        first_code, first_run, _ = self.invoke()
        before = {p.name: p.read_bytes() for p in first_run.iterdir() if p.is_file()}
        with mock.patch.object(harness, "codex_command", side_effect=AssertionError("must not launch")):
            second_code = harness.review(self.root, "repeat", remaining_seconds=1800, reserve_seconds=600)
        self.assertEqual((first_code, second_code), (0, 3))
        self.assertEqual(before, {p.name: p.read_bytes() for p in first_run.iterdir() if p.is_file()})
        self.assertEqual(len(list((self.root / ".harness/work").glob("review-*"))), 1)
        capture = json.loads((first_run / "capture.json").read_text(encoding="utf-8"))
        self.assertNotIn("--model", capture["argv"])

    def test_failed_review_consumes_attempt_and_cannot_reuse_output(self):
        code, current, receipt = self.invoke(write_output=False, exit_code=7)
        self.assertEqual(code, 1)
        self.assertFalse(receipt["completed"])
        self.assertEqual(receipt["exit_code"], 7)
        self.assertFalse((current / "review.json").exists())
        self.assertEqual(harness.review(self.root, "retry", remaining_seconds=1800, reserve_seconds=600), 3)

    def test_budget_insufficient_skips_without_claiming_or_launching(self):
        with mock.patch.object(harness, "codex_command", side_effect=AssertionError("must not launch")):
            self.assertEqual(harness.review(self.root, "check", timeout=600,
                                           remaining_seconds=899, reserve_seconds=300), 3)
        self.assertFalse((self.root / ".harness/work/independent-review-claim").exists())
        code, _, _ = self.invoke()
        self.assertEqual(code, 0)

    def test_invalid_or_missing_budget_is_rejected_before_launch(self):
        with mock.patch.object(harness, "codex_command", side_effect=AssertionError("must not launch")):
            with self.assertRaises(TypeError):
                harness.review(self.root, "check")
            for field in ("remaining_seconds", "reserve_seconds", "timeout"):
                for value in (0, -1, True, 1.5, float("inf"), "600", None):
                    args = dict(remaining_seconds=1800, reserve_seconds=600, timeout=600)
                    args[field] = value
                    with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                        harness.review(self.root, "check", **args)
        self.assertFalse((self.root / ".harness/work/independent-review-claim").exists())

    def test_simultaneous_reviews_launch_only_one_process(self):
        self.fake.with_suffix(".json").write_text(json.dumps({"result": self.result(), "sleep": 0.2}), encoding="utf-8")
        def call():
            return harness.review(self.root, "concurrent", timeout=30,
                                  remaining_seconds=1800, reserve_seconds=600)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: call(), range(2)))
        self.assertEqual(sorted(results), [0, 3])
        self.assertEqual(len(list((self.root / ".harness/work").glob("review-*/capture.json"))), 1)

    def test_nonzero_exit_is_failure_even_with_valid_output(self):
        code, run, receipt = self.invoke(exit_code=4)
        self.assertEqual(code, 1)
        self.assertTrue((run / "review.json").is_file())
        self.assertFalse(receipt["completed"])
        self.assertEqual(receipt["exit_code"], 4)

    def test_missing_malformed_and_invalid_outputs_do_not_complete(self):
        for scenario in (
            {"write_output": False}, {"raw_output": "not JSON"},
            {"raw_output": "null"}, {"result": {"summary": "missing fields"}},
        ):
            with self.subTest(scenario=scenario):
                self.new_project()
                code, _, receipt = self.invoke(**scenario)
                self.assertEqual(code, 1)
                self.assertFalse(receipt["completed"])
                self.assertEqual(receipt["exit_code"], 0)
                self.assertTrue(receipt["error"])

    def test_source_changed_by_child_makes_review_stale(self):
        code, _, receipt = self.invoke(mutate=True)
        self.assertEqual(code, 1)
        self.assertEqual(receipt["exit_code"], 0)
        self.assertFalse(receipt["completed"])
        self.assertNotEqual(receipt["fingerprint_before"], receipt["fingerprint_after"])

    def test_timeout_stops_child_and_does_not_complete(self):
        children = []
        start_process = harness.start_process

        def capture_process(*args, **kwargs):
            process = start_process(*args, **kwargs)
            children.append((process, kwargs["stdout"]))
            return process

        started = time.monotonic()
        with mock.patch.object(harness, "start_process", side_effect=capture_process):
            code, _, receipt = self.invoke(sleep=30, timeout=1)
        self.assertLess(time.monotonic() - started, 10)
        self.assertEqual(len(children), 2)
        self.assertIsNotNone(children[0][0].poll(), "login check did not finish")
        process, log = children[-1]
        self.assertIsNotNone(process.poll(), "timeout returned with the review child still alive")
        self.assertTrue(log.closed, "timeout left the parent log handle open")
        self.assertTrue(process.stdin.closed, "timeout left the child stdin handle open")
        self.assertEqual(code, 1)
        self.assertFalse(receipt["completed"])
        self.assertTrue(receipt["error"])
        self.assertIn("finished_at", receipt)

    def test_every_finding_field_is_required(self):
        for field in ("severity", "file", "line", "input", "evidence"):
            with self.subTest(field=field):
                result = self.result("HIGH")
                del result["findings"][0][field]
                with self.assertRaises(ValueError):
                    harness.validate_review(self.root, result)

    def test_invalid_finding_values_are_rejected(self):
        for field, value in (
            ("severity", "URGENT"), ("line", 0), ("line", 3), ("line", True),
            ("line", 1.0), ("line", "1"), ("input", " "), ("evidence", ""),
            ("input", None), ("evidence", []),
        ):
            with self.subTest(field=field, value=value):
                result = self.result("HIGH")
                result["findings"][0][field] = value
                with self.assertRaises(ValueError):
                    harness.validate_review(self.root, result)

    def test_missing_and_escaping_paths_are_rejected_for_findings_and_reviewed_files(self):
        outside = Path(self.temp.name) / "outside.py"
        outside.write_text("outside = 1\n", encoding="utf-8")
        for name in ("missing.py", "../outside.py", str(outside), ".", "", None):
            for location in ("finding", "reviewed_files"):
                with self.subTest(name=name, location=location):
                    result = self.result("HIGH")
                    if location == "finding":
                        result["findings"][0]["file"] = name
                    else:
                        result["reviewed_files"] = [name]
                    with self.assertRaises(ValueError):
                        harness.validate_review(self.root, result)

    def test_symlink_to_outside_project_is_rejected(self):
        outside = Path(self.temp.name) / "outside.py"
        outside.write_text("outside = 1\n", encoding="utf-8")
        try:
            (self.root / "escape.py").symlink_to(outside)
        except OSError as exc:
            self.skipTest("Symlink creation is unavailable: " + str(exc))
        result = self.result("HIGH")
        result["findings"][0]["file"] = "escape.py"
        with self.assertRaises(ValueError):
            harness.validate_review(self.root, result)

    def test_invalid_top_level_structure_is_rejected(self):
        valid = self.result()
        invalid = [None, [], {}, {**valid, "extra": True}]
        for field in valid:
            missing = copy.deepcopy(valid)
            del missing[field]
            invalid.append(missing)
        for field, value in (("summary", ""), ("reviewed_files", []), ("findings", {}),
                             ("limitations", "unknown"), ("limitations", [""])):
            invalid.append({**valid, field: value})
        for result in invalid:
            with self.subTest(result=result), self.assertRaises(ValueError):
                harness.validate_review(self.root, result)

    def test_verify_and_status_do_not_require_codex(self):
        self.write("acceptance_checker.py", "import json\nprint(json.dumps(" + repr({
            "schema": "project-acceptance/v1", "status": "passed",
            "test_results": [{"id": "fixture.required", "status": "passed"}]}) + "))\n")
        self.write("required_ids.json", json.dumps({"version": 1, "required_test_ids": ["fixture.required"]}))
        self.write(".harness/acceptance.json", json.dumps({"version": 1,
            "checker_argv": ["{python}", "-B", "acceptance_checker.py"],
            "required_ids_manifest": "required_ids.json", "protected_paths": ["acceptance_checker.py"]}))
        self.write(".harness/checks.json", json.dumps({"checks": [{
            "name": "local", "command": ["{python}", "-c", "print('local check')"]}]}))
        with mock.patch.object(harness, "codex_command", side_effect=AssertionError("must not launch Codex")):
            for command in ("verify", "status"):
                with self.subTest(command=command), mock.patch.object(
                    sys, "argv", ["harness.py", "--root", str(self.root), command]
                ):
                    self.assertEqual(harness.main(), 0)

    def test_login_failure_does_not_claim_review_and_allows_retry(self):
        self.fake.with_suffix(".json").write_text(json.dumps({"login_exit": 1}), encoding="utf-8")
        self.assertEqual(harness.review(self.root, "check", remaining_seconds=1800, reserve_seconds=600), 1)
        self.assertTrue(self.fake.with_suffix(".login.json").is_file())
        self.assertFalse((self.root / ".harness/work/independent-review-claim").exists())
        self.assertFalse(list((self.root / ".harness/work").glob("review-*")))
        self.assertNotIn("FAKE_AUTH_PRIVATE", self.output.getvalue())
        self.assertIn("codex login", self.output.getvalue())
        code, _, receipt = self.invoke()
        self.assertEqual(code, 0)
        self.assertTrue(receipt["completed"])

    def test_login_timeout_stops_process_without_claiming_review(self):
        self.fake.with_suffix(".json").write_text(json.dumps({"login_sleep": 30}), encoding="utf-8")
        children = []
        start_process = harness.start_process
        def capture_process(*args, **kwargs):
            process = start_process(*args, **kwargs)
            children.append(process)
            return process
        started = time.monotonic()
        with mock.patch.object(harness, "start_process", side_effect=capture_process):
            self.assertEqual(harness.review(self.root, "check", timeout=1,
                                           remaining_seconds=600, reserve_seconds=60), 1)
        self.assertLess(time.monotonic() - started, 30)
        self.assertEqual(len(children), 1)
        self.assertIsNotNone(children[0].poll())
        self.assertFalse((self.root / ".harness/work/independent-review-claim").exists())
        self.assertFalse(list((self.root / ".harness/work").glob("review-*")))

    def test_cli_reports_unavailable_codex_without_consuming_review(self):
        with mock.patch.object(harness, "codex_command", side_effect=ValueError("Codex is unavailable")):
            with mock.patch.object(sys, "argv", ["harness.py", "--root", str(self.root), "review", "check src.py",
                                                "--remaining-seconds", "1800", "--reserve-seconds", "600"]):
                self.assertEqual(harness.main(), 1)
        self.assertFalse(list((self.root / ".harness/work").glob("review-*")))
        self.assertFalse((self.root / ".harness/work/independent-review-claim").exists())
        self.assertIn("Codex is unavailable", self.output.getvalue())
        code, _, receipt = self.invoke()
        self.assertEqual(code, 0)
        self.assertTrue(receipt["completed"])


if __name__ == "__main__":
    unittest.main()
