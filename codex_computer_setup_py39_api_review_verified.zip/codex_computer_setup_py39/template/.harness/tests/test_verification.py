import contextlib
import importlib.util
import io
import json
import os
import signal
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock
from boundary_fixture import ready as ready_boundary, answered as answered_boundary
import api_fixture


SOURCE = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("verification", SOURCE / ".harness/verification.py")
verification = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verification)


class VerificationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="harness-verification-")
        self.addCleanup(self.cleanup_temp)
        self.root = Path(self.temp.name) / "project with spaces"
        self.root.mkdir()
        subprocess.run(["git", "init", "-q", str(self.root)], check=True, capture_output=True)
        self.write("app.py", "value = 1\n")
        self.write(".gitignore", "__pycache__/\nignored/\n")
        self.checks()
        # Controller fixtures use a deterministic receipt; real unittest acceptance is tested separately.
        self.write("acceptance_checker.py", "import json\nprint(json.dumps(" + repr({
            "schema": "project-acceptance/v1", "status": "passed",
            "test_results": [{"id": "fixture.required", "status": "passed"}]}) + "))\n")
        self.write("required_ids.json", json.dumps({"version": 1, "required_test_ids": ["fixture.required"]}))
        self.write(".harness/acceptance.json", json.dumps({"version": 1,
            "checker_argv": ["{python}", "-B", "acceptance_checker.py"],
            "required_ids_manifest": "required_ids.json", "protected_paths": ["acceptance_checker.py"]}))
        ready_boundary(self.root)
        self.output = io.StringIO()
        contexts = contextlib.ExitStack()
        self.addCleanup(contexts.close)
        contexts.enter_context(contextlib.redirect_stdout(self.output))
        contexts.enter_context(contextlib.redirect_stderr(self.output))

    def cleanup_temp(self):
        # Windows scanners may briefly lock Git's sample hook after git exits.
        deadline = time.monotonic() + 5
        while True:
            try:
                self.temp.cleanup()
                return
            except PermissionError as exc:
                if os.name != 'nt' or exc.winerror not in (5, 32) or time.monotonic() >= deadline:
                    raise
                time.sleep(0.05)

    def write(self, name, text):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path

    def checks(self, code="print('passed')", **extra):
        data = {"checks": [{"name": "unit", "command": ["{python}", "-c", code],
                             "timeout_seconds": 30}]}
        data.update(extra)
        verification.write_json(self.root / ".harness/checks.json", data)

    def receipt(self):
        return verification.read_json(self.receipt_paths()[-1])

    def receipt_paths(self):
        return sorted((self.root / ".harness/work").glob("verify-*/receipt.json"))

    def test_pass_records_commands_logs_and_current_state(self):
        self.assertEqual(verification.verify(self.root), 0)
        self.assertEqual(verification.status(self.root), 0)
        self.assertTrue(self.receipt()["passed"])
        self.assertEqual(self.receipt()["results"][0]["exit_code"], 0)
        self.assertIn("passed", (self.root / self.receipt()["results"][0]["log"]).read_text())
        self.assertEqual(self.receipt()["fingerprint_before"], self.receipt()["fingerprint_after"])
        self.assertEqual(self.receipt()["status"], "passed")
        self.assertIsNotNone(self.receipt()["finished_at"])
        self.write(".harness/work/review.json", "review output")
        self.write("work/notes.txt", "scratch")
        self.assertEqual(verification.status(self.root), 0)

    def register_api(self, mode="passed", first=False):
        api_fixture.configure(self.root, mode)
        data = verification.read_json(self.root / ".harness/checks.json")
        check = {"name": "api-review", "command": ["{python}", "-B", ".harness/api-review/check_api.py"],
                 "protocol": verification.reports.API_PROTOCOL, "timeout_seconds": 30}
        data["checks"].insert(0 if first else len(data["checks"]), check)
        verification.write_json(self.root / ".harness/checks.json", data)

    def test_optional_api_receipt_is_validated_and_raw_damage_rejects_current_status(self):
        self.register_api()
        self.assertEqual(verification.verify(self.root), 0, self.output.getvalue())
        self.assertEqual(verification.status(self.root), 0, self.output.getvalue())
        receipt = self.receipt()
        api = next(row for row in receipt["results"] if row["name"] == "api-review")
        self.assertEqual(api["api_review"]["status"], "passed")
        self.assertIn("raw diagnostics", (self.root / api["stderr_log"]).read_text(encoding="utf-8"))
        self.assertTrue(next(row for row in receipt["results"] if row["name"] == "acceptance")["acceptance_passed"])
        self.assertIn("선택 API 검수", (self.root / "docs/progress.md").read_text(encoding="utf-8"))
        artifact = api["api_review"]["checks"][0]["artifacts"][-1]["path"]
        self.write(artifact, "damaged XML")
        self.assertEqual(verification.status(self.root), 1)
        self.assertIsNone(verification.reports.current_api_evidence(self.root)["context"])

    def test_api_zero_allskip_malformed_missing_and_failed_results_cannot_pass(self):
        for mode in ("zero", "allskip", "malformed", "missing", "failed"):
            with self.subTest(mode=mode):
                self.checks()
                self.register_api(mode)
                self.assertEqual(verification.verify(self.root), 1, self.output.getvalue())
                self.assertEqual(verification.status(self.root), 1)
                api = next(row for row in self.receipt()["results"] if row["name"] == "api-review")
                self.assertEqual(api["status"], "failed")
                if mode == "failed":
                    self.assertEqual(api["api_review"]["checks"][0]["status"], "FAIL")
                    self.assertIn("FAIL", (self.root / "docs/progress.md").read_text(encoding="utf-8"))
                else:
                    self.assertNotIn("api_review", api)

    def test_unreached_api_check_is_recorded_not_run_without_old_pass_reuse(self):
        self.register_api()
        self.assertEqual(verification.verify(self.root), 0)
        self.checks("raise SystemExit(1)")
        self.register_api()
        self.assertEqual(verification.verify(self.root), 1)
        api = next(row for row in self.receipt()["results"] if row["name"] == "api-review")
        self.assertEqual(api["status"], "not_run")
        self.assertIsNone(verification.reports.current_api_evidence(self.root)["context"])

    def test_unknown_protocol_or_substitute_runner_is_rejected_before_execution(self):
        self.register_api()
        data = verification.read_json(self.root / ".harness/checks.json")
        data["checks"][-1]["command"] = ["{python}", "-c", "print('forged')"]
        verification.write_json(self.root / ".harness/checks.json", data)
        with mock.patch.object(verification, "run_check", side_effect=AssertionError("must not launch")):
            self.assertEqual(verification.verify(self.root), 1)

    def test_managed_reports_refresh_without_changing_semantic_fingerprint(self):
        self.assertEqual(verification.verify(self.root), 0)
        before = verification.fingerprint(self.root)
        verification.reports.append_event(self.root, {"kind": "note", "status": "RECORDED",
            "data": {"next_steps": "Keep the actual result and continue with the next check."}})
        self.assertEqual(verification.fingerprint(self.root), before)
        self.assertEqual(verification.status(self.root), 0)
        self.write("docs/design.md", "A real source document, not a managed report.")
        self.assertNotEqual(verification.fingerprint(self.root), before)
        self.assertEqual(verification.status(self.root), 1)

    def test_existing_report_documents_are_not_overwritten_or_excluded(self):
        original = "The user's existing progress document.\n"
        self.write("docs/progress.md", original)
        before = verification.fingerprint(self.root)
        self.write("docs/progress.md", original + "A source change.\n")
        self.assertNotEqual(verification.fingerprint(self.root), before)
        with mock.patch.object(verification, "run_check", side_effect=AssertionError("must not execute")):
            self.assertEqual(verification.verify(self.root), 1)
        self.assertEqual((self.root / "docs/progress.md").read_text(encoding="utf-8"), original + "A source change.\n")
        self.assertFalse((self.root / "docs/review-score.md").exists())

    def test_check_cannot_edit_managed_progress_or_continue_to_later_checks(self):
        self.checks("from pathlib import Path; Path('docs/progress.md').write_text('forged progress')")
        self.assertEqual(verification.verify(self.root), 1)
        self.assertFalse(self.receipt()["passed"])
        self.assertEqual(self.receipt()["results"][-1]["status"], "not_run")
        self.assertEqual((self.root / "docs/progress.md").read_text(encoding="utf-8"), "forged progress")
        self.assertEqual(verification.status(self.root), 1)

    def test_reporting_runtime_criteria_and_schema_stay_hashed_when_ignored(self):
        self.write(".gitignore", ".harness/\ndocs/\n__pycache__/\n")
        self.write(".harness/review.schema.json", '{"description":"review schema"}')
        self.assertEqual(verification.verify(self.root), 0)
        for name in (".harness/reports.py", ".harness/review_criteria.json", ".harness/review.schema.json"):
            with self.subTest(name=name):
                path = self.root / name
                original = path.read_bytes()
                path.write_bytes(original + b"\n ")
                self.assertEqual(verification.status(self.root), 1)
                path.write_bytes(original)
                self.assertEqual(verification.status(self.root), 0)

    def test_failed_and_not_run_checks_are_preserved_in_progress(self):
        self.checks("raise SystemExit(7)")
        self.assertEqual(verification.verify(self.root), 1)
        text = (self.root / "docs/progress.md").read_text(encoding="utf-8")
        self.assertIn("| unit | FAIL | 7 |", text)
        self.assertIn("| acceptance | NOT_RUN |", text)
        self.assertIn(self.receipt()["run_id"], text)
        events = sorted((self.root / ".harness/work/reporting/events").glob("*.json"))
        before = {path.name: path.read_bytes() for path in events}
        self.checks()
        self.assertEqual(verification.verify(self.root), 0)
        self.assertEqual(before, {name: (events[0].parent / name).read_bytes() for name in before})
        self.assertIn("FAIL", (self.root / "docs/progress.md").read_text(encoding="utf-8"))

    def test_verify_records_checks_without_rescoring_or_rerunning_review(self):
        rows = [{"criterion_id": criterion["id"], "status": "UNVERIFIED", "reason": "Not exercised.",
                 "evidence_refs": []}
                for axis in verification.reports.load_criteria(self.root)["axes"]
                for criterion in axis["criteria"]]
        score = verification.reports.score_review(self.root, rows, {})
        verification.reports.append_event(self.root, {"kind": "review", "status": "PASS",
            "scope": "fake-review", "data": {"review": score}})
        with mock.patch.object(verification.reports, "score_review",
                               side_effect=AssertionError("verification must not rescore")):
            self.assertEqual(verification.verify(self.root), 0)
            self.assertEqual(verification.status(self.root), 0)
        events = [verification.read_json(path) for path in
                  sorted((self.root / ".harness/work/reporting/events").glob("*.json"))]
        self.assertEqual(sum("review" in event["data"] for event in events), 1)
        self.assertNotIn("오래됨", (self.root / "docs/review-score.md").read_text(encoding="utf-8").split("## 리뷰 이력")[0])

    def test_verify_alone_invalidates_damaged_review_evidence_after_pass_or_failure(self):
        for code, expected in (("print('passed')", 0), ("raise SystemExit(7)", 1)):
            with self.subTest(expected=expected):
                self.checks(code)
                proof = self.write(".harness/work/review-evidence.txt", "Preserved review input.\n").resolve()
                rows = [{"criterion_id": item["id"], "status": "UNVERIFIED", "reason": "Not exercised.",
                         "evidence_refs": []}
                        for axis in verification.reports.load_criteria(self.root)["axes"] for item in axis["criteria"]]
                rows[0].update(status="PASS", reason="Inspected the preserved review input.",
                               evidence_refs=["file:review-input"])
                evidence = {"file:review-input": verification.reports.file_evidence(self.root, proof)}
                score = verification.reports.score_review(self.root, rows, evidence)
                verification.reports.append_event(self.root, {"kind": "review", "status": "PASS",
                    "scope": "fake-review", "data": {"review": score}})
                proof.write_text("Damaged archived input.\n", encoding="utf-8")
                with mock.patch.object(verification.reports, "score_review",
                                       side_effect=AssertionError("verification must not rescore")):
                    self.assertEqual(verification.verify(self.root), expected)
                self.assertEqual(self.receipt()["passed"], expected == 0)
                self.assertIn("점수 미산정", (self.root / "docs/review-score.md").read_text(encoding="utf-8"))
                self.assertEqual(verification.status(self.root), expected)

    def test_boundary_edits_invalidate_prior_receipt_even_when_gitignored(self):
        self.write("reference/rules.md", "Original reference requirement.\n")
        ready = answered_boundary(self.root, references=["reference/rules.md"])
        contract = verification.read_json(self.root / ".harness/acceptance.json")
        contract["boundary_tests"] = {"Q-001": ["fixture.required"]}
        verification.write_json(self.root / ".harness/acceptance.json", contract)
        self.write(".gitignore", ".harness/\n*.md\nreference/\n__pycache__/\n")
        self.assertEqual(verification.verify(self.root), 0, self.output.getvalue())
        for path in ready["protected_files"]:
            with self.subTest(path=path):
                original = path.read_bytes()
                path.write_bytes(original + b"\nchanged")
                self.assertEqual(verification.status(self.root), 1)
                path.write_bytes(original)
                self.assertEqual(verification.status(self.root), 0)
        verification.boundary.submit_answer(self.root, "Q-001", "Accept negative inputs instead.")
        self.assertEqual(verification.status(self.root), 1)
        with mock.patch.object(verification, "run_check", side_effect=AssertionError("must not execute")):
            self.assertEqual(verification.verify(self.root), 1)
        state = verification.boundary.load_state(self.root)
        verification.boundary.complete_analysis(self.root, state, {
            "version": 1, "questions": [], "unresolved": [], "references": ["reference/rules.md"]})
        self.assertEqual(verification.status(self.root), 1)
        self.assertEqual(verification.verify(self.root), 0)
        self.assertEqual(verification.status(self.root), 0)

    def test_boundary_input_changed_during_check_cannot_pass(self):
        self.checks("from pathlib import Path; Path('SPEC.md').write_text('different decision')")
        self.assertEqual(verification.verify(self.root), 1)
        self.assertFalse(self.receipt()["passed"])

    def test_selecting_another_spec_invalidates_boundary_and_receipt(self):
        self.write("automation/codex-loop/config.json", json.dumps({"spec": "SPEC.md"}))
        self.write("OTHER.md", "Another specification.\n")
        self.assertEqual(verification.verify(self.root), 0)
        self.write("automation/codex-loop/config.json", json.dumps({"spec": "OTHER.md"}))
        self.assertEqual(verification.status(self.root), 1)
        with mock.patch.object(verification, "run_check", side_effect=AssertionError("must not execute")):
            self.assertEqual(verification.verify(self.root), 1)

    def test_source_add_modify_delete_and_checks_change_make_receipt_stale(self):
        for mutate in (
            lambda: self.write("app.py", "value = 2"),
            lambda: self.write("new.py", "new = 1"),
            lambda: (self.root / "app.py").unlink(),
            lambda: self.checks("print('different command')"),
        ):
            self.assertEqual(verification.verify(self.root), 0)
            mutate()
            self.assertEqual(verification.status(self.root), 1)

    def test_tracked_deleted_file_is_in_fingerprint(self):
        subprocess.run(["git", "-C", str(self.root), "add", "app.py"], check=True, capture_output=True)
        before = verification.fingerprint(self.root)
        (self.root / "app.py").unlink()
        deleted = verification.fingerprint(self.root)
        subprocess.run(["git", "-C", str(self.root), "rm", "--cached", "app.py"], check=True, capture_output=True)
        absent = verification.fingerprint(self.root)
        self.assertNotEqual(before, deleted)
        self.assertNotEqual(deleted, absent)

    def test_failure_and_invalid_config_invalidate_prior_pass(self):
        self.assertEqual(verification.verify(self.root), 0)
        self.checks("raise SystemExit(7)")
        self.assertEqual(verification.verify(self.root), 1)
        self.assertEqual(self.receipt()["results"][0]["exit_code"], 7)
        self.assertFalse(self.receipt()["passed"])
        self.checks()
        self.assertEqual(verification.verify(self.root), 0)
        self.write(".harness/checks.json", '{"checks": []}')
        self.assertEqual(verification.verify(self.root), 1)
        self.assertFalse(self.receipt()["passed"])
        self.assertEqual(verification.status(self.root), 1)

    def test_mid_check_source_mutation_cannot_pass(self):
        self.checks("from pathlib import Path; Path('app.py').write_text('value = 9')")
        self.assertEqual(verification.verify(self.root), 1)
        self.assertEqual(self.receipt()["results"][0]["exit_code"], 0)
        self.assertFalse(self.receipt()["passed"])

    def test_explicit_ignored_inputs_are_hashed_and_missing_or_escape_rejected(self):
        self.write("ignored/data.csv", "1,2")
        self.checks(inputs=["ignored/data.csv"])
        self.assertEqual(verification.verify(self.root), 0)
        self.write("ignored/data.csv", "3,4")
        self.assertEqual(verification.status(self.root), 1)
        for value in ("missing.csv", "../outside.csv", "work", ".git"):
            self.checks(inputs=[value])
            with self.assertRaises(ValueError):
                verification.fingerprint(self.root)

    def test_ignored_core_documents_and_check_config_are_still_hashed(self):
        self.write(".gitignore", ".harness/\nREQUIREMENTS.md\n")
        self.write("REQUIREMENTS.md", "R1")
        before = verification.fingerprint(self.root)
        self.write("REQUIREMENTS.md", "R2")
        self.assertNotEqual(before, verification.fingerprint(self.root))
        before = verification.fingerprint(self.root)
        self.checks("print('updated')")
        self.assertNotEqual(before, verification.fingerprint(self.root))

    def test_nested_git_root_and_git_error_are_not_success(self):
        nested = self.root / "nested"
        nested.mkdir()
        ready_boundary(nested)
        with self.assertRaises(ValueError):
            verification.fingerprint(nested)
        outside = Path(self.temp.name) / "not-a-repo"
        outside.mkdir()
        ready_boundary(outside)
        with self.assertRaises(subprocess.CalledProcessError):
            verification.fingerprint(outside)

    def test_invalid_receipts_fail_closed(self):
        for text in ("not JSON", "[]", '{"passed": true}', "null"):
            self.assertEqual(verification.verify(self.root), 0)
            self.receipt_paths()[-1].write_text(text, encoding="utf-8")
            self.assertEqual(verification.status(self.root), 1)

    def test_shell_strings_and_invalid_timeout_are_rejected(self):
        for command, timeout in (("echo ok", 1), ([""], 1), (["echo"], True), (["echo"], 0)):
            verification.write_json(self.root / ".harness/checks.json", {
                "checks": [{"name": "bad", "command": command, "timeout_seconds": timeout}]})
            self.assertEqual(verification.verify(self.root), 1)
            self.assertFalse(self.receipt()["passed"])

    def test_unavailable_command_is_failure(self):
        verification.write_json(self.root / ".harness/checks.json", {
            "checks": [{"name": "missing", "command": ["harness-no-such-executable-12093"]}]})
        self.assertEqual(verification.verify(self.root), 1)
        self.assertFalse(self.receipt()["passed"])

    @unittest.skipUnless(os.name == "nt", "Windows batch launch guard")
    def test_windows_batch_shims_are_rejected_before_launch(self):
        shim = self.write("tools/unsafe-check.cmd", "@echo off\necho launched>batch-ran.txt\n")
        batch = self.write("tools/unsafe-batch.BAT", "@echo off\necho launched>batch-ran.txt\n")
        self.assertEqual(verification.verify(self.root), 0)
        with mock.patch.dict(os.environ, {"PATH": str(shim.parent) + os.pathsep + os.environ.get("PATH", "")}):
            for command in ([str(shim)], [str(batch)], ["unsafe-check"], [str(shim.with_suffix(""))], ["tools/unsafe-check"]):
                with self.subTest(command=command):
                    with self.assertRaisesRegex(ValueError, "native executable or an explicitly chosen shell"):
                        verification.start_process(command, cwd=self.root, shell=False)
                    verification.write_json(self.root / ".harness/checks.json", {
                        "checks": [{"name": "batch", "command": command}]})
                    self.assertEqual(verification.verify(self.root), 1)
                    self.assertFalse(self.receipt()["passed"])
                    self.assertFalse((self.root / "batch-ran.txt").exists())

    def child_check(self, wait):
        # The child announces readiness while holding a socket; its closure proves reaping.
        import socket
        listener = socket.socket()
        listener.bind(("127.0.0.1", 0))
        listener.listen()
        listener.settimeout(60)
        self.addCleanup(listener.close)
        port = listener.getsockname()[1]
        child = ("import socket,time; s=socket.create_connection(('127.0.0.1', " + str(port)
                 + ")); s.sendall(b'ready'); time.sleep(120)")
        release = self.root / ".harness/work/parent-release"
        code = ("import subprocess,sys,socket,time; "
                "p=subprocess.Popen([sys.executable,'-c'," + repr(child) + "]); "
                + ("time.sleep(120)" if wait else
                   "from pathlib import Path\nwhile not Path(" + repr(str(release)) + ").exists(): time.sleep(.01)"))
        self.checks(code)
        original = verification.start_process
        ready = threading.Event()
        connection = []
        def start(*args, **kwargs):
            process = original(*args, **kwargs)
            if args[0][-1] == "acceptance_checker.py":
                return process
            try:
                client, _ = listener.accept()
                client.settimeout(30)
                self.addCleanup(client.close)
                self.assertEqual(client.recv(5), b"ready")
                connection.append(client)
                ready.set()
                if not wait:
                    release.write_text("ready", encoding="utf-8")
            except BaseException:
                verification.stop_process(process)
                raise
            return process
        if wait:
            config = verification.read_json(self.root / ".harness/checks.json")
            config["checks"][0]["timeout_seconds"] = 0.2
            verification.write_json(self.root / ".harness/checks.json", config)
        with mock.patch.object(verification, "start_process", side_effect=start):
            result = verification.verify(self.root)
        self.assertTrue(ready.is_set())
        connection[0].settimeout(5)
        try:
            self.assertEqual(connection[0].recv(1), b"", "check left a child running")
        except ConnectionResetError:
            pass  # Windows reports forcibly closed child sockets as RST instead of EOF.
        return result

    def test_timeout_stops_spawned_child(self):
        self.assertEqual(self.child_check(wait=True), 1)
        self.assertEqual(self.receipt()["results"][0]["status"], "timed_out")

    def test_successful_check_stops_spawned_child(self):
        self.assertEqual(self.child_check(wait=False), 0)
        self.assertEqual(verification.status(self.root), 0)

    def test_history_is_immutable_across_failed_and_successful_attempts(self):
        self.checks("raise SystemExit(7)")
        self.assertEqual(verification.verify(self.root), 1)
        first = self.receipt_paths()[0]
        first_bytes = first.read_bytes()
        first_log = (self.root / self.receipt()["results"][0]["log"]).read_bytes()
        self.checks()
        self.assertEqual(verification.verify(self.root), 0)
        self.assertEqual(len(self.receipt_paths()), 2)
        self.assertEqual(first.read_bytes(), first_bytes)
        self.assertEqual((self.root / verification.read_json(first)["results"][0]["log"]).read_bytes(), first_log)
        self.assertFalse((self.root / ".harness/work/verification.json").exists())

    def test_results_only_blocks_preserve_status_but_other_text_does_not(self):
        for name in ("HANDOFF.md", "PLAN.md"):
            with self.subTest(name=name):
                self.write(name, "Rule A\n<!-- harness:results:start -->\nold\n<!-- harness:results:end -->\nFooter\n")
                self.assertEqual(verification.verify(self.root), 0)
                self.write(name, "Rule A\n<!-- harness:results:start -->\nnew status/time\n<!-- harness:results:end -->\nFooter\n")
                with mock.patch.object(verification, "run_check", side_effect=AssertionError("status reran checks")):
                    self.assertEqual(verification.status(self.root), 0)
                self.write(name, "Rule B\n<!-- harness:results:start -->\nnew status/time\n<!-- harness:results:end -->\nFooter\n")
                self.assertEqual(verification.status(self.root), 1)

    def test_missing_results_document_and_malformed_markers_fail_closed(self):
        for text in ("<!-- harness:results:start -->", "<!-- harness:results:end -->",
                     "<!-- harness:results:end --><!-- harness:results:start -->",
                     "<!-- harness:results:start --><!-- harness:results:end -->" * 2):
            self.write("PLAN.md", text)
            self.assertEqual(verification.verify(self.root), 1)
            self.assertEqual(verification.status(self.root), 1)
        self.write("PLAN.md", "<!-- harness:results:start -->\nok\n<!-- harness:results:end -->\n")
        self.assertEqual(verification.verify(self.root), 0)
        (self.root / "PLAN.md").unlink()
        self.assertEqual(verification.status(self.root), 1)

    def test_specs_readme_and_runner_tests_are_hashed_even_when_ignored(self):
        names = ("INTERVIEW.md", "FUNCTIONAL_SPEC.md", "README.md", ".harness/tests/test_other.py",
                 ".harness/review_instructions.md", ".harness/review.schema.json", ".codex/agents/kty-reviewer.toml")
        self.write(".gitignore", ".harness/\n.codex/\n*.md\n")
        for name in names:
            with self.subTest(name=name):
                self.write(name, "one")
                self.assertEqual(verification.verify(self.root), 0)
                self.write(name, "two")
                self.assertEqual(verification.status(self.root), 1)

    def test_log_deletion_and_tampering_invalidate_status(self):
        for mutation in (lambda p: p.unlink(), lambda p: p.write_text("tampered")):
            self.assertEqual(verification.verify(self.root), 0)
            mutation(self.root / self.receipt()["results"][0]["log"])
            self.assertEqual(verification.status(self.root), 1)

    def test_failure_leaves_remaining_checks_explicitly_not_run(self):
        config = {"checks": [
            {"name": "first", "command": ["{python}", "-c", "raise SystemExit(7)"]},
            {"name": "second", "command": ["{python}", "-c", "print('must not run')"]}]}
        verification.write_json(self.root / ".harness/checks.json", config)
        self.assertEqual(verification.verify(self.root), 1)
        self.assertEqual([r["status"] for r in self.receipt()["results"]], ["failed", "not_run", "not_run"])
        self.assertIsNone(self.receipt()["results"][1]["exit_code"])

    def test_interruption_records_failure_and_preserves_older_pass(self):
        self.assertEqual(verification.verify(self.root), 0)
        old = self.receipt_paths()[0].read_bytes()
        with mock.patch.object(verification, "run_check", side_effect=KeyboardInterrupt):
            self.assertEqual(verification.verify(self.root), 1)
        self.assertEqual(self.receipt()["status"], "interrupted")
        self.assertEqual(self.receipt_paths()[0].read_bytes(), old)
        self.assertEqual(verification.status(self.root), 1)

    def test_concurrent_runs_keep_logs_and_latest_start_failure_visible(self):
        entered, release = threading.Event(), threading.Event()
        answers = []
        original = verification.run_check
        def check(root, config, logfile, on_start=None):
            if config["_acceptance"]:
                return original(root, config, logfile, on_start=on_start)
            if on_start:
                on_start(mock.Mock(pid=os.getpid()))
            logfile.write_text(threading.current_thread().name, encoding="utf-8")
            if threading.current_thread().name == "older-success":
                entered.set()
                self.assertTrue(release.wait(60))
                return 0
            return 7
        with mock.patch.object(verification, "run_check", side_effect=check):
            worker = threading.Thread(target=lambda: answers.append(verification.verify(self.root)), name="older-success")
            worker.start()
            try:
                self.assertTrue(entered.wait(60))
                self.assertEqual(verification.verify(self.root), 1)
                self.assertEqual(verification.status(self.root), 1)
            finally:
                release.set()
                worker.join(60)
        self.assertFalse(worker.is_alive())
        self.assertEqual(answers, [0])
        receipts = [verification.read_json(p) for p in self.receipt_paths()]
        self.assertEqual([r["passed"] for r in receipts], [True, False])
        self.assertNotEqual(receipts[0]["results"][0]["log"], receipts[1]["results"][0]["log"])
        self.assertEqual(verification.status(self.root), 1)

    def test_older_running_attempt_is_not_hidden_by_new_success(self):
        entered, release = threading.Event(), threading.Event()
        original = verification.run_check
        def check(root, config, logfile, on_start=None):
            if config["_acceptance"]:
                return original(root, config, logfile, on_start=on_start)
            if on_start:
                on_start(mock.Mock(pid=os.getpid()))
            logfile.write_text("ok", encoding="utf-8")
            if threading.current_thread().name == "unfinished":
                entered.set()
                self.assertTrue(release.wait(60))
            return 0
        with mock.patch.object(verification, "run_check", side_effect=check):
            worker = threading.Thread(target=verification.verify, args=(self.root,), name="unfinished")
            worker.start()
            try:
                self.assertTrue(entered.wait(60))
                self.assertEqual(verification.verify(self.root), 0)
                self.assertEqual(verification.status(self.root), 1)
                self.assertIn("미완료", self.output.getvalue())
            finally:
                release.set()
                worker.join(60)
        self.assertEqual(verification.status(self.root), 0)

    def test_attempt_is_written_before_invalid_configuration_is_loaded(self):
        self.write(".harness/checks.json", "{bad json")
        self.assertEqual(verification.verify(self.root), 1)
        receipt = self.receipt()
        self.assertEqual(receipt["configuration"]["status"], "invalid")
        self.assertEqual(receipt["status"], "failed")
        self.assertIsNotNone(receipt["started_at"])
        self.assertIsNotNone(receipt["finished_at"])

    def test_hard_kill_owner_cannot_hide_a_live_check_or_child(self):
        import socket
        listener = socket.socket()
        self.addCleanup(listener.close)
        listener.bind(("127.0.0.1", 0))
        listener.listen()
        listener.settimeout(60)
        child = ("import os,socket,time; "
                 "s=socket.create_connection(('127.0.0.1'," + str(listener.getsockname()[1]) + ")); "
                 "s.sendall((str(os.getpid())+' '+str(os.getppid())+'\\n').encode()); time.sleep(120)")
        check_code = ("import subprocess,sys,time; from pathlib import Path\n"
                      "if not Path('.harness/work/recovery').exists():\n"
                      " subprocess.Popen([sys.executable,'-c'," + repr(child) + "])\n"
                      " time.sleep(120)\n")
        self.checks(check_code)
        code = ("import importlib.util; from pathlib import Path\n"
                "spec=importlib.util.spec_from_file_location('verification'," + repr(str(SOURCE / ".harness/verification.py")) + ")\n"
                "v=importlib.util.module_from_spec(spec); spec.loader.exec_module(v)\n"
                "v.verify(Path(" + repr(str(self.root)) + "))\n")
        # Windows venv redirectors have a different PID from the verifier they launch.
        executable = getattr(sys, "_base_executable", sys.executable)
        owner = subprocess.Popen([executable, "-c", code], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        child_pids = []
        def cleanup_children():
            for pid in child_pids:
                try:
                    os.kill(pid, signal.SIGTERM)
                except OSError:
                    pass
        self.addCleanup(cleanup_children)
        try:
            client, _ = listener.accept()
            self.addCleanup(client.close)
            client.settimeout(10)
            hello = b""
            while not hello.endswith(b"\n"):
                hello += client.recv(64)
            child_pids.extend(int(value) for value in hello.split())
        finally:
            owner.kill()
            owner.wait(timeout=10)
        self.assertEqual(self.receipt()["owner_pid"], owner.pid)
        self.assertEqual(self.receipt()["status"], "running")
        old_path = self.receipt_paths()[0]
        old_bytes = old_path.read_bytes()
        self.assertEqual(verification.status(self.root), 1)
        self.write(".harness/work/recovery", "new checks may finish")
        self.assertEqual(verification.verify(self.root), 0)
        if os.name == "nt":
            client.settimeout(5)
            try:
                self.assertEqual(client.recv(1), b"", "hard-killed verifier left a child running")
            except ConnectionResetError:
                pass
            self.assertEqual(verification.status(self.root), 0)
        else:
            self.assertEqual(verification.status(self.root), 1, "live orphan group was hidden by a newer success")
        self.assertEqual(old_path.read_bytes(), old_bytes)
        self.assertIn("중단된", self.output.getvalue())

    def test_dead_owner_with_unknown_check_process_blocks_new_success(self):
        self.assertEqual(verification.verify(self.root), 0)
        owner = subprocess.Popen([sys.executable, "-c", "pass"])
        owner.wait(timeout=30)
        receipt = self.receipt()
        receipt.update(owner_pid=owner.pid, status="running", passed=False, finished_at=None)
        receipt["results"][0].update(status="running", process_pid=None, finished_at=None)
        old_path = self.receipt_paths()[0]
        verification.write_json(old_path, receipt)
        before = old_path.read_bytes()
        self.assertEqual(verification.verify(self.root), 0)
        self.assertEqual(verification.status(self.root), 1)
        self.assertIn("불명", self.output.getvalue())
        self.assertEqual(old_path.read_bytes(), before)

    def test_inline_result_markers_cannot_hide_business_rules(self):
        for body in ("Rule <!-- harness:results:start -->old<!-- harness:results:end -->\n",
                     "Rule <!-- harness:results:start -->\nold\n<!-- harness:results:end -->\n",
                     "<!-- harness:results:start -->\nold\n<!-- harness:results:end --> Rule\n"):
            with self.subTest(body=body):
                self.write("PLAN.md", body)
                with self.assertRaises(ValueError):
                    verification.fingerprint(self.root)

    def test_dead_owner_with_live_check_blocks_new_success(self):
        self.assertEqual(verification.verify(self.root), 0)
        owner = subprocess.Popen([sys.executable, "-c", "pass"])
        owner.wait(timeout=30)
        check = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(120)"],
                                 start_new_session=os.name != "nt")
        def cleanup():
            if check.poll() is None:
                check.kill()
            check.wait(timeout=10)
        self.addCleanup(cleanup)
        receipt = self.receipt()
        receipt.update(owner_pid=owner.pid, status="running", passed=False, finished_at=None)
        receipt["results"][0].update(status="running", process_pid=check.pid, finished_at=None)
        old_path = self.receipt_paths()[0]
        verification.write_json(old_path, receipt)
        before = old_path.read_bytes()
        self.assertEqual(verification.verify(self.root), 0)
        self.assertIsNone(check.poll())
        self.assertEqual(verification.status(self.root), 1)
        self.assertIn("프로세스가 남아", self.output.getvalue())
        self.assertEqual(old_path.read_bytes(), before)

    def test_new_success_recovers_after_old_receipt_corruption(self):
        self.assertEqual(verification.verify(self.root), 0)
        old_path = self.receipt_paths()[0]
        old_path.write_text("broken receipt", encoding="utf-8")
        self.assertEqual(verification.status(self.root), 1)
        self.assertEqual(verification.verify(self.root), 0)
        self.assertEqual(verification.status(self.root), 0)
        self.assertEqual(old_path.read_text(encoding="utf-8"), "broken receipt")
        self.assertIn("손상된 이전", self.output.getvalue())

    @unittest.skipIf(os.name == "nt", "Windows executable mode is not a POSIX permission bit")
    def test_executable_mode_is_hashed(self):
        path = self.root / "app.py"
        before = verification.fingerprint(self.root)
        path.chmod(0o755)
        self.assertNotEqual(before, verification.fingerprint(self.root))


if __name__ == "__main__":
    unittest.main()
