import copy
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest import mock

import api_fixture

BASE = Path(__file__).resolve().parents[1]
loader = importlib.util.spec_from_file_location("api_reports_under_test", BASE / "reports.py")
reports = importlib.util.module_from_spec(loader)
loader.loader.exec_module(reports)


class APIReportingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="api-reporting-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        (self.root / ".harness").mkdir()
        shutil.copyfile(BASE / "review_criteria.json", self.root / ".harness/review_criteria.json")
        api_fixture.configure(self.root)
        reports.initialize(self.root)
        self.value = api_fixture.result(self.root, reports)

    def rows(self):
        return [{"criterion_id": item["id"], "status": "UNVERIFIED", "reason": "Not executed by reviewer", "evidence_refs": []}
                for axis in reports.load_criteria(self.root)["axes"] for item in axis["criteria"]]

    def test_protocol_rejects_zero_skip_missing_duplicate_ids_versions_and_forged_counts(self):
        variants = []
        for field, value in (("collected", 0), ("passed", True), ("failed", -1), ("skipped", 1)):
            changed = copy.deepcopy(self.value)
            changed["checks"][0]["counts"][field] = value
            variants.append(changed)
        for key, value in (("schema", "wrong"), ("checks", self.value["checks"][:1]),
                           ("checks", [self.value["checks"][0]] * 2), ("required_check_ids", []),
                           ("tools", {}), ("source_hash", "0" * 64), ("scenario_files", []), ("config_digest", "wrong")):
            changed = copy.deepcopy(self.value)
            changed[key] = value
            variants.append(changed)
        for changed in variants:
            with self.subTest(value=changed):
                with self.assertRaises(reports.ReportError):
                    reports.validate_api_result(self.root, changed, 0)
        with self.assertRaises(reports.ReportError):
            reports.validate_api_result(self.root, self.value, True)
        with self.assertRaises(reports.ReportError):
            reports.decode('{"schema":"harness-api-review/v1","schema":"harness-api-review/v1"}')

    def test_all_skipped_and_omitted_fixed_hurl_scenarios_are_not_success(self):
        value = copy.deepcopy(self.value)
        value["checks"][0]["counts"] = dict(collected=1, passed=0, failed=0, skipped=1)
        value["checks"][0]["status"] = "SKIP"
        value["checks"][0]["exit_code"] = None
        with self.assertRaises(reports.ReportError):
            reports.validate_api_result(self.root, value, 0)
        (self.root / "api-tests/second.hurl").write_text("GET http://127.0.0.1/second", encoding="utf-8")
        config = self.root / ".harness/api-review.json"
        config.write_text(json.dumps({"scenarios": ["api-tests/basic.hurl", "api-tests/second.hurl"]}), encoding="utf-8")
        value = api_fixture.result(self.root, reports)
        with self.assertRaisesRegex(reports.ReportError, "Not all fixed"):
            reports.validate_api_result(self.root, value, 0)

    def test_fixed_scenarios_cannot_hide_in_any_source_digest_exclusion(self):
        for name in sorted(reports.SOURCE_EXCLUDED_DIRS):
            with self.subTest(directory=name):
                scenario = self.root / "api-tests" / name / "hidden.hurl"
                scenario.parent.mkdir(exist_ok=True)
                scenario.write_text("GET {{base_url}}/hidden", encoding="utf-8")
                config = self.root / ".harness/api-review.json"
                config.write_text(json.dumps({"scenarios": [scenario.relative_to(self.root).as_posix()]}), encoding="utf-8")
                value = api_fixture.result(self.root, reports)
                before = reports.source_digest(self.root)
                scenario.write_text("GET {{base_url}}/changed", encoding="utf-8")
                self.assertEqual(reports.source_digest(self.root), before)
                with self.assertRaisesRegex(reports.ReportError, "runtime/ignored"):
                    reports.validate_api_result(self.root, value, 0)
                alias = "api-tests/" + name.upper() + "/hidden.hurl"
                config.write_text(json.dumps({"scenarios": [alias]}), encoding="utf-8")
                with self.assertRaisesRegex(reports.ReportError, "runtime/ignored"):
                    reports.validate_api_result(self.root, api_fixture.result(self.root, reports), 0)

    def test_paths_and_all_raw_artifacts_are_validated_before_using_prior_evidence(self):
        for name in ("../outside.log", ".harness/work/api-review/../../fake.log", "api-tests/basic.hurl"):
            value = copy.deepcopy(self.value)
            value["checks"][0]["artifacts"][0]["path"] = name
            with self.assertRaises(reports.ReportError):
                reports.validate_api_result(self.root, value, 0)
        api_fixture.record(self.root, reports, self.value)
        self.assertEqual(set(reports.current_api_evidence(self.root)["evidence"]), {"api-check:schemathesis", "api-check:hurl"})
        path = self.root / self.value["checks"][0]["artifacts"][-1]["path"]
        path.write_text("modified XML", encoding="utf-8")
        self.assertIsNone(reports.current_api_evidence(self.root)["context"])
        reports.refresh(self.root)
        self.assertIn("API 근거 상태: 미검증 / 무효", (self.root / "docs/review-score.md").read_text(encoding="utf-8"))

    def test_prior_api_has_provenance_does_not_rescore_and_source_change_makes_it_stale(self):
        score = reports.score_review(self.root, self.rows(), {})
        reports.append_event(self.root, {"kind": "review", "status": "PASS", "data": {"review": score}})
        api_fixture.record(self.root, reports, self.value)
        prior = reports.current_api_evidence(self.root)
        self.assertIn("not commands executed by this reviewer", prior["context"]["provenance"])
        with mock.patch.object(reports, "score_review", side_effect=AssertionError("must not rescore")):
            reports.refresh(self.root)
        state, events = reports._read(self.root)
        self.assertEqual([event["data"]["review"] for event in events if "review" in event["data"]], [score])
        text = (self.root / "docs/review-score.md").read_text(encoding="utf-8")
        self.assertIn("기존 독립 리뷰 점수에 자동 반영하거나 재채점하지 않습니다", text)
        (self.root / "implementation.py").write_text("changed = True", encoding="utf-8")
        reports.refresh(self.root)
        self.assertIsNone(reports.current_api_evidence(self.root)["context"])
        self.assertIn("오래됨", (self.root / "docs/progress.md").read_text(encoding="utf-8"))

    def test_api_score_dependency_damage_invalidates_existing_score_without_new_review(self):
        api_fixture.record(self.root, reports, self.value)
        catalog = reports.current_api_evidence(self.root)["evidence"]
        rows = self.rows()
        next(row for row in rows if row["criterion_id"] == "TEST01").update(
            status="PASS", reason="Prior controller API checked this condition", evidence_refs=["api-check:schemathesis"])
        score = reports.score_review(self.root, rows, catalog)
        reports.append_event(self.root, {"kind": "review", "status": "PASS", "data": {"review": score}})
        (self.root / self.value["checks"][1]["artifacts"][-1]["path"]).unlink()
        with mock.patch.object(reports, "score_review", side_effect=AssertionError("must not rescore")):
            reports.refresh(self.root)
        text = (self.root / "docs/review-score.md").read_text(encoding="utf-8")
        self.assertIn("점수 미산정", text)
        self.assertIn("API 근거 상태: 미검증 / 무효", text)

    def test_later_failed_or_not_run_api_attempt_cannot_reuse_older_pass(self):
        api_fixture.record(self.root, reports, self.value)
        reports.append_event(self.root, {"kind": "api_verification", "status": "NOT_RUN", "scope": "api-check",
                                      "data": {"api_review": None, "api_error": "Earlier required check failed"}})
        self.assertEqual(reports.current_api_evidence(self.root), {"context": None, "evidence": {}})


if __name__ == "__main__":
    unittest.main()
