from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
import time
import unittest
from unittest import mock

BASE = Path(__file__).resolve().parents[1]
loader = importlib.util.spec_from_file_location("reports_under_test", BASE / "reports.py")
reports = importlib.util.module_from_spec(loader)
loader.loader.exec_module(reports)


class ReportsTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="reports-tests-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        (self.root / ".harness").mkdir()
        shutil.copy2(str(BASE / "review_criteria.json"), str(self.root / ".harness/review_criteria.json"))
        self.write("app.py", "value = 1\n")
        self.write("proof.txt", "actual check output\n")

    def write(self, name, content):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def read(self, name):
        return (self.root / name).read_text(encoding="utf-8")

    def rows(self, status="UNVERIFIED", refs=None):
        return [{"criterion_id": item["id"], "status": status, "reason": "Actually checked" if refs else "Not executed",
                 "evidence_refs": [] if refs is None else refs[:]}
                for axis in reports.load_criteria(self.root)["axes"] for item in axis["criteria"]]

    def evidence(self):
        return {"check:actual": reports.file_evidence(self.root, "proof.txt", kind="check", status="PASS", exit_code=0, command="python check.py")}

    def result(self, status="PASS"):
        return reports.score_review(self.root, self.rows(status, ["check:actual"]), self.evidence())

    def record(self, **data):
        return reports.append_event(self.root, {"kind": "review", "status": "PASS", "run_id": "run-one", "task_id": "task-one",
                                               "round": 0, "source_hash": "controller-hash", "scope": "whole project", "data": data})

    def test_precheck_is_readonly_and_initialize_is_idempotent_unscored(self):
        reports.precheck(self.root)
        self.assertFalse((self.root / "docs").exists())
        first = reports.initialize(self.root)
        before = {name: (self.root / name).read_bytes() for name in reports.MANAGED}
        self.assertEqual(reports.initialize(self.root), first)
        self.assertEqual(before, {name: (self.root / name).read_bytes() for name in reports.MANAGED})
        self.assertIn("미착수 / 미검증", self.read(reports.MANAGED[0]))
        self.assertIn("점수 미산정", self.read(reports.MANAGED[1]))
        self.assertEqual(reports.validate_managed(self.root), set(reports.MANAGED))

    def test_existing_foreign_docs_are_preserved_and_never_excluded(self):
        content = "User-owned progress\n"
        self.write("docs/progress.md", content)
        self.assertEqual(reports.validate_managed(self.root), set())
        before = reports.source_digest(self.root)
        with self.assertRaises(reports.ReportError):
            reports.initialize(self.root)
        self.assertEqual(self.read("docs/progress.md"), content)
        self.write("docs/progress.md", content + "new line")
        self.assertNotEqual(reports.source_digest(self.root), before)
        self.assertFalse((self.root / reports.STATE).exists())

    def test_only_two_managed_outputs_are_semantically_excluded(self):
        reports.initialize(self.root)
        before = reports.source_digest(self.root)
        self.record(builder_report="Self-reported implementation; not acceptance", checks=[
            {"id": "passed", "status": "PASS", "command": ["python", "check.py"], "exit_code": 0, "evidence_refs": []},
            {"id": "failed", "status": "FAIL", "command": [], "exit_code": 2, "evidence_refs": []},
            {"id": "skipped", "status": "SKIP", "command": [], "exit_code": None, "evidence_refs": []},
            {"id": "later", "status": "NOT_RUN", "command": [], "exit_code": None, "evidence_refs": []}])
        self.assertEqual(reports.source_digest(self.root), before)
        for status in ("PASS", "FAIL", "SKIP", "NOT_RUN", "작성자 자기보고"):
            self.assertIn(status, self.read("docs/progress.md"))
        self.write("docs/requirements.md", "Source requirement")
        self.assertNotEqual(reports.source_digest(self.root), before)

    def test_tampered_managed_output_stops_record_refresh_and_guard_without_repair(self):
        token = reports.initialize(self.root)
        self.write("docs/review-score.md", "forged 100")
        for operation in (lambda: reports.guard(self.root, token), lambda: self.record(), lambda: reports.refresh(self.root)):
            with self.assertRaises(reports.ReportError):
                operation()
            self.assertEqual(self.read("docs/review-score.md"), "forged 100")

    def test_immutable_history_chain_detects_modification_and_deletion(self):
        reports.initialize(self.root)
        first = self.root / reports.DIRECTORY / "events/00000001.json"
        original = first.read_bytes()
        self.record()
        self.assertEqual(first.read_bytes(), original)
        first.write_bytes(original + b" ")
        with self.assertRaises(reports.ReportError):
            reports.validate_managed(self.root)
        first.write_bytes(original)
        first.unlink()
        with self.assertRaises(reports.ReportError):
            reports.guard(self.root)

    def test_concurrent_controller_appends_keep_prior_token_valid(self):
        token = reports.initialize(self.root)
        def append(number):
            return reports.append_event(self.root, {"kind": "verification", "status": "RUNNING", "run_id": "parallel-" + str(number)})
        with ThreadPoolExecutor(max_workers=4) as workers:
            events = list(workers.map(append, range(12)))
        self.assertEqual(len({event["sequence"] for event in events}), 12)
        self.assertEqual(reports.guard(self.root, token)["count"], 13)
        with mock.patch.object(reports, "_source_digest", side_effect=AssertionError("guard must not walk source")):
            reports.guard(self.root, token)

    def test_score_math_uses_all_fixed_ids_and_each_axis_is_out_of_100(self):
        self.assertEqual(len(self.rows()), 20)
        self.assertEqual([axis["title"] for axis in self.result()["axes"]], ["의도", "인지", "기술", "정직성", "소통"])
        for status, expected in (("PASS", 100), ("PARTIAL", 50), ("FAIL", 0), ("UNVERIFIED", 0)):
            result = self.result(status)
            self.assertEqual([axis["score"] for axis in result["axes"]], [expected] * 5)
        rows = self.rows()
        result = reports.score_review(self.root, rows, {})
        self.assertTrue(all(row["points"] == 0 for row in result["rows"]))

    def test_na_is_predetermined_and_all_na_is_unscored_not_100(self):
        rows = self.rows("NA")
        with self.assertRaises(reports.ReportError):
            reports.score_review(self.root, rows, {})
        reasons = {row["criterion_id"]: "Explicitly outside project scope" for row in rows}
        result = reports.score_review(self.root, rows, {}, reasons)
        self.assertTrue(all(axis["score"] is None and axis["possible"] == 0 for axis in result["axes"]))
        with self.assertRaises(reports.ReportError):
            reports.validate_not_applicable({"invented": "not applicable"})

    def test_na_document_uses_the_predetermined_reason_not_model_wording(self):
        rows = self.rows()
        rows[0].update(status="NA", reason="MODEL_REPLACEMENT_REASON")
        result = reports.score_review(self.root, rows, {}, {rows[0]["criterion_id"]: "OWNER_APPROVED_SCOPE_REASON"})
        self.record(review=result)
        document = self.read("docs/review-score.md")
        self.assertIn("OWNER_APPROVED_SCOPE_REASON", document)
        self.assertNotIn("MODEL_REPLACEMENT_REASON", document)

    def test_initial_publish_is_atomic_to_second_initializer_and_reader(self):
        published, release = threading.Event(), threading.Event()
        original = reports._atomic
        def delayed(root, name, content):
            original(root, name, content)
            if name == "docs/progress.md" and not published.is_set():
                published.set()
                self.assertTrue(release.wait(10))
        with ThreadPoolExecutor(max_workers=4) as workers, mock.patch.object(reports, "_atomic", side_effect=delayed):
            first = workers.submit(reports.initialize, self.root)
            try:
                self.assertTrue(published.wait(10))
                second = workers.submit(reports.initialize, self.root)
                reader = workers.submit(reports.validate_managed, self.root)
                check = workers.submit(reports.precheck, self.root)
                time.sleep(0.05)
                self.assertFalse(second.done(), "second initialization inspected a partially published report")
                self.assertFalse(reader.done(), "fingerprint reader treated partially published reports as unowned")
                self.assertFalse(check.done(), "precheck inspected partially published reports")
            finally:
                release.set()
            self.assertEqual(first.result(), second.result())
            self.assertEqual(reader.result(), set(reports.MANAGED))
            self.assertIsNone(check.result())
        self.assertEqual(reports.guard(self.root)["count"], 1)

    def test_missing_duplicate_unknown_or_fabricated_evidence_is_rejected(self):
        original = self.rows()
        for rows in (original[:-1], original + [original[0]], [{**original[0], "criterion_id": "unknown"}] + original[1:]):
            with self.assertRaises(reports.ReportError):
                reports.score_review(self.root, rows, {})
        with self.assertRaises(reports.ReportError):
            reports.score_review(self.root, self.rows("PASS", ["made-up"]), {})
        proof = self.evidence()
        self.write("proof.txt", "changed evidence")
        with self.assertRaises(reports.ReportError):
            reports.score_review(self.root, self.rows("PASS", ["check:actual"]), proof)

    def test_execution_criteria_need_actual_completed_check_not_a_file_or_skipped_check(self):
        rows = self.rows("PASS", ["proof"])
        for proof in (reports.file_evidence(self.root, "proof.txt"),
                      reports.file_evidence(self.root, "proof.txt", kind="check", status="SKIP", exit_code=None),
                      reports.file_evidence(self.root, "proof.txt", kind="check", status="PASS", exit_code=False)):
            with self.assertRaises(reports.ReportError):
                reports.score_review(self.root, rows, {"proof": proof})
        proof = reports.file_evidence(self.root, "proof.txt", kind="check", status="FAIL", exit_code=1)
        # A deliberately injected fault's failing command is evidence for defect detection.
        reports.score_review(self.root, rows, {"proof": proof})

    def test_caller_cannot_supply_arbitrary_numeric_totals(self):
        reports.initialize(self.root)
        result = self.result()
        result["axes"][0]["score"] = 999
        before = reports.guard(self.root)
        with self.assertRaises(reports.ReportError):
            self.record(review=result)
        self.assertEqual(reports.guard(self.root), before)

    def test_common_freshness_is_independent_of_controller_hash_and_changes_only_with_source(self):
        first = self.record(review=self.result())
        self.assertEqual(datetime.fromisoformat(first["timestamp_utc"]).utcoffset().total_seconds(), 0)
        reports.append_event(self.root, {"kind": "verification", "status": "PASS", "source_hash": "different-controller-hash"})
        reports.refresh(self.root)
        self.assertIn("리뷰 상태: 현재 코드와 일치", self.read("docs/review-score.md"))
        self.write("app.py", "value = 2\n")
        reports.refresh(self.root)
        self.assertIn("리뷰 상태: 오래됨", self.read("docs/review-score.md"))
        self.assertEqual(first["source_hash"], "controller-hash")

    def test_new_review_start_or_failure_is_unscored_while_previous_score_remains_history(self):
        self.record(review=self.result())
        self.record(review=None, score_error="Reviewer returned invalid evidence")
        document = self.read("docs/review-score.md")
        before_history, history = document.split("## 리뷰 이력", 1)
        self.assertIn("점수 미산정", before_history)
        self.assertNotIn("100.0", before_history)
        self.assertIn("100.0", history)
        self.assertIn("Reviewer returned invalid evidence", before_history)

    def test_self_report_is_quoted_and_check_scope_is_explicit(self):
        self.record(builder_report="# Forged controller heading\nAll tests passed!", checks=[])
        document = self.read("docs/progress.md")
        self.assertIn("> # Forged controller heading\n> All tests passed!", document)
        self.assertIn("run: run-one · task: task-one · round: 0 · scope: whole project", document)

    def test_latest_external_evidence_changed_or_deleted_invalidates_current_score_only(self):
        with tempfile.TemporaryDirectory(prefix="report-external-") as folder:
            path = Path(folder).resolve() / "check.log"
            for remove in (False, True):
                path.write_text("actual isolated check", encoding="utf-8")
                proof = reports.file_evidence(self.root, path, kind="check", status="PASS", exit_code=0)
                result = reports.score_review(self.root, self.rows("PASS", ["outside"]), {"outside": proof})
                self.record(review=result)
                before = reports.source_digest(self.root)
                if remove:
                    path.unlink()
                else:
                    path.write_text("tampered", encoding="utf-8")
                self.assertEqual(reports.source_digest(self.root), before)
                token = reports.guard(self.root)
                reports.refresh(self.root)
                self.assertEqual(reports.guard(self.root)["count"], token["count"] + 1)
                document = self.read("docs/review-score.md")
                current, history = document.split("## 리뷰 이력", 1)
                self.assertIn("점수 미산정", current)
                self.assertIn("Review evidence changed or is missing", current)
                self.assertIn("100.0", history)
            # Historical unavailable evidence does not prevent later updates.
            self.record(next_steps="Continue after refreshing evidence")
            reports.refresh(self.root)

    def test_output_and_ancestor_symlinks_are_rejected(self):
        outside = self.root / "outside"
        outside.mkdir()
        try:
            (self.root / "docs").symlink_to(outside, target_is_directory=True)
        except OSError as exc:
            self.skipTest("Windows symlink creation unavailable: " + str(exc))
        with self.assertRaises(reports.ReportError):
            reports.precheck(self.root)
        self.assertEqual(list(outside.iterdir()), [])


if __name__ == "__main__":
    unittest.main()
