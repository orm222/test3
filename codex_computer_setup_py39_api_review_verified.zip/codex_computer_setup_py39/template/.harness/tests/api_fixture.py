"""Local API receipts only; these fixtures never install or invoke API tools."""
import json
from pathlib import Path


def configure(root, mode="passed"):
    root = Path(root)
    (root / "api-tests").mkdir(exist_ok=True)
    (root / "api-tests/basic.hurl").write_text("GET http://127.0.0.1/example\nHTTP 200\n", encoding="utf-8")
    (root / ".harness/api-review.json").write_text(json.dumps({"version": 1, "scenarios": ["api-tests/basic.hurl"]}), encoding="utf-8")
    runner = root / ".harness/api-review/check_api.py"
    runner.parent.mkdir(exist_ok=True)
    runner.write_text("import sys\nfrom pathlib import Path\n"
                      "sys.path.insert(0, str(Path(__file__).resolve().parents[1]))\nimport reports\n"
                      + RESULT_SOURCE + "\nvalue = result(Path.cwd(), reports)\n"
                      + {"passed": "", "malformed": "value = {'schema': 'wrong'}\n",
                         "zero": "value['checks'][0]['counts'] = dict(collected=0, passed=0, failed=0, skipped=0)\n",
                         "allskip": "value['checks'][0]['counts'] = dict(collected=1, passed=0, failed=0, skipped=1)\n",
                         "missing": "value['checks'].pop()\n",
                         "failed": "value['status']='failed'\nvalue['checks'][0].update(status='FAIL',exit_code=1,counts=dict(collected=1,passed=0,failed=1,skipped=0))\n"}[mode]
                      + "import json\nprint('raw diagnostics', file=sys.stderr)\nprint(json.dumps(value))\n"
                        "raise SystemExit(1 if value.get('status') == 'failed' else 0)\n", encoding="utf-8")


RESULT_SOURCE = '''
def result(root, reports):
    import json
    root = Path(root).resolve()
    folder = root / '.harness/work/api-review/fake-run'
    folder.mkdir(parents=True, exist_ok=True)
    checks = []
    for tool in ('schemathesis', 'hurl'):
        artifacts = []
        for suffix in ('.stdout.log', '.stderr.log', '.xml'):
            path = folder / (tool + suffix)
            path.write_text('fake actual execution evidence ' + tool + suffix, encoding='utf-8')
            artifacts.append(dict(path=path.relative_to(root).as_posix(), sha256=reports.sha(path.read_bytes())))
        checks.append(dict(id=tool, tool=tool, status='PASS', exit_code=0,
                           counts=dict(collected=1, passed=1, failed=0, skipped=0), artifacts=artifacts))
    config = root / '.harness/api-review.json'
    return dict(schema=reports.API_PROTOCOL, status='passed', source_hash=reports.source_digest(root),
                config_digest=reports.sha(config.read_bytes()), scenario_files=json.loads(config.read_text(encoding='utf-8'))['scenarios'],
                required_check_ids=['schemathesis','hurl'], checks=checks, artifacts=[],
                tools={'schemathesis':{'version':'4.4.4'},'hurl':{'version':'8.1.0'}})
'''
exec(RESULT_SOURCE)


def record(root, reports, value=None):
    value = result(root, reports) if value is None else value
    return reports.append_event(root, {"kind": "api_verification", "status": "PASS", "scope": "api-check",
        "run_id": "fake-prior-api", "source_hash": value["source_hash"], "data": {"api_review": value, "api_exit_code": 0}})
