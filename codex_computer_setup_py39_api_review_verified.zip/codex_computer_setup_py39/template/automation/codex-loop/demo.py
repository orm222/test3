#!/usr/bin/env python3
"""Offline control-flow demo. Fake workers, real subprocesses and unittest checks."""
import argparse
import json
from pathlib import Path
import shutil
import sys
import tempfile

import run


def create_boundary(project, spec="SPEC.md"):
    """Record a real no-question analysis for this explicitly scoped offline fixture."""
    shutil.copyfile(run.BASE.parents[1] / "BOUNDARY_QUESTION_TEMPLATE.md",
                    project / "BOUNDARY_QUESTION_TEMPLATE.md")
    state = run.boundary.create_state(project, spec)
    run.boundary.complete_analysis(project, state, {
        "version": 1, "questions": [], "unresolved": [], "references": []})


def create_acceptance(project, required_ids):
    """Give the offline fixture the same explicit contract as a real project."""
    folder = project / ".harness"
    folder.mkdir(exist_ok=True)
    for name in ("acceptance.py", "check_unittest.py", "reports.py", "review_criteria.json"):
        shutil.copyfile(run.BASE.parents[1] / ".harness" / name, folder / name)
    run.write_json(folder / "required_tests.json", {"version": 1, "required_test_ids": required_ids})
    run.write_json(folder / "acceptance.json", {
        "version": 1, "checker_argv": ["{python}", "-B", ".harness/check_unittest.py"],
        "required_ids_manifest": ".harness/required_tests.json", "protected_paths": ["tests"]})


def create_demo(directory):
    directory = Path(directory).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    if any(directory.iterdir()):
        raise ValueError("Demo destination must be empty: " + str(directory))
    project = directory / "project with spaces"
    (project / "tests").mkdir(parents=True)
    (project / "SPEC.md").write_text(
        "# Addition\nImplement add(a, b) for integers using exact addition. No I/O or external effects.\n"
        "Acceptance examples: add(2, 3) = 5; add(0, 0) = 0; add(-2, 3) = 1.\n", encoding="utf-8")
    (project / "tests/test_calc.py").write_text(
        "import unittest\nfrom calc import add\n\nclass TestAdd(unittest.TestCase):\n"
        "    def test_positive(self):\n        self.assertEqual(add(2, 3), 5)\n"
        "    def test_zero(self):\n        self.assertEqual(add(0, 0), 0)\n"
        "    def test_negative(self):\n        self.assertEqual(add(-2, 3), 1)\n", encoding="utf-8")
    create_acceptance(project, ["test_calc.TestAdd." + name
                               for name in ("test_positive", "test_zero", "test_negative")])
    create_boundary(project)
    tasks = json.loads((run.BASE / "tasks.example.json").read_text(encoding="utf-8"))
    tasks[0]["goal"] = "Implement addition according to SPEC.md. Offline fixture only."
    tasks[0]["checks"][0]["argv"][0] = sys.executable
    run.write_json(directory / "tasks.json", tasks)
    config = {"project": str(project), "spec": "SPEC.md", "tasks_file": "tasks.json",
              "builder_model": "FAKE-sol", "reviewer_model": "FAKE-terra", "max_repairs": 3,
              "stage_timeout_seconds": 20, "total_timeout_seconds": 120,
              "codex_command": [sys.executable, str(run.BASE / "tests/fake_codex.py")],
              "protected_paths": ["tests"], "run_root": str(directory / "runs")}
    run.write_json(directory / "config.json", config)
    return directory / "config.json"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", help="Empty output directory; default is a new temporary directory")
    args = parser.parse_args()
    directory = args.directory or tempfile.mkdtemp(prefix="codex-loop-demo-")
    print("OFFLINE SIMULATION: no Sol/Terra model or API calls.\n"
          "The explicit arithmetic fixture uses a simulated no-question boundary analysis.\n"
          "Real local tests will fail, then pass after a fixture repair.", flush=True)
    config = create_demo(directory)
    print("Demo files: " + str(config.parent), flush=True)
    return run.main(["--config", str(config)])


if __name__ == "__main__":
    sys.exit(main())
