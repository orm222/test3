"""Fail-closed unit and process tests; no network or real Codex calls."""
import copy
import importlib.util
import json
import os
import py_compile
from pathlib import Path
import shlex
import signal
import stat
import sys
import tempfile
import time
import unittest
from unittest.mock import patch


BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
import demo

SPEC = importlib.util.spec_from_file_location("codex_loop_unit_runner", BASE / "run.py")
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)


class TemporaryCase(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="codex-loop-unit-")
        self.addCleanup(self.cleanup_temp)
        self.root = Path(self.temp.name).resolve()

    def cleanup_temp(self):
        # Windows can briefly retain file locks after verified process termination.
        deadline = time.monotonic() + 2
        while True:
            try:
                self.temp.cleanup()
                return
            except OSError as exc:
                cause = exc
                while cause is not None and not (isinstance(cause, PermissionError)
                        and getattr(cause, "winerror", None) in (5, 32)):
                    cause = cause.__cause__ or cause.__context__
                if os.name != "nt" or cause is None or time.monotonic() >= deadline:
                    raise
                time.sleep(0.02)

    def write_json(self, name, value):
        path = self.root / name
        path.write_text(json.dumps(value), encoding="utf-8")
        return path


class SettingsTests(TemporaryCase):
    def setUp(self):
        super().setUp()
        self.project = self.root / "project with spaces"
        self.project.mkdir()
        (self.project / "SPEC.md").write_text("Return exact integer a+b. No I/O or external effects.\n", encoding="utf-8")
        (self.project / "tests").mkdir()
        (self.project / "tests/test_example.py").write_text(
            "import unittest\nclass Example(unittest.TestCase):\n"
            "    def test_ok(self): self.assertTrue(True)\n", encoding="utf-8")
        demo.create_acceptance(self.project, ["test_example.Example.test_ok"])
        demo.create_boundary(self.project)
        self.task = {
            "id": "T1", "goal": "Implement addition",
            "requirements": [{"id": "R1", "text": "Add numbers", "check_ids": ["C1"]}],
            "checks": [{"id": "C1", "argv": [sys.executable, "-c", "print('PASS')"],
                        "success_regex": "^PASS$"}],
        }
        self.config = {
            "project": "project with spaces", "spec": "SPEC.md", "tasks_file": "tasks.json",
            "builder_model": "test-builder", "reviewer_model": "test-reviewer",
            "run_root": "runs",
        }

    def load(self, config=None, tasks=None):
        self.write_json("tasks.json", [self.task] if tasks is None else tasks)
        return runner.load_settings(self.write_json("config.json", self.config if config is None else config))

    def test_valid_settings_resolve_paths_defaults_and_protected_inputs(self):
        loaded = self.load()
        self.assertEqual(loaded["project_path"], self.project)
        self.assertEqual(loaded["run_root"], self.root / "runs")
        self.assertEqual(loaded["max_repairs"], 3)
        self.assertEqual(loaded["codex_command"], ["codex"])
        for path in (self.root / "config.json", self.root / "tasks.json", self.project / "SPEC.md"):
            self.assertIn(str(path), loaded["protected"])
        runner.verify_protected(loaded)

    def test_invalid_settings_fail_closed(self):
        cases = [
            ("builder_model", "SET_BUILDER_MODEL"),
            ("reviewer_model", ""),
            ("max_repairs", True),
            ("max_repairs", -1),
            ("stage_timeout_seconds", 0),
            ("total_timeout_seconds", 1.5),
            ("codex_command", "codex"),
            ("codex_command", []),
            ("run_root", "project with spaces/logs"),
            ("exclude_dirs", ["../outside"]),
            ("exclude_dirs", ["."]),
            ("exclude_dirs", ["*"]),
            ("exclude_dirs", ["/tmp"]),
            ("spec", "../outside.md"),
        ]
        (self.root / "outside.md").write_text("outside", encoding="utf-8")
        for key, value in cases:
            with self.subTest(key=key, value=value):
                config = dict(self.config, **{key: value})
                with self.assertRaises(runner.StopRun):
                    self.load(config=config)

    def test_invalid_task_contracts_fail_closed(self):
        variants = []
        for key in ("requirements", "checks"):
            item = copy.deepcopy(self.task)
            item[key] = []
            variants.append([item])
        variants.append([self.task, copy.deepcopy(self.task)])
        for field in ("requirements", "checks"):
            item = copy.deepcopy(self.task)
            item[field].append(copy.deepcopy(item[field][0]))
            variants.append([item])
        for ids in (["unknown"], ["C1", "C1"], []):
            item = copy.deepcopy(self.task)
            item["requirements"][0]["check_ids"] = ids
            variants.append([item])
        item = copy.deepcopy(self.task)
        item["checks"].append(dict(item["checks"][0], id="UNMAPPED"))
        variants.append([item])
        for change in ({"argv": "python tests.py"}, {"success_regex": ""}, {"success_regex": "["}):
            item = copy.deepcopy(self.task)
            item["checks"][0].update(change)
            variants.append([item])
        for index, tasks in enumerate(variants):
            with self.subTest(index=index), self.assertRaises(runner.StopRun):
                self.load(tasks=tasks)

    def test_json_duplicate_keys_constants_and_malformed_input_rejected(self):
        path = self.root / "bad.json"
        for text in ('{"id":1,"id":2}', '{"value":NaN}', '{"value":Infinity}', '{'):
            with self.subTest(text=text):
                path.write_text(text, encoding="utf-8")
                with self.assertRaises(runner.StopRun):
                    runner.read_json(path)

    def test_reserved_final_ids_and_inline_shell_checks_are_rejected(self):
        for task_id in ("FINAL", "final", "Final"):
            with self.subTest(task_id=task_id), self.assertRaisesRegex(runner.StopRun, "reserved"):
                self.load(tasks=[dict(self.task, id=task_id)])
        item = copy.deepcopy(self.task)
        item["checks"][0]["argv"] = ["bash", "-lc", "printf PASS"]
        with self.assertRaisesRegex(runner.StopRun, "check script"):
            self.load(tasks=[item])

    def test_changed_and_deleted_protected_files_are_detected(self):
        loaded = self.load()
        target = self.project / "SPEC.md"
        target.write_text("Changed requirement", encoding="utf-8")
        with self.assertRaisesRegex(runner.StopRun, "Protected file changed"):
            runner.verify_protected(loaded)
        target.unlink()
        with self.assertRaisesRegex(runner.StopRun, "Protected file changed"):
            runner.verify_protected(loaded)

    def test_protected_symlink_is_rejected(self):
        try:
            (self.project / "alias.md").symlink_to("SPEC.md")
        except OSError as exc:
            if os.name == "nt" and exc.winerror == 1314:
                self.skipTest("Windows symlink privilege unavailable")
            raise
        with self.assertRaises(runner.StopRun):
            self.load(config=dict(self.config, protected_paths=["alias.md"]))

    def test_python_placeholder_uses_current_interpreter_and_native_shell(self):
        task = copy.deepcopy(self.task)
        task["checks"][0]["argv"] = ["{python}", "tests with spaces.py", "a'b"]
        check = self.load(tasks=[task])["tasks"][0]["checks"][0]
        self.assertEqual(check["argv"], [sys.executable, "tests with spaces.py", "a'b"])
        self.assertEqual(check["shell_command"], runner.shell_command(check["argv"]))

    @unittest.skipUnless(os.name == "nt", "Windows PowerShell 5/7 native argument ambiguity")
    def test_doublequote_argument_is_rejected_with_script_guidance(self):
        task = copy.deepcopy(self.task)
        task["checks"][0]["argv"] = ["{python}", "test.py", 'say "hello"']
        with self.assertRaisesRegex(runner.StopRun, "check script file"):
            self.load(tasks=[task])

    def test_not_applicable_requires_known_criteria_and_prior_reason(self):
        for value in ([], {"UNKNOWN": "not used"}, {"HAND02": ""}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.load(config=dict(self.config, review_not_applicable=value))
        loaded = self.load(config=dict(self.config, review_not_applicable={"REL01": "No uploads or polling in this project"}))
        self.assertEqual(loaded["review_not_applicable"], {"REL01": "No uploads or polling in this project"})


class SnapshotTests(TemporaryCase):
    def setUp(self):
        super().setUp()
        self.source = self.root / "source.py"
        self.source.write_text("answer = 1\n", encoding="utf-8")

    def test_content_new_file_delete_and_mode_affect_hash_but_mtime_does_not(self):
        baseline = runner.snapshot(self.root)
        os.utime(str(self.source), (1, 1))
        self.assertEqual(runner.snapshot(self.root), baseline)
        self.source.write_text("answer = 2\n", encoding="utf-8")
        self.assertNotEqual(runner.snapshot(self.root), baseline)
        self.source.write_text("answer = 1\n", encoding="utf-8")
        new = self.root / "untracked.py"
        new.write_text("new = True", encoding="utf-8")
        self.assertNotEqual(runner.snapshot(self.root), baseline)
        new.unlink()
        self.assertEqual(runner.snapshot(self.root), baseline)
        if os.name != "nt":
            original_mode = self.source.stat().st_mode
            self.source.chmod(stat.S_IMODE(original_mode) ^ stat.S_IXUSR)
            self.assertNotEqual(runner.snapshot(self.root), baseline)

    def test_explicit_exclusions_skip_directories_not_untracked_files(self):
        baseline = runner.snapshot(self.root)
        nested = self.root / "nested"
        (nested / "__pycache__").mkdir(parents=True)
        (nested / "__pycache__" / "cached.pyc").write_bytes(b"cache")
        self.assertEqual(runner.snapshot(self.root), baseline)
        (nested / "runtime").mkdir()
        (nested / "runtime" / "state.json").write_text("{}", encoding="utf-8")
        self.assertNotEqual(runner.snapshot(self.root), baseline)
        self.assertEqual(runner.snapshot(self.root, runner.DEFAULT_EXCLUDES + ["nested/runtime"]), baseline)
        (self.root / ".gitignore").write_text("ignored.py\n", encoding="utf-8")
        before_ignored = runner.snapshot(self.root)
        (self.root / "ignored.py").write_text("included = True", encoding="utf-8")
        self.assertNotEqual(runner.snapshot(self.root), before_ignored)

    def test_file_and_directory_symlinks_are_rejected(self):
        link = self.root / "alias"
        try:
            link.symlink_to(self.source)
        except OSError as exc:
            if os.name == "nt" and exc.winerror == 1314:
                self.skipTest("Windows symlink privilege unavailable")
            raise
        with self.assertRaisesRegex(runner.StopRun, "Symlink"):
            runner.snapshot(self.root)
        link.unlink()
        target = self.root / "directory"
        target.mkdir()
        link.symlink_to(target, target_is_directory=True)
        with self.assertRaisesRegex(runner.StopRun, "Symlink"):
            runner.snapshot(self.root)

    def test_empty_project_is_rejected(self):
        self.source.unlink()
        with self.assertRaises(runner.StopRun):
            runner.snapshot(self.root)

    def test_controller_reports_do_not_change_source_hash_but_other_docs_do(self):
        baseline = runner.snapshot(self.root)
        runner.reports.initialize(self.root)
        self.assertEqual(runner.snapshot(self.root), baseline)
        runner.reports.append_event(self.root, {"kind": "test", "status": "RUNNING", "data": {"goal": "Hash fixture"}})
        self.assertEqual(runner.snapshot(self.root), baseline)
        (self.root / "docs/implementation.md").write_text("An implementation decision changed.\n", encoding="utf-8")
        self.assertNotEqual(runner.snapshot(self.root), baseline)

    def test_managed_report_tampering_is_not_an_ignored_document(self):
        runner.reports.initialize(self.root)
        (self.root / "docs/review-score.md").write_text("All scores are 100.\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Managed report changed"):
            runner.snapshot(self.root)


class ReportTests(unittest.TestCase):
    def setUp(self):
        self.expected = {"run_id": "run-123", "task_id": "T1", "round": 0, "source_hash": "abc123"}
        argv = ["python3", "-m", "unittest", "discover", "-s", "tests"]
        self.command = runner.shell_command(argv)
        self.task = {
            "requirements": [{"id": rid, "check_ids": ["C1"]} for rid in ("R1", "R2")],
            "checks": [{"id": "C1", "argv": argv,
                        "success_regex": r"(?s)Ran [1-9][0-9]* tests? in [^\n]+\n\nOK\s*\Z"}],
        }
        self.events = {"cmd1": {"id": "cmd1", "type": "command_execution", "command": self.command,
                                "status": "completed", "exit_code": 0,
                                "aggregated_output": "Ran 2 tests in 0.001s\n\nOK\n"}}
        self.report = dict(self.expected, verdict="PASS", summary="All checks passed", repair_plan=[], checks=[
            {"requirement_id": rid, "status": "PASS", "expected": "Correct output", "actual": "Correct output",
             "verification_commands": [self.command]} for rid in ("R1", "R2")
        ])

    def validate(self, report=None, events=None):
        return runner.validate_report(self.report if report is None else report, self.expected,
                                      self.task, self.events if events is None else events)

    def test_valid_report_accepts_observed_shell_wrapped_command(self):
        events = copy.deepcopy(self.events)
        events["cmd1"]["command"] = "/bin/bash -lc " + shlex.quote(self.command)
        self.assertEqual(self.validate(events=events), "PASS")

    def test_empty_missing_duplicate_and_unknown_requirements_rejected(self):
        variants = [[], self.report["checks"][:1], self.report["checks"] * 2]
        unknown = copy.deepcopy(self.report["checks"])
        unknown[0]["requirement_id"] = "R999"
        variants.append(unknown)
        for rows in variants:
            with self.subTest(rows=rows), self.assertRaises(runner.StopRun):
                self.validate(report=dict(self.report, checks=rows))

    def test_stale_identities_and_bool_round_rejected(self):
        for key, value in (("run_id", "old-run"), ("task_id", "T2"), ("round", 1),
                           ("round", False), ("source_hash", "old-code")):
            with self.subTest(key=key, value=value), self.assertRaises(runner.StopRun):
                self.validate(report=dict(self.report, **{key: value}))

    def test_pass_requires_successful_observed_command_evidence(self):
        for events in ({}, {"cmd1": dict(self.events["cmd1"], exit_code=1)},
                       {"cmd1": dict(self.events["cmd1"], exit_code=False)},
                       {"cmd1": dict(self.events["cmd1"], status="failed")},
                       {"cmd1": dict(self.events["cmd1"], command="echo fabricated")}):
            with self.subTest(events=events), self.assertRaises(runner.StopRun):
                self.validate(events=events)
        report = copy.deepcopy(self.report)
        report["checks"][0]["verification_commands"] = []
        with self.assertRaises(runner.StopRun):
            self.validate(report)

    def test_true_command_cannot_replace_registered_check(self):
        report = copy.deepcopy(self.report)
        for row in report["checks"]:
            row["verification_commands"] = ["true"]
        events = {"cmd1": dict(self.events["cmd1"], command="true")}
        with self.assertRaisesRegex(runner.StopRun, "registered verification command"):
            self.validate(report, events)

    def test_missing_empty_and_skipped_execution_output_cannot_prove_pass(self):
        outputs = [None, "", "Ran 0 tests in 0.000s\n\nOK\n",
                   "Ran 2 tests in 0.001s\n\nOK (skipped=2)\n",
                   "Ran 2 tests in 0.001s\n\nFAILED (failures=1)\n"]
        for output in outputs:
            events = {"cmd1": dict(self.events["cmd1"], aggregated_output=output)}
            with self.subTest(output=output), self.assertRaisesRegex(runner.StopRun, "independently pass"):
                self.validate(events=events)

    def test_every_mapped_registered_check_requires_independent_execution(self):
        self.task["checks"].append({"id": "C2", "argv": ["python3", "integration_test.py"],
                                     "success_regex": "INTEGRATION_OK"})
        self.task["requirements"][0]["check_ids"].append("C2")
        with self.assertRaisesRegex(runner.StopRun, "registered verification command"):
            self.validate()

    def test_shell_expansion_cannot_match_registered_literal_argument(self):
        self.task["checks"][0]["argv"] = ["printf", "%s", "$HOME"]
        self.task["checks"][0]["success_regex"] = r"\$HOME"
        expanded_command = 'printf %s "$HOME"'
        report = copy.deepcopy(self.report)
        for row in report["checks"]:
            row["verification_commands"] = [expanded_command]
        events = {"cmd1": dict(self.events["cmd1"], command=expanded_command, aggregated_output="$HOME")}
        with self.assertRaisesRegex(runner.StopRun, "registered verification command"):
            self.validate(report, events)

    def test_incomplete_and_inconsistent_reports_are_not_passed(self):
        for status in ("FAIL", "UNVERIFIED"):
            report = copy.deepcopy(self.report)
            report["checks"][0]["status"] = status
            with self.subTest(status=status), self.assertRaises(runner.StopRun):
                self.validate(report)
            report["verdict"] = status
            if status == "FAIL":
                with self.assertRaises(runner.StopRun):
                    self.validate(report)
                report["repair_plan"] = ["Fix addition"]
            self.assertEqual(self.validate(report), status)

    def test_malformed_report_fields_rejected(self):
        for key, value in (("summary", ""), ("repair_plan", "fix"), ("checks", {}), ("verdict", "DONE")):
            with self.subTest(key=key), self.assertRaises(runner.StopRun):
                self.validate(dict(self.report, **{key: value}))
        for key, value in (("actual", ""), ("verification_commands", "python3"), ("status", "DONE")):
            report = copy.deepcopy(self.report)
            report["checks"][0][key] = value
            with self.subTest(key=key), self.assertRaises(runner.StopRun):
                self.validate(report)


class EventTests(TemporaryCase):
    def parse(self, events):
        path = self.root / "events.jsonl"
        path.write_text("\n".join(json.dumps(x) for x in events) + "\n", encoding="utf-8")
        return runner.command_events(path)

    def test_only_completed_command_events_are_collected(self):
        command = {"id": "cmd1", "type": "command_execution", "command": "python3 -m unittest",
                   "status": "completed", "exit_code": 0}
        result = self.parse([
            {"type": "thread.started", "thread_id": "thread"},
            {"type": "item.started", "item": dict(command, id="started-only")},
            {"type": "item.completed", "item": {"id": "message", "type": "agent_message", "text": "PASS"}},
            {"type": "item.completed", "item": command},
            {"type": "turn.completed"},
        ])
        self.assertEqual(result, {"cmd1": command})

    def test_failed_missing_completion_duplicate_and_malformed_events_rejected(self):
        command = {"type": "item.completed", "item": {"id": "cmd1", "type": "command_execution"}}
        cases = [[], [command], [{"type": "turn.completed"}, {"type": "turn.failed"}],
                 [{"type": "error"}], [command, command, {"type": "turn.completed"}],
                 [["not an object"], {"type": "turn.completed"}]]
        for index, events in enumerate(cases):
            with self.subTest(index=index), self.assertRaises(runner.StopRun):
                self.parse(events)
        path = self.root / "bad.jsonl"
        path.write_text('{broken\n', encoding="utf-8")
        with self.assertRaises(runner.StopRun):
            runner.command_events(path)

    def test_canonical_command_handles_quotes_and_nested_shell_wrappers(self):
        command = "python3 -c 'print(1)'"
        wrapped = "/bin/bash -lc " + shlex.quote("sh -c " + shlex.quote(command))
        self.assertEqual(runner.canonical_command(wrapped), runner.canonical_command(command))
        self.assertNotEqual(runner.canonical_command(command), runner.canonical_command(command + " --different"))

    def test_canonical_command_preserves_shell_quote_semantics(self):
        literal = "printf %s '$HOME'"
        expanded = 'printf %s "$HOME"'
        self.assertNotEqual(runner.canonical_command(literal), runner.canonical_command(expanded))
        wrapped = "/bin/bash -lc " + shlex.quote(expanded)
        self.assertEqual(runner.canonical_command(wrapped), expanded)


class ProcessAndLockTests(TemporaryCase):
    def test_old_timestamp_bytecode_cannot_hide_changed_source(self):
        source = self.root / "stale_fixture.py"
        source.write_text("def add(a,b): return a+b\n", encoding="utf-8")
        os.utime(str(source), (1700000000, 1700000000))
        py_compile.compile(str(source), doraise=True, invalidation_mode=py_compile.PycInvalidationMode.TIMESTAMP)
        source.write_text("def add(a,b): return a-b\n", encoding="utf-8")
        os.utime(str(source), (1700000000, 1700000000))
        prefix = self.root / "fresh-check"
        code = runner.execute([sys.executable, "-c", "from stale_fixture import add; assert add(2,3)==5"],
                              self.root, prefix, 5)
        self.assertEqual(code, 1)
        self.assertIn("AssertionError", prefix.with_suffix(".stderr.log").read_text())

    def test_executable_argv_and_large_logs_preserve_exit_code(self):
        code = runner.execute([sys.executable, "-c", "import sys; print('x' * 100000); sys.stderr.write('error'); sys.exit(7)"],
                              self.root, self.root / "command", timeout=5)
        self.assertEqual(code, 7)
        self.assertGreater((self.root / "command.stdout.log").stat().st_size, 100000)
        self.assertEqual((self.root / "command.stderr.log").read_text(), "error")
        self.assertEqual(runner.read_json(self.root / "command.exit.json")["exit_code"], 7)

    @staticmethod
    def running(pid):
        if os.name == "nt":
            return runner._processes.owner_running(pid)
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        status_path = Path("/proc") / str(pid) / "stat"
        if status_path.exists():
            try:
                return status_path.read_text().rsplit(")", 1)[1].split()[0] != "Z"
            except FileNotFoundError:
                return False
        return True

    def assert_child_stopped(self, pidfile):
        self.assertTrue(pidfile.exists(), "child should have started before termination")
        pid = int(pidfile.read_text())
        self.addCleanup(self.cleanup_pid, pid)
        deadline = time.monotonic() + 2
        while self.running(pid) and time.monotonic() < deadline:
            time.sleep(0.02)
        self.assertFalse(self.running(pid), "descendant process survived process-group cleanup")

    @staticmethod
    def cleanup_pid(pid):
        if os.name == "nt":
            if runner._processes.owner_running(pid):
                os.kill(pid, signal.SIGTERM)
            return
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

    def child_script(self, pidfile, parent_wait):
        child = "import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); time.sleep(60)"
        return ("import subprocess,sys,pathlib,time; "
                "p=subprocess.Popen([getattr(sys,'_base_executable',sys.executable),'-c'," + repr(child) + "]); "
                "pathlib.Path(" + repr(str(pidfile)) + ").write_text(str(p.pid)); "
                "time.sleep(" + str(parent_wait) + ")")

    @unittest.skipUnless(os.name == "nt" or Path("/proc").exists(), "Windows process handles or Linux /proc required")
    def test_timeout_stops_child_process_group(self):
        pidfile = self.root / "child.pid"
        with self.assertRaisesRegex(runner.StopRun, "Timeout"):
            runner.execute([sys.executable, "-c", self.child_script(pidfile, 60)], self.root,
                           self.root / "timeout", timeout=1.5)
        self.assert_child_stopped(pidfile)

    @unittest.skipUnless(os.name == "nt" or Path("/proc").exists(), "Windows process handles or Linux /proc required")
    def test_normal_parent_exit_also_stops_remaining_children(self):
        pidfile = self.root / "child.pid"
        self.assertEqual(runner.execute([sys.executable, "-c", self.child_script(pidfile, 0.15)], self.root,
                                        self.root / "normal", timeout=5), 0)
        self.assert_child_stopped(pidfile)

    def test_guard_failure_cancels_process(self):
        pidfile = self.root / "guard-child.pid"
        original = runner._processes.start_process
        parents = []
        def start(*args, **kwargs):
            process = original(*args, **kwargs)
            parents.append(process)
            return process
        def guard():
            if pidfile.is_file() and pidfile.read_text().strip():
                raise runner.StopRun("source changed")
        with patch.object(runner._processes, "start_process", side_effect=start), self.assertRaisesRegex(runner.StopRun, "source changed"):
            runner.execute([sys.executable, "-c", self.child_script(pidfile, 60)], self.root,
                           self.root / "guard", timeout=5, guard=guard)
        self.assertEqual(len(parents), 1)
        self.assertIsNotNone(parents[0].returncode, "guard returned before waiting for its direct process")
        self.assert_child_stopped(pidfile)

    def test_project_lock_rejects_second_owner_and_releases_after_error(self):
        with runner.project_lock(self.root):
            with self.assertRaisesRegex(runner.StopRun, "Another runner"):
                with runner.project_lock(self.root):
                    self.fail("second lock owner admitted")
        with self.assertRaisesRegex(RuntimeError, "intentional"):
            with runner.project_lock(self.root):
                raise RuntimeError("intentional")
        with runner.project_lock(self.root):
            pass


if __name__ == "__main__":
    unittest.main()
