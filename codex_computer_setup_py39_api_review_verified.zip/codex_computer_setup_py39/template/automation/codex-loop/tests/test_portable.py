"""Native Windows quoting, npm resolution and Python environment contracts."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("codex_loop_portable_runner", BASE / "run.py")
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)


class PortableTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="codex-loop-portable-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()

    def test_fake_boundary_cli_returns_structured_no_question_analysis(self):
        answer = self.root / "analysis.json"
        prefix = self.root / "boundary"
        command = [sys.executable, str(BASE / "tests/fake_codex.py"), "exec", "--output-schema",
                   str(BASE.parents[1] / ".harness/clarify.schema.json"),
                   "--output-last-message", str(answer), "-"]
        code = runner.execute(command, self.root, prefix, 10,
                              prompt="BOUNDARY_CLARIFICATION_CONTEXT\n" + json.dumps({"spec": "Exact integer addition"}))
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(answer.read_text(encoding="utf-8")),
                         {"version": 1, "questions": [], "unresolved": [], "references": []})
        self.assertEqual(runner.command_events(prefix.with_suffix(".stdout.log")), {})

    def test_powershell_rendering_is_literal_and_wrappers_preserve_extra_text(self):
        argv = [r"C:\Program Files\Python39\python.exe", "tests/check.py", "$HOME", "a'b", "a;b"]
        command = runner.shell_command(argv, windows=True)
        self.assertEqual(command, "& 'C:\\Program Files\\Python39\\python.exe' 'tests/check.py' '$HOME' 'a''b' 'a;b'")
        wrappers = [
            'powershell.exe -NoProfile -Command "' + command + '"',
            '"C:\\Program Files\\PowerShell\\7\\pwsh.exe" -NoLogo -NoProfile -Command "' + command + '"',
            "pwsh -Command '" + command.replace("'", "''") + "'",
        ]
        for wrapped in wrappers:
            with self.subTest(wrapped=wrapped):
                self.assertEqual(runner.canonical_command(wrapped), command)
                self.assertNotEqual(runner.canonical_command(wrapped + "; echo forged"), command)
        self.assertNotEqual(runner.canonical_command('powershell.exe -Command "' + command + '; echo forged"'), command)
        self.assertNotEqual(runner.canonical_command(command), runner.canonical_command(command.replace("'$HOME'", '"$HOME"')))

    @unittest.skipUnless(os.name == "nt", "Native PowerShell execution")
    def test_powershell_executes_space_apostrophe_and_metacharacters_as_literals(self):
        shell = shutil.which("powershell.exe")
        self.assertIsNotNone(shell)
        script = self.root / "check arguments.py"
        script.write_text("import json,sys\nprint(json.dumps(sys.argv[1:]))\n", encoding="utf-8")
        args = ["with spaces", "O'Brien", "$HOME", "a&b", "%PATH%", "; New-Item injected"]
        command = runner.shell_command([sys.executable, str(script)] + args)
        prefix = self.root / "literal"
        code = runner.execute([shell, "-NoProfile", "-NonInteractive", "-Command", command], self.root, prefix, 15)
        self.assertEqual(code, 0, prefix.with_suffix(".stderr.log").read_text())
        self.assertEqual(json.loads(prefix.with_suffix(".stdout.log").read_text()), args)
        self.assertFalse((self.root / "injected").exists())

    @unittest.skipUnless(os.name == "nt", "Windows npm shim resolver")
    def test_npm_codex_shim_is_bypassed_and_unrecognized_shim_rejected(self):
        shim = self.root / "codex.cmd"
        shim.write_text("@echo must-not-run", encoding="utf-8")
        node = str(self.root / "node.exe")
        entry = self.root / "node_modules/@openai/codex/bin/codex.js"
        entry.parent.mkdir(parents=True)
        entry.write_text("// resolution fixture", encoding="utf-8")
        lookup = lambda name, **kwargs: node if name == "node.exe" else str(shim)
        with patch.object(runner.shutil, "which", side_effect=lookup):
            self.assertEqual(runner.resolve_codex_command(["codex", "--version"]), [node, str(entry), "--version"])
            entry.unlink()
            with self.assertRaisesRegex(runner.StopRun, "native codex.exe"):
                runner.resolve_codex_command(["codex"])

    def test_execute_prefers_selected_python_and_clears_inherited_pythonhome(self):
        prefix = self.root / "python-env"
        program = ("import json,os,sys; print(json.dumps({'executable':sys.executable,"
                   "'first_path':os.environ['PATH'].split(os.pathsep)[0],"
                   "'home':os.environ.get('PYTHONHOME'), 'venv':os.environ.get('VIRTUAL_ENV')}))")
        with patch.dict(os.environ, {"PYTHONHOME": str(self.root / "wrong-runtime"), "VIRTUAL_ENV": "wrong-venv"}):
            self.assertEqual(runner.execute([sys.executable, "-c", program], self.root, prefix, 10), 0)
        value = json.loads(prefix.with_suffix(".stdout.log").read_text())
        self.assertEqual(Path(value["executable"]).resolve(), Path(sys.executable).resolve())
        self.assertEqual(value["first_path"], str(Path(sys.executable).parent))
        self.assertIsNone(value["home"])
        self.assertEqual(value["venv"], sys.prefix if sys.prefix != sys.base_prefix else None)


if __name__ == "__main__":
    unittest.main()
