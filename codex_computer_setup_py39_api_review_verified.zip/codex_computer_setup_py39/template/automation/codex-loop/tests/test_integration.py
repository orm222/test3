"""Real subprocess integration tests, explicitly using a fake Codex worker."""
import contextlib
import copy
import io
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
import demo
import run


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="codex-loop-integration-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config_path = demo.create_demo(self.root)
        self.trace = self.root / "trace.jsonl"

    def execute(self, mode="repair", config_changes=None):
        if config_changes:
            config = run.read_json(self.config_path)
            config.update(config_changes)
            run.write_json(self.config_path, config)
        c = run.load_settings(self.config_path)
        worker = run.Runner(c)
        with patch.dict(os.environ, {"CODEX_LOOP_FAKE_MODE": mode, "CODEX_LOOP_FAKE_TRACE": str(self.trace)}), contextlib.redirect_stdout(io.StringIO()):
            code = worker.run()
        state = run.read_json(worker.directory / "state.json")
        calls = [json.loads(line) for line in self.trace.read_text().splitlines()] if self.trace.exists() else []
        return code, state, calls, worker

    def test_fail_repair_pass_and_exact_feedback_forwarding(self):
        project = self.root / "project with spaces"
        analysis = run.boundary.create_state(project, "SPEC.md")
        run.boundary.complete_analysis(project, analysis, {
            "version": 1,
            "questions": [{"template": "T01", "question": "Should negative integer inputs use exact addition?",
                           "decides": "The permitted integer input domain.", "follow_up_to": None}],
            "unresolved": ["Negative integer behavior needs an actual answer."], "references": []})
        answer = "Negative integer inputs are permitted; add(-2, 3) must return 1 without external effects."
        analysis = run.boundary.submit_answer(project, "Q-001", answer)
        run.boundary.complete_analysis(project, analysis, {
            "version": 1, "questions": [], "unresolved": [], "references": []})
        contract = run.read_json(project / ".harness/acceptance.json")
        mapping = {"Q-001": ["test_calc.TestAdd.test_negative"]}
        contract["boundary_tests"] = mapping
        run.write_json(project / ".harness/acceptance.json", contract)
        code, state, calls, worker = self.execute()
        self.assertEqual(code, 0)
        self.assertEqual(state["status"], "COMPLETED")
        self.assertEqual([x["role"] for x in calls], ["builder", "reviewer", "builder", "reviewer"])
        self.assertEqual(calls[2]["context"]["previous_review"]["review"]["verdict"], "FAIL")
        self.assertIn("replace subtraction", calls[2]["context"]["previous_review"]["review"]["repair_plan"][0])
        self.assertNotEqual(calls[1]["context"]["source_hash"], calls[3]["context"]["source_hash"])
        for call in calls:
            self.assertIn("Should negative integer inputs use exact addition?", call["context"]["boundary_context"])
            self.assertIn(answer, call["context"]["boundary_context"])
            self.assertEqual(call["context"]["boundary_tests"], mapping)
            self.assertIn("review_criteria", call["context"])
            self.assertIn("prior_progress", call["context"])
            args = call["args"]
            self.assertNotIn("resume", args)
            self.assertEqual(args[args.index("--ask-for-approval") + 1], "never")
            self.assertEqual(args[args.index("--sandbox") + 1], "read-only" if call["role"] == "reviewer" else "workspace-write")
        for folder in (worker.directory / "T001-00", worker.directory / "T001-01"):
            self.assertTrue((folder / "reviewer.stdout.log").is_file())
            self.assertEqual(len(run.read_json(folder / "registered-checks.json")), 1)
        progress = (project / "docs/progress.md").read_text(encoding="utf-8")
        token = run.reports.guard(project)
        run.reports.refresh(project)
        self.assertEqual(run.reports.guard(project), token, "Controller updates must not invalidate reviewed Markdown evidence")
        score = (project / "docs/review-score.md").read_text(encoding="utf-8")
        for phase in ("RUNNING", "IMPLEMENTED", "CHECKED", "REVIEWED", "REVIEW_FAILED", "REPAIRING", "COMPLETED"):
            self.assertIn(phase, progress)
        self.assertIn("Builder self-report", progress)
        self.assertIn("UNVERIFIED", score)
        self.assertIn("PARTIAL", score)
        for call in (calls[1], calls[3]):
            evidence = call["context"]["evidence_catalog"]["file:docs/progress.md"]
            self.assertNotEqual(Path(evidence["path"]), project / "docs/progress.md")
            self.assertIn("REVIEWING", Path(evidence["path"]).read_text(encoding="utf-8"))
            self.assertEqual(run.file_hash(evidence["path"]), evidence["sha256"])
        self.assertIn("REVIEW_FAILED", calls[2]["context"]["prior_progress"])
        self.assertEqual(run.snapshot(project, worker.c["exclude_dirs"]), worker.current_hash)

    def test_worker_cannot_rewrite_managed_markdown_or_append_history(self):
        for mode in ("managed_md_tamper", "managed_history_append", "managed_refresh"):
            with self.subTest(mode=mode):
                # Each corrupt-history case is isolated; no evidence is repaired or removed.
                with tempfile.TemporaryDirectory(prefix="codex-loop-report-tamper-") as directory:
                    config = demo.create_demo(Path(directory))
                    worker = run.Runner(run.load_settings(config))
                    with patch.dict(os.environ, {"CODEX_LOOP_FAKE_MODE": mode}), contextlib.redirect_stdout(io.StringIO()):
                        self.assertEqual(worker.run(), 2)
                    self.assertEqual(worker.state["status"], "STOPPED")
                    self.assertTrue(worker.state.get("reporting_error"))

    def test_prior_api_catalog_is_context_without_rerunning_optional_tools(self):
        loader = importlib.util.spec_from_file_location("loop_api_fixture", BASE.parents[1] / ".harness/tests/api_fixture.py")
        fixture = importlib.util.module_from_spec(loader)
        loader.loader.exec_module(fixture)
        project = (self.root / "project with spaces").resolve()
        fixture.configure(project)
        (project / ".harness/api-review/check_api.py").write_text("raise AssertionError('API tools must not run during loop')", encoding="utf-8")
        (project / "calc.py").write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
        run.reports.initialize(project)
        fixture.record(project, run.reports)
        code, state, calls, worker = self.execute("api_evidence")
        self.assertEqual(code, 0, state)
        self.assertEqual(state["status"], "COMPLETED")
        self.assertEqual([call["role"] for call in calls], ["builder", "reviewer"])
        for call in calls:
            self.assertIn("Prior controller API execution", call["context"]["prior_api_review"]["provenance"])
            self.assertEqual(len(call["context"]["task"]["checks"]), 1)
        catalog = calls[-1]["context"]["evidence_catalog"]
        self.assertIn("api-check:schemathesis", catalog)
        self.assertIn("api-check:hurl", catalog)
        self.assertEqual(len(catalog["api-check:schemathesis"]["artifacts"]), 6)
        events = [run.read_json(path) for path in sorted((project / run.reports.DIRECTORY / "events").glob("*.json"))]
        score = next(event["data"]["review"] for event in reversed(events) if event["data"].get("review"))
        self.assertIn("api-check:schemathesis", score["evidence"])

    def test_invalid_score_evidence_and_unapproved_na_stop_without_repair(self):
        for mode in ("invalid_scores", "unauthorized_na"):
            with self.subTest(mode=mode):
                self.trace.unlink(missing_ok=True)
                code, state, calls, _ = self.execute(mode)
                self.assertEqual(code, 2)
                self.assertEqual(state["status"], "STOPPED")
                self.assertEqual([item["role"] for item in calls], ["builder", "reviewer"])

    def test_cli_failure_stops_without_review(self):
        code, state, calls, _ = self.execute("cli_failure")
        self.assertEqual(code, 2)
        self.assertIn("CLI failed", state["reason"])
        self.assertEqual([x["role"] for x in calls], ["builder"])

    def test_stale_empty_unverified_invalid_and_fabricated_pass_stop(self):
        for mode, reason in (("stale", "identity mismatch"), ("empty", "no checks"),
                             ("unverified", "UNVERIFIED"), ("invalid_json", "Cannot read JSON"),
                             ("claim_pass", "successful executed evidence")):
            with self.subTest(mode=mode):
                self.trace.unlink(missing_ok=True)
                code, state, calls, _ = self.execute(mode)
                self.assertEqual(code, 2)
                self.assertEqual(state["status"], "STOPPED")
                self.assertIn(reason, state["reason"])
                self.assertEqual(len(calls), 2)

    def test_reviewer_mutation_invalidates_results(self):
        code, state, _, _ = self.execute("mutate")
        self.assertEqual(code, 2)
        self.assertIn("Source changed", state["reason"])
        self.assertTrue((self.root / "project with spaces/unexpected.py").is_file())

    def test_maximum_repairs_excludes_first_implementation(self):
        code, state, calls, _ = self.execute("moving_fail")
        self.assertEqual(code, 2)
        self.assertIn("Repair limit", state["reason"])
        self.assertEqual(len([x for x in calls if x["role"] == "builder"]), 4)
        self.assertEqual(len([x for x in calls if x["role"] == "reviewer"]), 4)

    def test_no_progress_stops_early(self):
        code, state, calls, _ = self.execute("always_fail")
        self.assertEqual(code, 2)
        self.assertIn("No progress", state["reason"])
        self.assertEqual(len(calls), 6)

    def test_stage_timeout_records_stop_and_releases_lock(self):
        code, state, _, _ = self.execute("timeout", {"stage_timeout_seconds": 1})
        self.assertEqual(code, 2)
        self.assertIn("Timeout", state["reason"])
        with run.project_lock(self.root / "project with spaces"):
            pass

    def test_total_budget_prevents_any_model_call(self):
        worker = run.Runner(run.load_settings(self.config_path))
        worker.deadline = 0
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(worker.run(), 2)
        state = run.read_json(worker.directory / "state.json")
        self.assertIn("Total time", state["reason"])
        self.assertFalse(self.trace.exists())

    def test_restart_does_not_reuse_previous_pass(self):
        first = self.execute()
        progress_path = self.root / "project with spaces/docs/progress.md"
        previous = progress_path.read_text(encoding="utf-8")
        self.trace.unlink()
        second = self.execute()
        self.assertEqual(first[0], 0)
        self.assertEqual(second[0], 0)
        self.assertNotEqual(first[1]["run_id"], second[1]["run_id"])
        self.assertEqual(len(second[2]), 4)
        current = progress_path.read_text(encoding="utf-8")
        self.assertIn(first[1]["run_id"], current)
        self.assertIn(second[1]["run_id"], current)
        self.assertGreater(len(current), len(previous))

    def test_following_task_and_final_review_repair_earlier_regression(self):
        tasks = run.read_json(self.root / "tasks.json")
        # These are deliberately task-local checks; FINAL must add the common checker.
        tasks[0]["checks"][0]["argv"] = [sys.executable, "-B", "-m", "unittest", "discover",
                                              "-s", "tests", "-v", "-p", "test_calc.py"]
        tasks[0]["checks"][0]["success_regex"] = r"(?s)\A(?!.*\bskipped\b).*Ran [1-9][0-9]* tests?\b.*\nOK\s*\Z"
        second = copy.deepcopy(tasks[0])
        second["id"] = "T002"
        second["goal"] = "Create marker.ready without breaking addition"
        second["requirements"] = [{"id": "R-MARKER", "text": "marker.ready must be True", "check_ids": ["unit"]}]
        second["checks"][0]["argv"][-1] = "test_marker.py"
        tasks.append(second)
        run.write_json(self.root / "tasks.json", tasks)
        (self.root / "project with spaces/tests/test_marker.py").write_text(
            "import unittest\nfrom marker import ready\nclass TestMarker(unittest.TestCase):\n"
            "    def test_ready(self):\n        self.assertIs(ready, True)\n", encoding="utf-8")
        code, state, calls, worker = self.execute("regression")
        self.assertEqual(code, 0, state)
        self.assertEqual([x["id"] for x in state["completed_tasks"]], ["T001", "T002", "FINAL"])
        final_calls = [x for x in calls if x["context"]["task_id"] == "FINAL"]
        self.assertEqual([x["role"] for x in final_calls], ["reviewer", "builder", "reviewer"])
        self.assertEqual(final_calls[1]["context"]["previous_review"]["review"]["verdict"], "FAIL")
        self.assertTrue((worker.directory / "final-01/reviewer.answer.json").is_file())

    def test_preflight_and_probes_use_fake_cli_and_keep_logs(self):
        c = run.load_settings(self.config_path)
        with contextlib.redirect_stdout(io.StringIO()):
            run.preflight(c, probe_models=True)
        logs = list(c["run_root"].glob("preflight-*"))
        self.assertEqual(len(logs), 1)
        self.assertTrue((logs[0] / "reviewer.stdout.log").is_file())

    @unittest.skipIf(os.name == "nt", "Optional Bash/tmux launcher is Linux-only; native Python runner is covered above")
    def test_shell_launcher_no_tmux_handles_spaces_and_returns_exit_status(self):
        proc = subprocess.run(["bash", str(BASE / "start.sh"), "--no-tmux", "--config", str(self.config_path)],
                              env=dict(os.environ, PYTHON_BIN=sys.executable), capture_output=True, text=True, timeout=30)
        self.assertEqual(proc.returncode, 0, proc.stderr + proc.stdout)
        self.assertIn("COMPLETED", proc.stdout)
        proc = subprocess.run(["bash", str(BASE / "start.sh"), "--no-tmux", "--config", str(self.root / "missing.json")],
                              capture_output=True, text=True, timeout=10)
        self.assertEqual(proc.returncode, 2)


if __name__ == "__main__":
    unittest.main()
