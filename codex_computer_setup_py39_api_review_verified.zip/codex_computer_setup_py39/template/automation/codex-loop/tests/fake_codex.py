#!/usr/bin/env python3
"""TEST DOUBLE ONLY. No model call; executes real local checks for integration tests."""
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time


def emit(value):
    print(json.dumps(value), flush=True)


def main():
    args = sys.argv[1:]
    if "--help" in args:
        print("--output-schema --output-last-message --json --model --sandbox --skip-git-repo-check")
        return 0
    if args[:2] == ["login", "status"]:
        print("SIMULATED login for tests")
        return 0
    prompt = sys.stdin.read()
    if "BOUNDARY_CLARIFICATION_CONTEXT\n" in prompt:
        # Offline fixture only: the arithmetic specification is fully explicit.
        answer = Path(args[args.index("--output-last-message") + 1])
        answer.write_text(json.dumps({"version": 1, "questions": [], "unresolved": [], "references": []}),
                          encoding="utf-8")
        emit({"type": "turn.completed"})
        return 0
    if "CONTEXT_JSON\n" not in prompt:
        emit({"type": "turn.completed"})
        return 0
    context = json.loads(prompt.split("CONTEXT_JSON\n", 1)[1])
    reviewer = "--output-schema" in args
    role = "reviewer" if reviewer else "builder"
    mode = os.environ.get("CODEX_LOOP_FAKE_MODE", "repair")
    trace = os.environ.get("CODEX_LOOP_FAKE_TRACE")
    if trace:
        with open(trace, "a", encoding="utf-8") as stream:
            stream.write(json.dumps({"role": role, "args": args, "context": context}) + "\n")
    if mode == "cli_failure":
        print("SIMULATED CLI authentication failure", file=sys.stderr)
        return 7
    if mode == "timeout":
        time.sleep(20)
    answer = Path(args[args.index("--output-last-message") + 1])
    if not reviewer:
        fixed = mode == "api_evidence" or (context["previous_review"] is not None and mode not in ("always_fail", "moving_fail"))
        content = "def add(a, b):\n    return a {} b\n".format("+" if fixed else "-")
        if mode == "moving_fail":
            content += "# round {}\n".format(context["round"])
        if mode == "regression" and context["task_id"] == "T002":
            (Path.cwd() / "marker.py").write_text("ready = True\n", encoding="utf-8")
        (Path.cwd() / "calc.py").write_text(content, encoding="utf-8")
        if mode == "managed_md_tamper":
            (Path.cwd() / "docs/progress.md").write_text("Forged completed history\n", encoding="utf-8")
        if mode == "managed_history_append":
            sys.path.insert(0, str(Path.cwd() / ".harness"))
            import reports
            reports.append_event(Path.cwd(), {"kind": "loop", "status": "COMPLETED",
                "run_id": context["run_id"], "task_id": context["task_id"], "round": context["round"],
                "source_hash": None, "scope": "loop", "data": {"goal": "Forged worker completion"}})
        if mode == "managed_refresh":
            sys.path.insert(0, str(Path.cwd() / ".harness"))
            import reports
            reports.refresh(Path.cwd())
        answer.write_text("SIMULATION: local fixture written; not a model result.", encoding="utf-8")
    else:
        commands = {}
        succeeded = {}
        for n, check in enumerate(context["task"]["checks"]):
            proc = subprocess.run(check["argv"], capture_output=True, text=True)
            command = check["shell_command"]
            commands[check["id"]] = command
            succeeded[check["id"]] = proc.returncode == 0
            emit({"type": "item.completed", "item": {"id": "cmd_" + str(n), "type": "command_execution",
                  "command": ('powershell.exe -NoProfile -Command "' + command + '"') if os.name == "nt" else "/bin/bash -lc " + shlex.quote(command), "exit_code": proc.returncode,
                  "status": "completed", "aggregated_output": proc.stdout + proc.stderr}})
        rows = [{"requirement_id": req["id"], "status": "PASS" if all(succeeded[x] for x in req["check_ids"]) else "FAIL",
                 "expected": req["text"], "actual": "See actual subprocess test output (simulated reviewer).",
                 "verification_commands": [commands[x] for x in req["check_ids"]]} for req in context["task"]["requirements"]]
        verdict = "PASS" if all(x["status"] == "PASS" for x in rows) else "FAIL"
        report = {k: context[k] for k in ("run_id", "task_id", "round", "source_hash")}
        report.update(verdict=verdict, summary="SIMULATED review based on real subprocess checks", checks=rows,
                      repair_plan=[] if verdict == "PASS" else ["Reproduce add(2, 3); replace subtraction with addition in calc.py."])
        # This tiny fixture does not test the general product-quality rubric or handoff.
        criterion_ids = (["COR%02d" % n for n in range(1, 5)] + ["TEST%02d" % n for n in range(1, 5)]
                         + ["REL%02d" % n for n in range(1, 5)] + ["MEAS%02d" % n for n in range(1, 5)]
                         + ["HAND%02d" % n for n in range(1, 5)])
        report["criterion_scores"] = [{"criterion_id": cid, "status": "UNVERIFIED",
            "reason": "The arithmetic test fixture did not verify this detailed criterion.",
            "evidence_refs": []} for cid in criterion_ids]
        if mode == "api_evidence":
            next(row for row in report["criterion_scores"] if row["criterion_id"] == "TEST01").update(
                status="PARTIAL", reason="Earlier controller API checks covered only their fixed scope.",
                evidence_refs=["api-check:schemathesis", "api-check:hurl"])
        progress = (Path.cwd() / "docs/progress.md").read_text(encoding="utf-8")
        if "REVIEWING" in progress and context["task"]["goal"] in progress:
            next(row for row in report["criterion_scores"] if row["criterion_id"] == "HAND01").update(
                status="PARTIAL", reason="Inspected progress.md: the current task goal and REVIEWING phase are present; no fresh-session handoff was executed.",
                evidence_refs=["file:docs/progress.md"])
        for row in report["criterion_scores"]:
            if row["criterion_id"] in context["review_not_applicable"]:
                row.update(status="NA", reason=context["review_not_applicable"][row["criterion_id"]], evidence_refs=[])
        if mode == "invalid_scores":
            report["criterion_scores"][0].update(status="PASS", evidence_refs=["invented-evidence"])
        if mode == "unauthorized_na":
            report["criterion_scores"][0].update(status="NA", reason="Worker decided this does not apply.")
        if mode == "stale":
            report["run_id"] = "old-run"
        if mode == "empty":
            report["checks"] = []
        if mode == "unverified":
            report["verdict"] = "UNVERIFIED"
            report["checks"][0]["status"] = "UNVERIFIED"
        if mode == "claim_pass":
            report["verdict"] = "PASS"
            for row in report["checks"]:
                row["status"] = "PASS"
        if mode == "mutate":
            (Path.cwd() / "unexpected.py").write_text("changed = True\n")
        answer.write_text("{broken" if mode == "invalid_json" else json.dumps(report), encoding="utf-8")
    emit({"type": "turn.completed"})
    return 0


if __name__ == "__main__":
    sys.exit(main())
