import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

BASE = Path(__file__).resolve().parents[1]
KIT = BASE.parents[1]
spec = importlib.util.spec_from_file_location("check_api", BASE / "check_api.py")
api = importlib.util.module_from_spec(spec)
spec.loader.exec_module(api)


class ParserTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.xml = Path(self.temporary.name) / "report.xml"

    def parse(self, text):
        self.xml.write_text(text, encoding="utf-8")
        return api.parse_junit(self.xml)

    def test_actual_testcase_counts(self):
        self.assertEqual(self.parse('<testsuites><testsuite tests="2" failures="1" errors="0" skipped="0">'
                                    '<testcase name="one"/><testcase name="two"><failure/></testcase>'
                                    '</testsuite></testsuites>'),
                         {"collected": 2, "passed": 1, "failed": 1, "skipped": 0})

    def test_zero_tests_cannot_pass(self):
        with self.assertRaisesRegex(ValueError, "zero"):
            self.parse('<testsuite tests="0"/>')

    def test_declared_counts_cannot_invent_execution(self):
        with self.assertRaisesRegex(ValueError, "disagrees"):
            self.parse('<testsuite tests="2"><testcase name="one"/></testsuite>')

    def test_duplicate_testcase_rejected(self):
        with self.assertRaisesRegex(ValueError, "duplicate"):
            self.parse('<testsuite><testcase name="one"/><testcase name="one"/></testsuite>')

    def test_skip_is_distinct_from_pass(self):
        self.assertEqual(self.parse('<testsuite><testcase name="one"><skipped/></testcase></testsuite>'),
                         {"collected": 1, "passed": 0, "failed": 0, "skipped": 1})

    def test_entities_rejected(self):
        with self.assertRaisesRegex(ValueError, "DTD"):
            self.parse('<!DOCTYPE testsuite [<!ENTITY x "x">]><testsuite/>')


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="api review spaces ")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name) / "project"
        self.root.mkdir()
        shutil.copytree(KIT / "template/.harness", self.root / ".harness",
                        ignore=shutil.ignore_patterns("tests", "work", "__pycache__"))
        shutil.copy(BASE / "tests/api_fixture.py", self.root / "server.py")
        shutil.copy(BASE / "tests/smoke.hurl", self.root / "smoke.hurl")
        self.config = {"version": 1, "server": {"argv": ["{python}", "server.py", "--port", "{port}", "--work", "{work}"],
                    "readiness_path": "/health", "timeout_seconds": 15}, "schema_path": "/openapi.json",
                    "scenarios": ["smoke.hurl"], "timeout_seconds": 3, "max_examples": 3}
        self.write_config()
        (self.root / api.TOOLS).write_text(json.dumps({"version": 1, "python": sys.executable, "hurl": sys.executable,
                      "schemathesis_version": "4.4.4", "hurl_version": "8.1.0"}), encoding="utf-8")
        self.commands = []
        self.result_kind = "pass"

    def write_config(self):
        (self.root / api.CONFIG).write_text(json.dumps(self.config), encoding="utf-8")

    def fake_command(self, processes, command, work, env, prefix, timeout):
        self.commands.append(command)
        out, err = work / (prefix + ".stdout.log"), work / (prefix + ".stderr.log")
        out.write_text("", encoding="utf-8")
        err.write_text("", encoding="utf-8")
        if prefix.endswith("-version"):
            name = prefix[:-8]
            out.write_text(name + " " + api.VERSIONS[name] + "\n", encoding="utf-8")
            return 0, out, err
        if self.result_kind == "timeout":
            raise subprocess.TimeoutExpired(command, timeout)
        xml = Path(command[command.index("--report-junit-path" if prefix == "schemathesis" else "--report-junit") + 1])
        child = {"pass": "", "failure": "<failure/>", "skip": "<skipped/>"}[self.result_kind]
        xml.write_text('<testsuites><testsuite><testcase name="real parsed case">' + child + '</testcase></testsuite></testsuites>', encoding="utf-8")
        return (1 if prefix == "schemathesis" else 4) if self.result_kind == "failure" else 0, out, err

    def run_fake_tools(self):
        with mock.patch.object(api, "run_command", side_effect=self.fake_command):
            return api.run(self.root)

    def test_pass_tracks_fixed_scenarios_source_and_real_artifacts(self):
        report, code = self.run_fake_tools()
        self.assertEqual(code, 0, report)
        self.assertEqual(report["status"], "passed")
        self.assertEqual(report["source_hash"], report["source_hash_after"])
        self.assertEqual(report["scenario_files"], ["smoke.hurl"])
        schemathesis_command = report["checks"][0]["commands"][0]
        isolated_config = Path(schemathesis_command[schemathesis_command.index("--config-file") + 1])
        self.assertEqual(isolated_config.read_text(), "")
        for check in report["checks"]:
            self.assertEqual(check["counts"], {"collected": 1, "passed": 1, "failed": 0, "skipped": 0})
            self.assertEqual(len(check["artifacts"]), 3)
            for artifact in check["artifacts"]:
                self.assertEqual(api.sha(self.root / artifact["path"]), artifact["sha256"])
        self.assertFalse(api.load_processes(self.root).check_process_running(report["server"]["pid"]))

    def test_assertion_failures_are_findings(self):
        self.result_kind = "failure"
        report, code = self.run_fake_tools()
        self.assertEqual(code, 1, report)
        self.assertEqual(report["status"], "failed")
        self.assertTrue(all(c["counts"]["failed"] == 1 for c in report["checks"]))

    def test_all_skipped_is_error(self):
        self.result_kind = "skip"
        report, code = self.run_fake_tools()
        self.assertEqual(code, 2, report)
        self.assertIn("skipped", report["error"])

    def test_preparation_failure_leaves_tools_not_run(self):
        self.config["server"]["argv"].extend(["--mode", "notready"])
        self.config["server"]["timeout_seconds"] = 0.2
        self.write_config()
        report, code = self.run_fake_tools()
        self.assertEqual(code, 2, report)
        self.assertTrue(all(c["status"] == "NOT_RUN" for c in report["checks"]))
        self.assertFalse(api.load_processes(self.root).check_process_running(report["server"]["pid"]))

    def test_source_write_rejects_otherwise_passing_run(self):
        self.config["server"]["argv"].extend(["--mode", "mutate"])
        self.write_config()
        report, code = self.run_fake_tools()
        self.assertEqual(code, 2, report)
        self.assertIn("source changed", report["error"])

    def test_timeout_is_error_with_logs_and_stopped_server(self):
        self.result_kind = "timeout"
        report, code = self.run_fake_tools()
        self.assertEqual(code, 2, report)
        self.assertTrue(all(c["status"] == "FAIL" for c in report["checks"]))
        self.assertTrue(all(len(c["artifacts"]) == 2 for c in report["checks"]))
        self.assertFalse(api.load_processes(self.root).check_process_running(report["server"]["pid"]))

    def test_missing_or_empty_scenario_is_configuration_error(self):
        for names in ([], ["missing.hurl"]):
            self.config["scenarios"] = names
            self.write_config()
            report, code = self.run_fake_tools()
            self.assertEqual(code, 2, report)
            self.assertFalse(report.get("run_id"))

    def test_scenarios_cannot_hide_in_any_excluded_directory(self):
        for directory in ("api-tests/node_modules", "api-tests/.venv", "work", ".harness/work"):
            path = self.root / directory / "hidden.hurl"
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(self.root / "smoke.hurl", path)
            self.config["scenarios"] = [path.relative_to(self.root).as_posix()]
            self.write_config()
            report, code = self.run_fake_tools()
            self.assertEqual(code, 2, report)

    def test_shell_string_and_external_url_rejected(self):
        self.config["server"]["argv"] = "python server.py"
        self.write_config()
        self.assertEqual(self.run_fake_tools()[1], 2)
        self.config["server"]["argv"] = ["{python}", "server.py", "--port", "{port}"]
        self.config["schema_path"] = "https://example.org/schema.json"
        self.write_config()
        self.assertEqual(self.run_fake_tools()[1], 2)

    def test_hurl_external_custom_method_redirect_and_origin_override_rejected(self):
        for text in ('PROPFIND https://example.org/\nHTTP 200\n',
                     'GET {{base_url}}/\nHTTP 200\nGET https://example.org/ # comment\nHTTP 200\n',
                     'GET {{base_url}}/\n[Options]\nlocation: true\nHTTP 200\n',
                     'GET {{base_url}}/\nHTTP 200\n[Captures]\nbase_url: jsonpath "$.url"\n'):
            (self.root / "smoke.hurl").write_text(text, encoding="utf-8")
            report, code = self.run_fake_tools()
            self.assertEqual(code, 2, report)
            self.assertFalse(report.get("run_id"))

    def test_external_schema_reference_rejected_before_tools(self):
        schema = {"openapi": "3.0.3", "components": {"schemas": {"X": {"$ref": "https://example.org/schema.json"}}}}
        response = mock.MagicMock()
        response.__enter__.return_value.read1.side_effect = [json.dumps(schema).encode(), b""]
        opener = mock.Mock()
        opener.open.return_value = response
        with mock.patch.object(api.urllib.request, "build_opener", return_value=opener):
            with self.assertRaisesRegex(ValueError, "External OpenAPI"):
                api.local_schema("http://127.0.0.1/openapi.json", self.root / "should-not-exist.json", 1)
        self.assertFalse((self.root / "should-not-exist.json").exists())

    def test_wrong_tool_version_fails_before_server(self):
        original = self.fake_command
        def wrong(processes, command, work, env, prefix, timeout):
            code, out, err = original(processes, command, work, env, prefix, timeout)
            out.write_text("schemathesis 99.0.0\n", encoding="utf-8")
            return code, out, err
        with mock.patch.object(api, "run_command", side_effect=wrong):
            report, code = api.run(self.root)
        self.assertEqual(code, 2)
        self.assertNotIn("server", report)

    def test_subprocess_timeout_reaps_its_child(self):
        processes = api.load_processes(self.root)
        work = self.root / ".harness/work/process-test"
        work.mkdir(parents=True)
        env = api.environment(work)
        child_pid = work / "child.pid"
        child = ("import os,time;from pathlib import Path;p=Path({!r});"
                 "p.with_suffix('.tmp').write_text(str(os.getpid()));p.with_suffix('.tmp').replace(p);time.sleep(60)").format(str(child_pid))
        parent = "import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',{}]);time.sleep(60)".format(repr(child))
        actual_wait = api.wait_owned
        ready_pid = []

        def wait_after_child_ready(process, command, timeout):
            deadline = time.monotonic() + 15
            while api.poll_owned(process) is None and time.monotonic() < deadline:
                try:
                    ready_pid.append(int(child_pid.read_text()))
                    break
                except (FileNotFoundError, PermissionError, ValueError):
                    pass
                time.sleep(0.05)
            self.assertTrue(ready_pid, "Child did not publish readiness before timeout test")
            self.assertTrue(self.child_running(processes, ready_pid[0]))
            return actual_wait(process, command, timeout)

        with mock.patch.object(api, "wait_owned", side_effect=wait_after_child_ready):
            with self.assertRaises(subprocess.TimeoutExpired):
                api.run_command(processes, [sys.executable, "-B", "-c", parent], work, env, "timeout", 2)
        self.assertTrue(child_pid.is_file())
        pid = ready_pid[0]
        deadline = time.monotonic() + 3
        while self.child_running(processes, pid) and time.monotonic() < deadline:
            time.sleep(0.05)
        self.assertFalse(self.child_running(processes, pid))

    @staticmethod
    def child_running(processes, pid):
        if sys.platform.startswith("linux"):
            status = Path("/proc") / str(pid) / "stat"
            try:
                if status.read_text().rsplit(")", 1)[1].split()[0] == "Z":
                    return False
            except (FileNotFoundError, ProcessLookupError):
                return False
        return processes.owner_running(pid)

    def test_successful_command_preserves_exit_code_and_reaps_grandchild(self):
        processes = api.load_processes(self.root)
        work = self.root / ".harness/work/process-normal"
        work.mkdir(parents=True)
        env = api.environment(work)
        child_pid = work / "child.pid"
        child = ("import os,time;from pathlib import Path;p=Path({!r});"
                 "p.with_suffix('.tmp').write_text(str(os.getpid()));p.with_suffix('.tmp').replace(p);time.sleep(60)").format(str(child_pid))
        parent = ("import subprocess,sys,time\nfrom pathlib import Path\n"
                  "subprocess.Popen([sys.executable,'-c',{}])\n"
                  "ready=Path({!r})\ndeadline=time.monotonic()+15\n"
                  "while not ready.exists() and time.monotonic()<deadline: time.sleep(0.05)\n"
                  "sys.exit(7 if ready.exists() else 8)\n").format(repr(child), str(child_pid))
        code, _, _ = api.run_command(processes, [sys.executable, "-B", "-c", parent], work, env, "normal", 20)
        self.assertEqual(code, 7)
        self.assertTrue(child_pid.is_file())
        pid = int(child_pid.read_text())
        deadline = time.monotonic() + 3
        while self.child_running(processes, pid) and time.monotonic() < deadline:
            time.sleep(0.05)
        self.assertFalse(self.child_running(processes, pid))

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux SIGKILL/group ownership regression")
    def test_outer_sigkill_reaps_owned_server_tool_and_grandchildren(self):
        processes = api.load_processes(self.root)
        work = self.root / ".harness/work/process-outer"
        work.mkdir(parents=True)
        env = api.environment(work)
        marker = work / "pids.json"
        child = "import time;time.sleep(60)"
        command = ("import os,subprocess,sys,time,json;from pathlib import Path;"
                   "p=subprocess.Popen([sys.executable,'-c',{}]);Path({!r}).write_text(json.dumps([os.getpid(),p.pid]));time.sleep(60)").format(repr(child), str(marker))
        owner = ("import importlib.util;from pathlib import Path;"
                 "s=importlib.util.spec_from_file_location('owned_api',{!r});m=importlib.util.module_from_spec(s);s.loader.exec_module(m);"
                 "p=m.load_processes(Path({!r}));"
                 "m.run_command(p,{!r},Path({!r}),dict(__import__('os').environ),'outer',45)").format(
                     str(BASE / "check_api.py"), str(self.root), [sys.executable, "-B", "-c", command], str(work))
        process = subprocess.Popen([sys.executable, "-B", "-c", owner], env=env,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        try:
            deadline = time.monotonic() + 15
            while not marker.exists() and process.poll() is None and time.monotonic() < deadline:
                time.sleep(0.05)
            self.assertTrue(marker.exists(), "Owned command did not start")
            pids = json.loads(marker.read_text())
            self.assertTrue(all(self.child_running(processes, pid) for pid in pids))
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
            deadline = time.monotonic() + 5
            while any(self.child_running(processes, pid) for pid in pids) and time.monotonic() < deadline:
                time.sleep(0.05)
            self.assertTrue(all(not self.child_running(processes, pid) for pid in pids), pids)
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)


if __name__ == "__main__":
    unittest.main()
