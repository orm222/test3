import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("api_setup_under_test", HERE / "setup_tools.py")
setup = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(setup)


class SetupTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        self.project = self.root / "project"
        self.project.mkdir()
        self.tools = self.root / "tools"
        self.tools.mkdir()
        self.executable = self.tools / "tool.exe"
        self.executable.write_bytes(b"fixture only; never executed")
        self.descriptor = {"version": 1, "python": str(self.executable), "hurl": str(self.executable),
                           "schemathesis_version": "4.4.4", "hurl_version": "8.1.0"}
        self.config = {"version": 1, "server": {"argv": ["{python}", "server.py", "{port}"],
            "readiness_path": "/health", "timeout_seconds": 15}, "schema_path": "/openapi.json",
            "scenarios": ["api-tests/smoke.hurl"], "timeout_seconds": 60}
        self.write("api-tests/smoke.hurl", "GET {{base_url}}/health\nHTTP 200\n")
        self.write_json(".harness/checks.json", {"checks": [{"name": "original", "command": ["python", "tests.py"]}], "inputs": ["requirements.txt"]})
        self.write_json(".harness/acceptance.json", {"version": 1, "checker_argv": ["{python}", "-B", "check.py"], "protected_paths": ["tests"]})
        self.write_json("automation/codex-loop/config.json", {"builder_model": "unchanged", "protected_paths": ["tests"]})
        self.write_json("automation/codex-loop/tasks.json", [{"id": "T1", "checks": [{"id": "original"}]}])
        self.config_file = self.root / "supplied.json"
        self.config_file.write_bytes(setup.encoded(self.config))

    def write(self, relative, data):
        target = self.project / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(data, encoding="utf-8")
        return target

    def write_json(self, relative, value):
        return self.write(relative, json.dumps(value))

    def enable(self):
        with mock.patch.object(setup, "validate_install", return_value=self.descriptor):
            return setup.enable(self.project, self.tools, self.config_file)

    def test_enable_preserves_checks_tasks_and_registers_protected_inputs(self):
        tasks = (self.project / "automation/codex-loop/tasks.json").read_bytes()
        self.enable()
        checks = setup.read(self.project / ".harness/checks.json")
        self.assertEqual(checks["checks"][0], {"name": "original", "command": ["python", "tests.py"]})
        self.assertEqual(checks["checks"][1]["command"], setup.COMMAND)
        self.assertEqual(checks["checks"][1]["protocol"], "harness-api-review/v1")
        for path in [setup.RUNNER, setup.CONFIG, setup.TOOLS, "api-tests/smoke.hurl"]:
            self.assertIn(path, checks["inputs"])
            self.assertIn(path, setup.read(self.project / ".harness/acceptance.json")["protected_paths"])
            self.assertIn(path, setup.read(self.project / "automation/codex-loop/config.json")["protected_paths"])
        self.assertEqual(tasks, (self.project / "automation/codex-loop/tasks.json").read_bytes())

    def test_reenable_explicitly_updates_machine_paths_without_duplicates(self):
        self.enable()
        before = setup.read(self.project / ".harness/checks.json")
        other = self.tools / "other.exe"
        other.write_bytes(b"fixture")
        self.descriptor["hurl"] = str(other)
        self.enable()
        self.assertEqual(before, setup.read(self.project / ".harness/checks.json"))
        self.assertEqual(str(other), setup.read(self.project / setup.TOOLS)["hurl"])

    def test_timeout_covers_all_fixed_scenarios_and_server_startup(self):
        self.write("api-tests/second.hurl", "GET {{base_url}}/health\nHTTP 200\n")
        self.config["scenarios"].append("api-tests/second.hurl")
        self.config_file.write_bytes(setup.encoded(self.config))
        self.enable()
        registered = setup.read(self.project / ".harness/checks.json")["checks"][1]
        self.assertGreaterEqual(registered["timeout_seconds"], 15 + 3 * 60 + 60)

    def test_runner_collision_has_no_partial_config_changes(self):
        before = (self.project / ".harness/checks.json").read_bytes()
        self.write(setup.RUNNER, "user code")
        with self.assertRaisesRegex(setup.SetupError, "refusing to overwrite"):
            self.enable()
        self.assertEqual(before, (self.project / ".harness/checks.json").read_bytes())
        self.assertFalse((self.project / setup.CONFIG).exists())
        self.assertEqual("user code", (self.project / setup.RUNNER).read_text())

    def test_foreign_configuration_is_preserved(self):
        self.write(setup.CONFIG, "user-owned document")
        with self.assertRaisesRegex(setup.SetupError, "not owned"):
            self.enable()
        self.assertEqual("user-owned document", (self.project / setup.CONFIG).read_text())

    def test_invalid_remote_scenario_or_config_fails_before_mutation(self):
        before = (self.project / ".harness/checks.json").read_bytes()
        self.write("api-tests/smoke.hurl", "GET https://example.invalid/\nHTTP 200\n")
        with self.assertRaises(ValueError):
            self.enable()
        self.assertEqual(before, (self.project / ".harness/checks.json").read_bytes())
        self.assertFalse((self.project / setup.RUNNER).exists())

    def test_escape_scenario_and_embedded_tools_directory_are_rejected(self):
        self.config["scenarios"] = ["../outside.hurl"]
        self.config_file.write_bytes(setup.encoded(self.config))
        with self.assertRaises(ValueError):
            self.enable()
        with self.assertRaisesRegex(setup.SetupError, "outside"):
            setup.enable(self.project, self.project / "tools", self.config_file)

    def test_scenarios_in_any_source_hash_excluded_directory_are_rejected(self):
        original = (self.project / ".harness/checks.json").read_bytes()
        for excluded in (".git", ".venv", "venv", "node_modules", "__pycache__",
                         ".pytest_cache", ".ruff_cache", ".mypy_cache", ".VENV", "NODE_MODULES"):
            with self.subTest(excluded=excluded):
                relative = "api-tests/" + excluded + "/hidden.hurl"
                self.write(relative, "GET {{base_url}}/health\nHTTP 200\n")
                self.config["scenarios"] = [relative]
                self.config_file.write_bytes(setup.encoded(self.config))
                with self.assertRaises(ValueError):
                    self.enable()
                self.assertEqual(original, (self.project / ".harness/checks.json").read_bytes())

    def test_archive_traversal_is_rejected_before_any_extraction(self):
        archive = self.root / "unsafe.zip"
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr("safe.txt", "first")
            output.writestr("../escaped.txt", "bad")
        destination = self.root / "extracted"
        with self.assertRaises(ValueError):
            setup.extract_archive(archive, destination)
        self.assertFalse(destination.exists())
        self.assertFalse((self.root / "escaped.txt").exists())

    def test_archive_symlink_is_rejected(self):
        archive = self.root / "link.zip"
        with zipfile.ZipFile(archive, "w") as output:
            item = zipfile.ZipInfo("link")
            item.create_system = 3
            item.external_attr = 0o120777 << 16
            output.writestr(item, "outside")
        with self.assertRaisesRegex(setup.SetupError, "link"):
            setup.extract_archive(archive, self.root / "extracted")

    def test_official_lock_manifest_and_exact_versions_match(self):
        manifest = setup.read(HERE / "tools-manifest.json")
        self.assertEqual("4.4.4", manifest["schemathesis_version"])
        self.assertEqual("8.1.0", manifest["hurl_version"])
        for item in manifest["platforms"].values():
            self.assertEqual(item["requirements_sha256"], setup.digest(HERE / item["requirements"]))
            self.assertEqual(64, len(item["sha256"]))
            self.assertTrue(item["url"].startswith("https://github.com/Orange-OpenSource/hurl/releases/download/8.1.0/"))
        lines = (HERE / "requirements-py39.lock").read_text().splitlines()
        self.assertEqual(54, sum("==" in line for line in lines))
        self.assertTrue(any(line.startswith("schemathesis==4.4.4") for line in lines))

    def test_bad_download_hash_leaves_archive_unexecuted(self):
        import io
        archive = self.root / "download.zip"
        with mock.patch.object(setup.urllib.request, "urlopen", return_value=io.BytesIO(b"wrong")):
            with self.assertRaisesRegex(setup.SetupError, "SHA-256"):
                setup.download("https://github.com/Orange-OpenSource/hurl/releases/download/8.1.0/example.zip", archive, "0" * 64)

    def test_json_duplicate_keys_and_invalid_constants_rejected(self):
        for text in ('{"version":1,"version":1}', '{"timeout_seconds":NaN}'):
            self.config_file.write_text(text)
            with self.assertRaises(ValueError):
                setup.read(self.config_file)

    def test_install_receipt_reuse_requires_exact_files_and_version(self):
        python = setup.tool_python(self.tools)
        python.parent.mkdir(parents=True)
        python.write_bytes(b"test interpreter is never run")
        descriptor = dict(self.descriptor, python=str(python))
        manifest = setup.read(HERE / "tools-manifest.json")
        lock = HERE / manifest["platforms"][setup.platform_key()]["requirements"]
        receipt = {"version": 1, "platform": setup.platform_key(), "tools": descriptor,
            "manifest_sha256": setup.digest(HERE / "tools-manifest.json"), "lock_sha256": setup.digest(lock),
            "files": setup.inventory(self.tools)}
        (self.tools / "installation.json").write_bytes(setup.encoded(receipt))
        self.assertEqual(descriptor, setup.validate_install(self.tools))
        self.executable.write_bytes(b"changed binary")
        with self.assertRaisesRegex(setup.SetupError, "files changed"):
            setup.validate_install(self.tools)

    def test_nonroot_installation_named_file_is_in_inventory(self):
        target = self.tools / "nested/installation.json"
        target.parent.mkdir()
        target.write_text("must be protected")
        self.assertIn("nested/installation.json", setup.inventory(self.tools))

    def test_inventory_rejects_redirected_directory_before_descending(self):
        outside = self.root / "outside"
        outside.mkdir()
        (outside / "secret.txt").write_text("not a tool file")
        try:
            (self.tools / "linked").symlink_to(outside, target_is_directory=True)
        except OSError:
            self.skipTest("Symlink permission is unavailable")
        with self.assertRaisesRegex(setup.SetupError, "Redirected"):
            setup.inventory(self.tools)

    def test_inventory_hashes_nested_files_and_excludes_only_runtime_cache(self):
        nested = self.tools / "nested"
        nested.mkdir()
        (nested / "code.py").write_text("original")
        (nested / "__pycache__").mkdir()
        (nested / "__pycache__/code.pyc").write_bytes(b"cache")
        initial = setup.inventory(self.tools)
        self.assertEqual(set(initial), {"tool.exe", "nested/code.py"})
        (nested / "code.py").write_text("changed")
        self.assertNotEqual(initial, setup.inventory(self.tools))

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux venv alias")
    def test_inventory_allows_only_standard_internal_venv_lib64_alias(self):
        library = self.tools / ".venv/lib"
        library.mkdir(parents=True)
        (library / "module.py").write_text("protected")
        before = setup.inventory(self.tools)
        alias = self.tools / ".venv/lib64"
        alias.symlink_to("lib", target_is_directory=True)
        self.assertEqual(before, setup.inventory(self.tools))
        alias.unlink()
        outside = self.root / "outside-library"
        outside.mkdir()
        alias.symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(setup.SetupError, "Redirected"):
            setup.inventory(self.tools)

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux venv alias")
    def test_standard_alias_cannot_hide_redirected_lib_directory(self):
        venv = self.tools / ".venv"
        venv.mkdir()
        outside = self.root / "outside-library"
        outside.mkdir()
        (venv / "lib").symlink_to(outside, target_is_directory=True)
        (venv / "lib64").symlink_to("lib", target_is_directory=True)
        with self.assertRaisesRegex(setup.SetupError, "Redirected"):
            setup.inventory(self.tools)


if __name__ == "__main__":
    unittest.main()
