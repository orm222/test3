"""Disposable local test application; never included in project attachment."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--work", required=True)
    parser.add_argument("--mode", default="good", choices=("good", "server500", "wrongbody", "notready", "slow", "mutate"))
    args = parser.parse_args()
    Path(args.work, "fixture-started.txt").write_text("started", encoding="utf-8")
    if args.mode == "mutate":
        Path("mutation.txt").write_text("unexpected application source write", encoding="utf-8")

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *values):
            pass

        def reply(self, status, data):
            raw = json.dumps(data).encode("utf-8")
            self.send_response(status)
            if status == 405:
                self.send_header("Allow", "GET")
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            try:
                self.wfile.write(raw)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            if self.path == "/health":
                return self.reply(503 if args.mode == "notready" else 200, {"ready": True})
            if self.path == "/openapi.json":
                return self.reply(200, {"openapi": "3.0.3", "info": {"title": "Test fixture", "version": "1"},
                    "paths": {"/ping": {"get": {"responses": {"200": {"description": "OK", "content": {
                        "application/json": {"schema": {"type": "object", "required": ["message"],
                            "properties": {"message": {"type": "string"}}, "additionalProperties": False}}}}}}}}})
            if self.path.split("?")[0] == "/ping":
                if args.mode == "slow":
                    time.sleep(20)
                return self.reply(500 if args.mode == "server500" else 200,
                                  {"message": "wrong" if args.mode == "wrongbody" else "hello"})
            self.reply(404, {"error": "not found"})

        def do_POST(self):
            self.reply(405, {"error": "method not allowed"})

        do_PUT = do_DELETE = do_PATCH = do_OPTIONS = do_TRACE = do_HEAD = do_POST

    ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
