#!/usr/bin/env python3
"""Explicit, isolated installation and registration of optional API checks."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
import zipfile

HERE = Path(__file__).resolve().parent
KIT = HERE.parents[1]
CONFIG = ".harness/api-review.json"
TOOLS = ".harness/api-tools.json"
RUNNER = ".harness/api-review/check_api.py"
COMMAND = ["{python}", "-B", RUNNER]


class SetupError(ValueError):
    pass


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def read(path):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise SetupError("Duplicate JSON key: " + key)
            value[key] = item
        return value
    def invalid(value):
        raise SetupError("Invalid JSON number: " + value)
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=pairs, parse_constant=invalid)


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def safe_path(path):
    path = Path(path).absolute()
    if path.resolve() != path or any(item.is_symlink() for item in (path,) + tuple(path.parents)):
        raise SetupError("Redirected/symlink paths are not allowed: " + str(path))
    return path


def project_path(root, relative):
    if not isinstance(relative, str) or not relative or "\\" in relative:
        raise SetupError("Use a project-relative POSIX path")
    value = PurePosixPath(relative)
    if value.is_absolute() or ".." in value.parts or ":" in relative or any(
            part.casefold() in (".git", ".venv", "venv", "node_modules", "__pycache__",
                                ".pytest_cache", ".ruff_cache", ".mypy_cache") for part in value.parts):
        raise SetupError("Unsafe project path: " + relative)
    if relative.casefold().startswith(("work/", ".harness/work/")):
        raise SetupError("Inputs cannot be stored in runtime directories")
    path = safe_path(root / relative)
    if not path.is_relative_to(root):
        raise SetupError("Path escapes project")
    return path


def atomic(path, data):
    path = safe_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".api-setup-", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as target:
            target.write(data)
        os.replace(temporary, str(path))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def platform_key():
    if platform.machine().lower() not in ("amd64", "x86_64"):
        raise SetupError("This tool lock supports x86_64 Windows/Linux only")
    if sys.platform == "win32":
        return "windows-x86_64"
    if sys.platform.startswith("linux"):
        return "linux-x86_64"
    raise SetupError("This tool lock supports Windows/Linux only")


def tool_python(directory):
    return directory / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def harness_setup():
    spec = importlib.util.spec_from_file_location("optional_api_setup_env", KIT / "setup_env.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def download(url, destination, expected):
    if not url.startswith("https://github.com/Orange-OpenSource/hurl/releases/download/8.1.0/"):
        raise SetupError("Unexpected Hurl download source")
    with urllib.request.urlopen(url, timeout=60) as response, Path(destination).open("wb") as output:
        shutil.copyfileobj(response, output)
    if digest(destination) != expected:
        raise SetupError("Hurl archive SHA-256 mismatch; nothing has been extracted")


def extract_archive(archive, destination):
    destination = safe_path(destination)
    with (zipfile.ZipFile(archive) if str(archive).endswith(".zip") else tarfile.open(archive, "r:gz")) as bundle:
        members = bundle.infolist() if isinstance(bundle, zipfile.ZipFile) else bundle.getmembers()
        # Validate the complete archive before writing any member.
        for item in members:
            name = item.filename if isinstance(bundle, zipfile.ZipFile) else item.name
            target = project_path(destination, name.rstrip("/"))
            mode = item.external_attr >> 16 if isinstance(bundle, zipfile.ZipFile) else item.mode
            if stat.S_ISLNK(mode) or (not isinstance(bundle, zipfile.ZipFile) and not (item.isfile() or item.isdir())):
                raise SetupError("Archive contains a link or special file")
        for item in members:
            name = item.filename if isinstance(bundle, zipfile.ZipFile) else item.name
            target = project_path(destination, name.rstrip("/"))
            directory = item.is_dir() if isinstance(bundle, zipfile.ZipFile) else item.isdir()
            if directory:
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            source = bundle.open(item) if isinstance(bundle, zipfile.ZipFile) else bundle.extractfile(item)
            with source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
            if os.name != "nt":
                target.chmod(0o755 if item.mode & 0o111 else 0o644)


def inventory(directory):
    directory = safe_path(directory)
    pending, files = [directory], {}
    while pending:
        with os.scandir(pending.pop()) as entries:
            for entry in entries:
                path = Path(entry.path)
                if entry.name == "__pycache__" or path.suffix == ".pyc" or path == directory / "installation.json":
                    continue
                info = entry.stat(follow_symlinks=False)
                # Linux venv creates this internal alias even with --copies; hash lib once.
                if (sys.platform.startswith("linux") and path == directory / ".venv/lib64"
                        and stat.S_ISLNK(info.st_mode)):
                    target = directory / ".venv/lib"
                    if (os.readlink(path) == "lib" and target.is_dir() and not target.is_symlink()
                            and target.resolve() == target.absolute()):
                        continue
                if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                    raise SetupError("Redirected/symlink tool path: " + str(path))
                if stat.S_ISDIR(info.st_mode):
                    pending.append(path)
                elif stat.S_ISREG(info.st_mode):
                    files[path.relative_to(directory).as_posix()] = digest(path)
                else:
                    raise SetupError("Tool inventory contains a special file: " + str(path))
    return dict(sorted(files.items()))


def validate_install(directory):
    directory = safe_path(directory)
    receipt = read(directory / "installation.json")
    manifest = read(HERE / "tools-manifest.json")
    key = platform_key()
    if not isinstance(receipt, dict) or type(receipt.get("version")) is not int or receipt.get("version") != 1 or receipt.get("platform") != key:
        raise SetupError("Tools belong to another OS/version; install into a separate tools directory")
    lock = HERE / manifest["platforms"][key]["requirements"]
    if digest(lock) != manifest["platforms"][key]["requirements_sha256"]:
        raise SetupError("Requirements lock SHA-256 mismatch")
    if receipt.get("manifest_sha256") != digest(HERE / "tools-manifest.json") or receipt.get("lock_sha256") != digest(lock):
        raise SetupError("Installed tools do not match this kit's pinned manifest/lock")
    if receipt.get("files") != inventory(directory):
        raise SetupError("Installed tool files changed; use a new tools directory")
    descriptor = receipt.get("tools")
    if not isinstance(descriptor, dict) or Path(descriptor.get("python", "")) != tool_python(directory):
        raise SetupError("Invalid installed tool descriptor")
    if (descriptor.get("schemathesis_version") != "4.4.4" or descriptor.get("hurl_version") != "8.1.0"
            or type(descriptor.get("version")) is not int or descriptor["version"] != 1):
        raise SetupError("Installed tool versions differ from the pinned versions")
    for name in ("python", "hurl"):
        target = safe_path(descriptor[name])
        if not target.is_file() or not target.is_relative_to(directory):
            raise SetupError("Missing or escaped tool executable")
    return descriptor


def install(directory, python39):
    directory = safe_path(directory)
    if directory == directory.parent or directory.is_relative_to(KIT) or KIT.is_relative_to(directory):
        raise SetupError("--tools-dir must be a separate directory outside this kit")
    if (directory / "installation.json").exists():
        return validate_install(directory)
    if directory.exists() and any(directory.iterdir()):
        raise SetupError("Nonempty unowned tools directory; choose a new directory")
    setup = harness_setup()
    python = setup.find_python(python39)
    key = platform_key()
    manifest = read(HERE / "tools-manifest.json")
    entry = manifest["platforms"][key]
    lock = HERE / entry["requirements"]
    if digest(lock) != entry["requirements_sha256"]:
        raise SetupError("Requirements lock SHA-256 mismatch")
    directory.mkdir(parents=True, exist_ok=True)
    archive = directory / entry["filename"]
    download(entry["url"], archive, entry["sha256"])
    extract_archive(archive, directory / "hurl")
    created = setup.run([str(python), "-I", "-B", "-m", "venv", "--copies", str(directory / ".venv")], timeout=300)
    if created.returncode:
        raise SetupError("Python 3.9 venv/ensurepip is required:\n" + created.stderr[-2000:])
    selected = tool_python(directory)
    result = setup.run([str(selected), "-I", "-B", "-m", "pip", "--isolated", "--disable-pip-version-check",
        "install", "--no-compile", "--no-cache-dir", "--index-url", "https://pypi.org/simple", "--only-binary=:all:",
        "--require-hashes", "-r", str(lock)], timeout=600)
    if result.returncode:
        raise SetupError("Pinned dependency installation failed:\n" + result.stderr[-3000:])
    binaries = list((directory / "hurl").rglob("hurl.exe" if os.name == "nt" else "hurl"))
    binaries = [path for path in binaries if path.is_file()]
    if len(binaries) != 1:
        raise SetupError("Expected exactly one Hurl executable")
    tools = {"version": 1, "python": str(selected), "hurl": str(binaries[0]),
             "schemathesis_version": "4.4.4", "hurl_version": "8.1.0"}
    for command, expected in (([str(selected), "-I", "-B", "-X", "utf8", "-c", "from schemathesis.cli import schemathesis; schemathesis(prog_name='schemathesis')", "--version"], "4.4.4"),
                              ([tools["hurl"], "--version"], "hurl 8.1.0")):
        result = setup.run(command, timeout=30)
        if result.returncode or expected not in result.stdout:
            raise SetupError("Installed tool cannot run: " + result.stdout + result.stderr)
    receipt = {"version": 1, "platform": key, "tools": tools,
               "manifest_sha256": digest(HERE / "tools-manifest.json"), "lock_sha256": digest(lock),
               "files": inventory(directory)}
    atomic(directory / "installation.json", encoded(receipt))
    return tools


def enable(project, directory, config_file):
    project, directory = safe_path(project), safe_path(directory)
    if project.is_relative_to(KIT) or KIT.is_relative_to(project):
        raise SetupError("The application project must be separate from this kit")
    if directory.is_relative_to(project) or project.is_relative_to(directory):
        raise SetupError("Tools must be outside the application project")
    tools = validate_install(directory)
    configuration = read(config_file)
    if not isinstance(configuration, dict) or type(configuration.get("version")) is not int or configuration["version"] != 1:
        raise SetupError("API configuration version must be 1")
    scenarios = configuration.get("scenarios")
    if (not isinstance(scenarios, list) or not scenarios or any(not isinstance(value, str) for value in scenarios)
            or len(scenarios) != len(set(scenarios))):
        raise SetupError("Register a nonempty unique Hurl scenario list")
    for relative in scenarios:
        path = project_path(project, relative)
        if not path.is_file() or path.suffix != ".hurl":
            raise SetupError("Missing .hurl scenario: " + str(relative))
    spec = importlib.util.spec_from_file_location("api_setup_configuration", HERE / "check_api.py")
    runner_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner_module)
    runner_module.validate_configuration(project, configuration, tools)
    checks_path = project_path(project, ".harness/checks.json")
    checks = read(checks_path)
    if (not isinstance(checks, dict) or not isinstance(checks.get("checks"), list)
            or any(not isinstance(item, dict) for item in checks["checks"])):
        raise SetupError("Attach the harness before enabling API review")
    existing = [item for item in checks["checks"] if item.get("name") == "api-review"]
    if len(existing) > 1 or (existing and (existing[0].get("command") != COMMAND or existing[0].get("protocol") != "harness-api-review/v1")):
        raise SetupError("An unrelated api-review check already exists")
    if not existing and any(project_path(project, relative).exists() for relative in (CONFIG, TOOLS)):
        raise SetupError("Existing API configuration is not owned by this registration; refusing to overwrite")
    timeout = configuration.get("timeout_seconds", 60)
    if type(timeout) not in (int, float) or not 0 < timeout <= 3600:
        raise SetupError("timeout_seconds must be between 0 and 3600")
    item = {"name": "api-review", "command": COMMAND, "protocol": "harness-api-review/v1",
            "timeout_seconds": max(120, timeout * (len(scenarios) + 1)
                                   + configuration["server"].get("timeout_seconds", 15) + 90)}
    if existing:
        checks["checks"][checks["checks"].index(existing[0])] = item
    else:
        checks["checks"].append(item)
    protected = [RUNNER, CONFIG, TOOLS] + scenarios
    inputs = checks.setdefault("inputs", [])
    if not isinstance(inputs, list):
        raise SetupError("Existing checks inputs must be a list")
    for relative in protected:
        if relative not in inputs:
            inputs.append(relative)
    writes = {checks_path: encoded(checks), project_path(project, CONFIG): encoded(configuration),
              project_path(project, TOOLS): encoded(tools)}
    runner = project_path(project, RUNNER)
    payload = (HERE / "check_api.py").read_bytes()
    if runner.exists() and runner.read_bytes() != payload:
        raise SetupError("Existing API runner differs; refusing to overwrite: " + str(runner))
    writes[runner] = payload
    for relative in (".harness/acceptance.json", "automation/codex-loop/config.json"):
        path = project_path(project, relative)
        current = read(path)
        paths = current.setdefault("protected_paths", [])
        if not isinstance(paths, list):
            raise SetupError("Existing protected_paths must be a list")
        for member in protected:
            if member not in paths:
                paths.append(member)
        writes[path] = encoded(current)
    # All collisions/inputs are checked before changing any project file.
    for path, data in writes.items():
        if not path.exists() or path.read_bytes() != data:
            atomic(path, data)
    return {"enabled": True, "project": str(project), "tools": tools, "command": COMMAND}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    installing = sub.add_parser("install")
    installing.add_argument("--tools-dir", required=True, type=Path)
    installing.add_argument("--python39", required=True)
    enabling = sub.add_parser("enable")
    enabling.add_argument("--project", required=True, type=Path)
    enabling.add_argument("--tools-dir", required=True, type=Path)
    enabling.add_argument("--config", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        result = install(args.tools_dir, args.python39) if args.action == "install" else enable(args.project, args.tools_dir, args.config)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (SetupError, OSError, ValueError, subprocess.SubprocessError) as error:
        print("API setup failed: " + str(error), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
