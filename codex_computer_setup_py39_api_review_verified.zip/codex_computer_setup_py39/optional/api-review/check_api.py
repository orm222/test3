#!/usr/bin/env python3
"""Run pinned API tools against one disposable local server; Python 3.9 stdlib."""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
SCHEMA = "harness-api-review/v1"
CONFIG = ".harness/api-review.json"
TOOLS = ".harness/api-tools.json"
VERSIONS = {"schemathesis": "4.4.4", "hurl": "8.1.0"}
IDS = ["schemathesis", "hurl"]
SCHEMATHESIS_ENTRY = "from schemathesis.cli import schemathesis; schemathesis(prog_name='schemathesis')"
EXCLUDED_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache", ".ruff_cache", ".mypy_cache"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def plain_path(path, exists=True):
    path = Path(path).absolute()
    # Resolve Windows 8.3 aliases, but never accept symlink/junction ancestors.
    for parent in (path, *path.parents):
        if parent.exists() or parent.is_symlink():
            require(not parent.is_symlink() and not (getattr(parent.lstat(), "st_file_attributes", 0) & 0x400),
                    "Redirected path: " + str(parent))
    path = path.resolve()
    if exists:
        require(path.is_file(), "Required ordinary file is missing: " + str(path))
    return path


def read_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(plain_path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=pairs,
                      parse_constant=lambda value: require(False, "Invalid JSON number: " + value))


def positive(value, name):
    require(type(value) in (int, float) and math.isfinite(value) and value > 0,
            name + " must be a positive finite number")
    return value


def project_file(root, name):
    require(isinstance(name, str) and name and not Path(name).is_absolute(), "Expected project-relative file")
    path = plain_path(root / name)
    require(path.is_relative_to(root), "File escapes project: " + name)
    relative = path.relative_to(root).as_posix()
    require(not EXCLUDED_DIRS.intersection(part.casefold() for part in Path(relative).parts)
            and not relative.casefold().startswith(("work/", ".harness/work/")), "Runtime/excluded file cannot be a scenario")
    return path


def local_path(value, name):
    require(isinstance(value, str) and value.startswith("/") and not value.startswith("//")
            and not any(c in value for c in "\r\n\\#"), name + " must be a local absolute URL path")
    return value


def configuration(root, name):
    path = project_file(root, name)
    config = read_json(path)
    config, tools, paths = validate_configuration(root, config, read_json(root / TOOLS))
    return config, tools, paths, sha(path)


def validate_configuration(root, config, tools):
    root = plain_path(root, exists=False)
    require(isinstance(config, dict) and type(config.get("version")) is int and config["version"] == 1,
            "API configuration version must be 1")
    server = config.get("server")
    require(isinstance(server, dict), "server must be an object")
    argv = server.get("argv")
    require(isinstance(argv, list) and argv and all(isinstance(a, str) and a and "\0" not in a for a in argv),
            "server.argv must be a nonempty argument array, never a shell string")
    require(any("{port}" in arg for arg in argv), "server.argv must use {port}")
    local_path(server.get("readiness_path"), "server.readiness_path")
    positive(server.get("timeout_seconds", 15), "server.timeout_seconds")
    local_path(config.get("schema_path"), "schema_path")
    positive(config.get("timeout_seconds", 60), "timeout_seconds")
    examples = config.get("max_examples", 20)
    require(type(examples) is int and examples > 0, "max_examples must be a positive integer")
    names = config.get("scenarios")
    require(isinstance(names, list) and names and all(isinstance(n, str) for n in names),
            "scenarios must fix a nonempty list of Hurl files")
    paths = [project_file(root, name) for name in names]
    require(len(set(str(p).casefold() for p in paths)) == len(paths), "Duplicate scenario file")
    for scenario in paths:
        require(scenario.suffix == ".hurl", "Scenario must be a .hurl file")
        text = scenario.read_text(encoding="utf-8-sig")
        requests = re.findall(r"^[ \t]*[A-Za-z][A-Za-z0-9_-]*[ \t]+((?:[A-Za-z][A-Za-z0-9+.-]*://|\{\{)\S*)", text, re.M)
        require(requests and all(url == "{{base_url}}" or url.startswith("{{base_url}}/") for url in requests),
                "Every scenario request must use {{base_url}}: " + scenario.name)
        require(re.search(r"^HTTP(?:/[\d.]+)?\s+\d{3}\s*$", text, re.M),
                "Scenario needs an HTTP status assertion: " + scenario.name)
        require(not re.search(r"^\s*(?:location(?:-trusted)?|proxy|connect-to|resolve|unix-socket|variable|variables-file|base_url|no-assert|from-entry|to-entry)\s*:", text, re.M | re.I),
                "Scenario cannot redirect, reroute, redefine variables, or skip assertions: " + scenario.name)
    require(isinstance(tools, dict) and type(tools.get("version")) is int and tools["version"] == 1,
            "API tools descriptor version must be 1")
    for name, key in (("schemathesis", "python"), ("hurl", "hurl")):
        require(tools.get(name + "_version") == VERSIONS[name], "Unpinned tool descriptor: " + name)
        require(isinstance(tools.get(key), str) and Path(tools[key]).is_absolute(), "Tool path must be absolute: " + key)
        # A Linux virtualenv intentionally exposes Python through a symlink.
        require(Path(tools[key]).is_file(), "Tool executable is missing: " + key)
    return config, tools, paths


def load_processes(root):
    path = plain_path(root / ".harness/verification.py")
    spec = importlib.util.spec_from_file_location("api_review_processes", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def counts():
    return {"collected": 0, "passed": 0, "failed": 0, "skipped": 0}


def parse_junit(path):
    """Count actual testcase elements, never trust a declared total alone."""
    raw = plain_path(path).read_bytes()
    require(b"<!DOCTYPE" not in raw.upper() and b"<!ENTITY" not in raw.upper(), "DTD is not supported in JUnit")
    tree = ET.fromstring(raw)
    require(tree.tag in ("testsuite", "testsuites"), "Unexpected JUnit root")
    cases = list(tree.iter("testcase"))
    require(cases, "JUnit contains zero tests")
    result = counts()
    result["collected"] = len(cases)
    identities = set()
    for case in cases:
        identity = (case.get("classname", ""), case.get("name"))
        require(identity[1] and identity not in identities, "Missing/duplicate JUnit testcase identity")
        identities.add(identity)
        statuses = [tag for tag in ("failure", "error", "skipped") if case.find(tag) is not None]
        require(len(statuses) <= 1, "Conflicting JUnit testcase statuses")
        key = "skipped" if statuses == ["skipped"] else "failed" if statuses else "passed"
        result[key] += 1
    for suite in tree.iter("testsuite"):
        children = list(suite.iter("testcase"))
        for key, actual in (("tests", len(children)),
                            ("failures", sum(c.find("failure") is not None for c in children)),
                            ("errors", sum(c.find("error") is not None for c in children)),
                            ("skipped", sum(c.find("skipped") is not None for c in children))):
            if key in suite.attrib:
                require(suite.attrib[key].isdigit() and int(suite.attrib[key]) == actual,
                        "JUnit declared " + key + " disagrees with testcase elements")
    return result


def environment(work):
    env = {key: value for key, value in os.environ.items()
           if not key.upper().startswith(("HURL_", "SCHEMATHESIS_", "HYPOTHESIS_"))
           and key.upper() not in ("PYTHONHOME", "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY")}
    home = work / "home"
    temporary = work / "tmp"
    home.mkdir()
    temporary.mkdir()
    env.update(HOME=str(home), USERPROFILE=str(home), XDG_CONFIG_HOME=str(home),
               TEMP=str(temporary), TMP=str(temporary), TMPDIR=str(temporary),
               PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8", NO_COLOR="1",
               NO_PROXY="127.0.0.1,localhost", API_REVIEW_WORK=str(work))
    return env


def artifact(root, path):
    path = plain_path(path)
    return {"path": path.relative_to(root).as_posix() if path.is_relative_to(root) else str(path), "sha256": sha(path)}


def process_options(root, env, stdout, stderr):
    return dict(cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, shell=False,
                start_new_session=os.name != "nt",
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0)


def owned_child(owner, result_path, command):
    """Linux guardian survives an outer killpg long enough to reap its own group."""
    require(sys.platform.startswith("linux") and os.getpgrp() == os.getpid(), "Invalid process guardian group")
    try:
        require(os.getppid() == owner, "Process owner disappeared before launch")
        child = subprocess.Popen(command, shell=False)
        published = False
        while True:
            if os.getppid() != owner:
                return
            code = child.poll()
            if code is not None and not published:
                temporary = result_path.with_suffix(".tmp")
                temporary.write_text(str(code), encoding="ascii")
                temporary.replace(result_path)
                published = True
            # Keep the guardian alive after command exit until the owner cleans the
            # group, so grandchildren cannot escape through an exit/kill race.
            time.sleep(0.05)
    finally:
        os.killpg(os.getpgrp(), signal.SIGKILL)


def start_owned(processes, command, result_path, **options):
    if not sys.platform.startswith("linux"):
        return processes.start_process(command, **options)
    guardian = [sys.executable, "-B", str(Path(__file__).resolve()), "--owned-process",
                str(os.getpid()), str(result_path)] + command
    process = processes.start_process(guardian, **options)
    process._api_result = result_path
    return process


def poll_owned(process):
    path = getattr(process, "_api_result", None)
    if path is not None and path.is_file():
        return int(path.read_text(encoding="ascii"))
    return process.poll()


def wait_owned(process, command, timeout):
    if not hasattr(process, "_api_result"):
        return process.wait(timeout=timeout)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        code = poll_owned(process)
        if code is not None:
            return code
        time.sleep(0.05)
    raise subprocess.TimeoutExpired(command, timeout)


def run_command(processes, command, work, env, prefix, timeout):
    out, err = work / (prefix + ".stdout.log"), work / (prefix + ".stderr.log")
    process = None
    with out.open("wb") as stdout, err.open("wb") as stderr:
        try:
            process = start_owned(processes, command, work / (prefix + ".exit"), **process_options(work, env, stdout, stderr))
            code = wait_owned(process, command, timeout)
        finally:
            if process is not None:
                processes.stop_process(process)
    return code, out, err


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def wait_ready(process, url, timeout):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        require(poll_owned(process) is None, "Server exited before readiness")
        try:
            with opener.open(url, timeout=min(0.5, max(0.01, deadline - time.monotonic()))) as response:
                if 200 <= response.status < 300:
                    require(poll_owned(process) is None, "Server exited during readiness")
                    return
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(0.05)
    raise TimeoutError("Local server readiness timed out")


def local_schema(url, destination, timeout):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    deadline = time.monotonic() + timeout
    chunks, size = [], 0
    with opener.open(url, timeout=min(timeout, 1)) as response:
        while True:
            require(time.monotonic() < deadline, "OpenAPI schema download timed out")
            chunk = response.read1(65536)
            if not chunk:
                break
            size += len(chunk)
            require(size <= 16 * 1024 * 1024, "OpenAPI schema exceeds 16 MiB")
            chunks.append(chunk)
    raw = b"".join(chunks)
    value = json.loads(raw.decode("utf-8-sig"))
    require(isinstance(value, dict) and ("openapi" in value or "swagger" in value), "Expected an OpenAPI JSON document")
    pending = [value]
    while pending:
        item = pending.pop()
        if isinstance(item, dict):
            if "$ref" in item:
                require(isinstance(item["$ref"], str) and item["$ref"].startswith("#"),
                        "External OpenAPI $ref is not allowed")
            pending.extend(item.values())
        elif isinstance(item, list):
            pending.extend(item)
    destination.write_bytes(raw)


def expand(argv, port, work):
    return [arg.replace("{python}", sys.executable).replace("{port}", str(port)).replace("{work}", str(work))
            for arg in argv]


def run(root, config_name=CONFIG, work_dir=None):
    root = Path(root).absolute()
    report = {"schema": SCHEMA, "status": "error", "source_hash": None, "source_hash_after": None,
              "config_digest": None, "tools": {}, "required_check_ids": IDS[:], "scenario_files": [],
              "checks": [{"id": name, "tool": name, "status": "NOT_RUN", "exit_code": None,
                          "counts": counts(), "count_unit": "operation" if name == "schemathesis" else "scenario_file",
                          "artifacts": []} for name in IDS], "artifacts": [], "error": None}
    report["checks"][0]["phases"] = ["coverage", "fuzzing"]
    processes, guard, work, server = None, None, None, None
    server_streams = []
    exit_code = 2
    try:
        root = plain_path(root, exists=False)
        require(root.is_dir(), "Project root must be an ordinary directory")
        config, tools, scenarios, report["config_digest"] = configuration(root, config_name)
        report["scenario_files"] = [p.relative_to(root).as_posix() for p in scenarios]
        processes = load_processes(root)
        report["source_hash"] = processes.reports.source_digest(root)
        guard = processes.reports.guard(root)
        base = Path(work_dir).absolute() if work_dir else root / ".harness/work/api-review"
        base = plain_path(base, exists=False)
        require(not base.is_relative_to(root) or base == root / ".harness/work/api-review",
                "Work directory must be external or exactly .harness/work/api-review")
        base.mkdir(parents=True, exist_ok=True)
        work = base / ("run-" + uuid.uuid4().hex)
        work.mkdir()
        report["run_id"] = work.name
        env = environment(work)
        # 4.4.4 otherwise searches parent directories for project-wide tool overrides.
        (work / "schemathesis.toml").write_text("", encoding="utf-8")
        for name, command in (("schemathesis", [tools["python"], "-I", "-B", "-X", "utf8", "-c", SCHEMATHESIS_ENTRY, "--version"]),
                              ("hurl", [tools["hurl"], "--version"])):
            code, out, err = run_command(processes, command, work, env, name + "-version", 15)
            report["artifacts"].extend([artifact(root, out), artifact(root, err)])
            text = out.read_text(encoding="utf-8", errors="replace")
            match = re.search(r"(?im)^" + name + r"(?:,? version)?\s+(\d+\.\d+\.\d+)(?:\s|$)", text)
            require(code == 0 and match and match.group(1) == VERSIONS[name], "Unexpected tool version: " + name)
            report["tools"][name] = {"version": match.group(1)}
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        base_url = "http://127.0.0.1:" + str(port)
        server_argv = expand(config["server"]["argv"], port, work)
        server_streams = [(work / "server.stdout.log").open("wb"), (work / "server.stderr.log").open("wb")]
        server = start_owned(processes, server_argv, work / "server.exit", **process_options(root, env, *server_streams))
        report["server"] = {"pid": server.pid, "base_url": base_url, "ready": False}
        wait_ready(server, base_url + config["server"]["readiness_path"], config["server"].get("timeout_seconds", 15))
        report["server"]["ready"] = True
        timeout = config.get("timeout_seconds", 60)
        local_schema(base_url + config["schema_path"], work / "schema.json", min(timeout, 15))
        report["artifacts"].append(artifact(root, work / "schema.json"))
        commands = [("schemathesis", None, [tools["python"], "-I", "-B", "-X", "utf8", "-c", SCHEMATHESIS_ENTRY,
                     "--config-file", str(work / "schemathesis.toml"), "run",
                     str(work / "schema.json"), "--url", base_url,
                     "--phases", "coverage,fuzzing",
                     "--max-examples", str(config.get("max_examples", 20)), "--max-redirects", "0",
                     "--report-junit-path", str(work / "schemathesis.xml")],
                     work / "schemathesis.xml")]
        for index, scenario in enumerate(scenarios):
            xml = work / ("hurl-" + str(index) + ".xml")
            commands.append(("hurl", scenario.relative_to(root).as_posix(),
                             [tools["hurl"], "--test", "--jobs", "1", "--no-color", "--variable", "base_url=" + base_url,
                              "--report-junit", str(xml), str(scenario)], xml))
        report["checks"][1]["scenario_results"] = []
        errors = []
        for index, (name, scenario, command, xml) in enumerate(commands):
            row = report["checks"][IDS.index(name)]
            prefix = name if scenario is None else "hurl-" + str(index - 1)
            result = {"scenario": scenario, "command": command, "exit_code": None, "status": "FAIL", "counts": counts()}
            try:
                require(poll_owned(server) is None, "Server exited before tool execution")
                code, out, err = run_command(processes, command, work, env, prefix, timeout)
                result["exit_code"] = code
                result["counts"] = parse_junit(xml)
                require(code in ((0, 1) if name == "schemathesis" else (0, 4)), name + " preparation/runtime error")
                require(not result["counts"]["skipped"], name + " skipped required tests")
                require(result["counts"]["passed"] or result["counts"]["failed"], name + " executed zero tests")
                if code == 0 and not result["counts"]["failed"]:
                    result["status"] = "PASS"
                elif code == 0 or not result["counts"]["failed"]:
                    raise ValueError(name + " exit code disagrees with JUnit results")
            except (OSError, ValueError, ET.ParseError, subprocess.TimeoutExpired, TimeoutError) as exc:
                errors.append(name + ": " + str(exc))
                result["error"] = str(exc)
            row["status"] = "PASS" if result["status"] == "PASS" and row["status"] != "FAIL" else "FAIL"
            row["exit_code"] = result["exit_code"] if row["exit_code"] in (None, 0) else row["exit_code"]
            for key, value in result["counts"].items():
                row["counts"][key] += value
            row.setdefault("commands", []).append(command)
            row["artifacts"].extend(artifact(root, p) for p in (work / (prefix + ".stdout.log"), work / (prefix + ".stderr.log"), xml) if p.is_file())
            if scenario is not None:
                row["scenario_results"].append(result)
        if errors:
            raise ValueError("; ".join(errors))
        require(poll_owned(server) is None, "Server exited during API review")
        report["status"] = "passed" if all(row["status"] == "PASS" for row in report["checks"]) else "failed"
        exit_code = 0 if report["status"] == "passed" else 1
    except (Exception, KeyboardInterrupt) as exc:
        report["status"], report["error"], exit_code = "error", str(exc) or type(exc).__name__, 2
    finally:
        if server is not None:
            try:
                processes.stop_process(server)
            except Exception as exc:
                report["status"], report["error"], exit_code = "error", "Server cleanup failed: " + str(exc), 2
        for stream in server_streams:
            stream.close()
        if processes is not None and report["source_hash"] is not None:
            try:
                processes.reports.guard(root, guard)
                report["source_hash_after"] = processes.reports.source_digest(root)
                require(report["source_hash_after"] == report["source_hash"], "Project source changed during API review")
            except Exception as exc:
                report["status"], report["error"], exit_code = "error", str(exc), 2
        if work is not None:
            try:
                report["artifacts"].extend(artifact(root, p) for p in (work / "server.stdout.log", work / "server.stderr.log") if p.is_file())
            except Exception as exc:
                report["status"], report["error"], exit_code = "error", "Evidence collection failed: " + str(exc), 2
    return report, exit_code


def main(argv=None):
    sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=".")
    parser.add_argument("--config", default=CONFIG)
    parser.add_argument("--work-dir", help="Optional external evidence directory (standalone runs only)")
    args = parser.parse_args(argv)
    report, code = run(args.root, args.config, args.work_dir)
    print(json.dumps(report, ensure_ascii=False, separators=(",", ":")))
    return code


if __name__ == "__main__":
    if len(sys.argv) >= 5 and sys.argv[1] == "--owned-process":
        owned_child(int(sys.argv[2]), Path(sys.argv[3]), sys.argv[4:])
    else:
        raise SystemExit(main())
