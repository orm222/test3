"""Installer contracts and real offline venv/project setup. No model calls."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("kit_setup", ROOT / "setup_env.py")
setup = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(setup)
_boundary_fixture_spec = importlib.util.spec_from_file_location("setup_boundary_fixture",
    ROOT / "template/.harness/tests/boundary_fixture.py")
boundary_fixture = importlib.util.module_from_spec(_boundary_fixture_spec)
_boundary_fixture_spec.loader.exec_module(boundary_fixture)


class SetupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="setup kit space ")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.context = contextlib.ExitStack()
        self.addCleanup(self.context.close)
        self.output = io.StringIO()
        self.context.enter_context(contextlib.redirect_stdout(self.output))
        self.context.enter_context(contextlib.redirect_stderr(self.output))

    def test_explicit_wrong_python_is_rejected_without_fallback(self):
        response = subprocess.CompletedProcess([], 0, json.dumps({"version": [3, 13, 1]}), "")
        with mock.patch.object(setup, "run", return_value=response) as run:
            with self.assertRaisesRegex(setup.SetupError, "3.9 is required"):
                setup.find_python("chosen-python")
        self.assertEqual(run.call_count, 1)

    def test_default_command_only_displays_order(self):
        with mock.patch.object(setup, "prepare_venv") as prepare:
            self.assertEqual(setup.main([]), 0)
            prepare.assert_not_called()
        self.assertIn("install -> doctor -> attach", self.output.getvalue())

    def test_missing_prerequisites_are_reported_without_model_calls(self):
        with mock.patch.object(setup, "find_python", side_effect=setup.SetupError("missing Python 3.9")), \
             mock.patch.object(setup, "check_venv", side_effect=FileNotFoundError), \
             mock.patch.object(setup, "run", side_effect=FileNotFoundError), \
             mock.patch.object(setup.shutil, "which", return_value=None), \
             mock.patch.object(setup, "codex_command", side_effect=setup.SetupError("missing CLI")):
            self.assertEqual(setup.doctor(as_json=True), 1)
        report = json.loads(self.output.getvalue())
        self.assertFalse(report["ready"])
        self.assertEqual(report["model_calls"], 0)
        missing = {"python39", "kit_venv", "git", "codex_cli", "codex_login"}
        if sys.platform.startswith("linux"):
            missing.add("tmux")
        self.assertEqual({x["name"] for x in report["checks"] if not x["ok"] and x["required"]}, missing)

    def test_doctor_only_uses_help_and_login_status(self):
        info = dict(executable=sys.executable, version=[3, 9, 25], prefix=str(ROOT / ".venv"), tomli=True)
        calls = []
        def run(argv, **kwargs):
            calls.append(argv)
            return subprocess.CompletedProcess(argv, 0,
                "--output-schema --output-last-message --json --model --sandbox --skip-git-repo-check", "private auth output")
        with mock.patch.object(setup, "find_python", return_value=Path(sys.executable)), \
             mock.patch.object(setup, "python_info", return_value=info), \
             mock.patch.object(setup, "check_venv", return_value=info), \
             mock.patch.object(setup.shutil, "which", return_value="fake-tmux"), \
             mock.patch.object(setup, "codex_command", return_value=["fake-codex"]), \
             mock.patch.object(setup, "run", side_effect=run):
            self.assertEqual(setup.doctor(as_json=True), 0)
        self.assertEqual(calls, [["git", "--version"], ["fake-codex", "exec", "--help"], ["fake-codex", "login", "status"]])
        self.assertNotIn("private auth output", self.output.getvalue())

    def test_doctor_requires_tmux_only_on_linux_without_starting_it(self):
        info = dict(executable=sys.executable, version=[3, 9, 25], prefix=str(ROOT / ".venv"), tomli=True)
        cases = [("linux", None, 1), ("linux2", None, 1), ("linux", "/usr/bin/tmux", 0),
                 ("win32", None, 0), ("win32", "unused-tmux", 0)]
        for platform, tmux, expected in cases:
            with self.subTest(platform=platform, tmux=tmux):
                self.output.seek(0)
                self.output.truncate()
                with mock.patch.object(setup.sys, "platform", platform), \
                     mock.patch.object(setup, "find_python", return_value=Path(sys.executable)), \
                     mock.patch.object(setup, "python_info", return_value=info), \
                     mock.patch.object(setup, "check_venv", return_value=info), \
                     mock.patch.object(setup, "codex_command", return_value=["fake-codex"]), \
                     mock.patch.object(setup.shutil, "which", return_value=tmux) as which, \
                     mock.patch.object(setup, "run", return_value=subprocess.CompletedProcess([], 0,
                         "--output-schema --output-last-message --json --model --sandbox --skip-git-repo-check", "")) as run:
                    self.assertEqual(setup.doctor(as_json=True), expected)
                report = json.loads(self.output.getvalue())
                item = next(check for check in report["checks"] if check["name"] == "tmux")
                self.assertEqual(item["required"], platform.startswith("linux"))
                self.assertEqual(report["ready"], expected == 0)
                self.assertEqual(report["model_calls"], 0)
                if platform.startswith("linux"):
                    which.assert_called_once_with("tmux")
                    if not tmux:
                        self.assertIn("Install", item["detail"])
                        self.assertIn("docs/SETUP.md", item["detail"])
                else:
                    which.assert_not_called()
                    self.assertIn("current terminal", item["detail"])
                self.assertEqual([call.args[0] for call in run.call_args_list],
                    [["git", "--version"], ["fake-codex", "exec", "--help"], ["fake-codex", "login", "status"]])

    def test_attach_collision_is_rejected_before_mutation(self):
        project = self.root / "project"
        (project / ".harness").mkdir(parents=True)
        existing = project / ".harness/harness.py"
        existing.write_text("my existing harness", encoding="utf-8")
        with mock.patch.object(setup, "find_python", return_value=Path(sys.executable)), \
             mock.patch.object(setup, "git_root", return_value=project), \
             mock.patch.object(setup, "prepare_venv") as prepare:
            with self.assertRaisesRegex(setup.SetupError, "nothing has been overwritten"):
                setup.attach(str(project), "SPEC.md")
            prepare.assert_not_called()
        self.assertEqual(existing.read_text(encoding="utf-8"), "my existing harness")
        self.assertFalse((project / ".venv").exists())

    def test_attach_rejects_overlap_and_outside_spec(self):
        for project, spec in ((ROOT, "SPEC.md"), (ROOT / "project", "SPEC.md"), (self.root / "p", "../SPEC.md")):
            with self.subTest(project=project, spec=spec), self.assertRaises(setup.SetupError):
                setup.attach(str(project), spec)

    def test_redirected_parent_is_rejected_before_venv_or_git_creation(self):
        project = (self.root / "new project").resolve()
        with mock.patch.object(setup, "find_python", return_value=Path(sys.executable)), \
             mock.patch.object(setup, "git_root", return_value=None), \
             mock.patch.object(setup, "prepare_venv") as prepare, \
             mock.patch.object(Path, "is_symlink", autospec=True,
                               side_effect=lambda path: path == project / ".harness"):
            with self.assertRaisesRegex(setup.SetupError, "redirected installation directory"):
                setup.attach(str(project), "SPEC.md")
            prepare.assert_not_called()
        self.assertFalse(project.exists())

    def test_payload_has_tools_and_workflow_but_no_examples_or_records(self):
        names = {relative.as_posix() for _, relative in setup.payload_files()}
        self.assertIn("automation/codex-loop/WORKFLOW_SPEC.md", names)
        self.assertIn(".harness/harness.py", names)
        self.assertIn("run_harness.py", names)
        self.assertIn("BOUNDARY_QUESTION_TEMPLATE.md", names)
        self.assertIn(".harness/boundary.py", names)
        self.assertIn(".harness/reports.py", names)
        self.assertIn(".harness/review_criteria.json", names)
        self.assertNotIn("AGENTS.md", names)
        self.assertFalse(any("tests" in Path(name).parts or name.endswith("demo.py") or ".example." in name for name in names))
        self.assertFalse(any("runs" in Path(name).parts or "work" in Path(name).parts for name in names))

    def test_existing_user_progress_is_preserved_before_environment_creation(self):
        project = (self.root / "existing notes").resolve()
        (project / "docs").mkdir(parents=True)
        notes = project / "docs/progress.md"
        notes.write_text("User-owned development history.\n", encoding="utf-8")
        with mock.patch.object(setup, "find_python", return_value=Path(sys.executable)), \
             mock.patch.object(setup, "git_root", return_value=project), \
             mock.patch.object(setup, "prepare_venv") as prepare:
            with self.assertRaises(ValueError):
                setup.attach(str(project), "SPEC.md")
            prepare.assert_not_called()
        self.assertEqual(notes.read_text(encoding="utf-8"), "User-owned development history.\n")
        self.assertFalse((project / ".harness").exists())

    def test_attach_initializes_unreviewed_reports_without_model_or_prior_work(self):
        project = (self.root / "new reports").resolve()
        with mock.patch.object(setup, "find_python", return_value=Path(sys.executable)), \
             mock.patch.object(setup, "git_root", return_value=project), \
             mock.patch.object(setup, "prepare_venv"), \
             mock.patch.object(setup, "run", side_effect=AssertionError("No model or application call during attach")):
            self.assertEqual(setup.attach(str(project), "SPEC.md"), 0)
            before = {name: (project / name).read_bytes() for name in ("docs/progress.md", "docs/review-score.md")}
            self.assertEqual(setup.attach(str(project), "SPEC.md"), 0)
        self.assertEqual(before, {name: (project / name).read_bytes() for name in before})
        self.assertEqual(setup._processes.reports.validate_managed(project), set(before))
        self.assertIn("미산정", (project / "docs/review-score.md").read_text(encoding="utf-8"))

    def test_attach_preserves_user_instructions_and_existing_project_contracts(self):
        project = (self.root / "existing project").resolve()
        (project / ".harness").mkdir(parents=True)
        (project / "automation/codex-loop").mkdir(parents=True)
        preserved = {"AGENTS.md": "User-owned instructions.\n",
                     ".harness/acceptance.json": '{"boundary_tests":{"Q-001":["existing.test"]}}',
                     ".harness/checks.json": '{"checks":["existing"]}',
                     "automation/codex-loop/config.json": '{"spec":"USER_SPEC.md"}',
                     "automation/codex-loop/tasks.json": '["existing task"]'}
        for name, body in preserved.items():
            (project / name).write_text(body, encoding="utf-8")
        with mock.patch.object(setup, "find_python", return_value=Path(sys.executable)), \
             mock.patch.object(setup, "git_root", return_value=project), \
             mock.patch.object(setup, "prepare_venv"), \
             mock.patch.object(setup, "run", side_effect=AssertionError("attach must not start any CLI")):
            self.assertEqual(setup.attach(str(project), "SPEC.md"), 0)
        for name, body in preserved.items():
            self.assertEqual((project / name).read_text(encoding="utf-8"), body)
        self.assertFalse((project / ".harness/boundary.json").exists())
        self.assertFalse((project / "BOUNDARY_ANSWERS.md").exists())

    def test_corrupt_wheel_and_foreign_venv_are_not_overwritten(self):
        with mock.patch.object(setup, "ROOT", self.root):
            with self.assertRaisesRegex(setup.SetupError, "wheel is missing or damaged"):
                setup.prepare_venv(self.root / "project", Path(sys.executable))
        project = self.root / "project"
        (project / ".venv").mkdir(parents=True)
        marker = project / ".venv/foreign-marker"
        marker.write_text("keep", encoding="utf-8")
        with self.assertRaisesRegex(setup.SetupError, "incomplete or foreign-OS"):
            setup.prepare_venv(project, Path(sys.executable))
        self.assertEqual(marker.read_text(), "keep")

    @unittest.skipUnless(sys.version_info[:2] == (3, 9) and shutil.which("git"), "real smoke requires Python3.9 and Git")
    def test_real_install_prepares_local_environment_then_stops_at_doctor(self):
        kit = self.root / "isolated kit"
        shutil.copytree(str(ROOT / "vendor"), str(kit / "vendor"))
        with mock.patch.object(setup, "ROOT", kit), mock.patch.object(setup, "doctor", return_value=1) as doctor:
            self.assertEqual(setup.main(["install", "--python39", sys.executable]), 1)
            self.assertTrue(setup.check_venv(kit)["tomli"])
            doctor.assert_called_once_with(str(setup.venv_python(kit)))
        self.assertFalse((kit / "automation").exists())

    @unittest.skipUnless(sys.version_info[:2] == (3, 9) and shutil.which("git"), "real smoke requires Python3.9 and Git")
    def test_real_offline_attach_is_idempotent_and_starts_no_models(self):
        project = self.root / "project 한글 spaces"
        with mock.patch.object(setup, "codex_command", side_effect=AssertionError("attach must not call Codex")):
            self.assertEqual(setup.attach(str(project), "SPEC.md", sys.executable), 0)
            paths = [p for p in project.rglob("*") if p.is_file() and not any(x in (".venv", ".git") for x in p.relative_to(project).parts)]
            before = {p.relative_to(project).as_posix(): p.read_bytes() for p in paths}
            self.assertEqual(setup.attach(str(project), "SPEC.md", sys.executable), 0)
            self.assertEqual(before, {name: (project / name).read_bytes() for name in before})
        self.assertTrue(setup.check_venv(project)["tomli"])
        self.assertFalse((project / "SPEC.md").exists())
        self.assertEqual(json.loads((project / ".harness/checks.json").read_text(encoding="utf-8")), {"checks": []})
        self.assertEqual(json.loads((project / ".harness/acceptance.json").read_text(encoding="utf-8")),
                         {"version": 1, "checker_argv": [], "required_ids_manifest": "", "protected_paths": [], "boundary_tests": {}})
        config = json.loads((project / "automation/codex-loop/config.json").read_text(encoding="utf-8"))
        run_root = (project / "automation/codex-loop" / config["run_root"]).resolve()
        self.assertFalse(setup.inside(run_root, project))
        self.assertFalse(run_root.exists())
        for arguments, expected in ((["verify"], "boundary"), (["loop", "--preflight"], "spec must be")):
            result = setup.run([str(setup.venv_python(project)), "-B", str(project / "run_harness.py")] + arguments, cwd=project)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn(expected, result.stdout + result.stderr)
        # The project is independently usable after the setup-kit is removed/moved.
        boundary_fixture.ready(project)
        (project / "check.py").write_text("print('REAL_CHECK_OK')\n", encoding="utf-8")
        (project / "tests").mkdir()
        (project / "tests/test_smoke.py").write_text(
            "import unittest\nclass Smoke(unittest.TestCase):\n def test_required(self): self.assertEqual(2+3,5)\n",
            encoding="utf-8")
        (project / "required_ids.json").write_text(json.dumps({
            "version": 1, "required_test_ids": ["test_smoke.Smoke.test_required"]}), encoding="utf-8")
        (project / ".harness/acceptance.json").write_text(json.dumps({"version": 1,
            "checker_argv": ["{python}", "-B", ".harness/check_unittest.py"],
            "required_ids_manifest": "required_ids.json", "protected_paths": ["tests"]}), encoding="utf-8")
        (project / ".harness/checks.json").write_text(json.dumps({"checks": [
            {"name": "smoke", "command": ["{python}", "check.py"], "timeout_seconds": 15}]}), encoding="utf-8")
        for mode in ("verify", "status"):
            result = setup.run([str(setup.venv_python(project)), "-B", str(project / "run_harness.py"), mode], cwd=project)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
