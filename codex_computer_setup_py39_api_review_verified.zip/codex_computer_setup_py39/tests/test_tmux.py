"""Real Linux tmux/PTY launch tests. All worker calls use the bundled fake CLI."""
import json
import os
from pathlib import Path
import select
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest

KIT = Path(__file__).resolve().parents[1]
TEMPLATE = KIT / "template"
LOOP = TEMPLATE / "automation/codex-loop"
sys.path.insert(0, str(LOOP))
import demo

AVAILABLE = sys.platform.startswith("linux") and shutil.which("tmux") and shutil.which("bash")


@unittest.skipUnless(AVAILABLE, "requires Linux, Bash and real tmux")
class TmuxLaunchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tmux39-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.socket = self.root / "socket"
        self.socket.mkdir(mode=0o700)
        self.env = dict(os.environ, TMUX_TMPDIR=str(self.socket), TERM="xterm-256color",
                        HOME=str(self.root / "home"), PYTHONDONTWRITEBYTECODE="1")
        self.env.pop("TMUX", None)
        self.env.pop("PYTHONHOME", None)
        Path(self.env["HOME"]).mkdir()
        self.release = self.root / "release"
        self.addCleanup(self.stop_server)
        self.project = self.root / "project O'Brien $HOME; $(touch TMUX_INJECTION);"
        shutil.copytree(TEMPLATE, self.project)
        (self.project / ".venv").symlink_to(Path(sys.prefix), target_is_directory=True)
        (self.project / "tests").mkdir()
        (self.project / "SPEC.md").write_text(
            "Exact integer addition, with no I/O or external effects: add(2, 3)=5; add(0, 0)=0; add(-2, 3)=1.\n")
        (self.project / "tests/test_calc.py").write_text(
            "import unittest\nfrom calc import add\nclass Addition(unittest.TestCase):\n"
            " def test_values(self):\n"
            "  self.assertEqual([add(2,3),add(0,0),add(-2,3)],[5,0,1])\n")
        self.trace = self.root / "trace.jsonl"
        self.calls = self.root / "calls.jsonl"
        self.metadata = self.root / "worker.jsonl"
        self.wrapper = self.root / "fake worker O'Brien $HOME.py"
        # Capture the actual pane environment before the wrapper supplies fixture controls.
        self.wrapper.write_text(
            "import json,os,shutil,sys,time\nfrom pathlib import Path\n"
            "args=sys.argv[1:]\n"
            "with open(%r,'a') as f: f.write(json.dumps(args)+'\\n')\n"
            "if '--output-last-message' in args:\n"
            " with open(%r,'a') as f: f.write(json.dumps({'cwd':os.getcwd(),"
            "'tmux':os.environ.get('TMUX'),'path':os.environ.get('PATH'),"
            "'virtual_env':os.environ.get('VIRTUAL_ENV'),'pythonhome':os.environ.get('PYTHONHOME'),"
            "'which_python':shutil.which('python')})+'\\n')\n"
            " deadline=time.monotonic()+40\n"
            " while not Path(%r).exists():\n"
            "  if time.monotonic()>deadline: raise SystemExit(87)\n"
            "  time.sleep(.05)\n"
            "os.environ['CODEX_LOOP_FAKE_TRACE']=%r\n"
            "os.environ['CODEX_LOOP_FAKE_MODE']='repair'\n"
            "os.execv(sys.executable,[sys.executable,%r]+args)\n"
            % (str(self.calls), str(self.metadata), str(self.release), str(self.trace),
               str(LOOP / "tests/fake_codex.py")), encoding="utf-8")
        tasks = json.loads((LOOP / "tasks.example.json").read_text(encoding="utf-8"))
        (self.project / ".harness/required_tests.json").write_text(json.dumps({
            "version": 1, "required_test_ids": ["test_calc.Addition.test_values"]}), encoding="utf-8")
        (self.project / ".harness/acceptance.json").write_text(json.dumps({
            "version": 1, "checker_argv": tasks[0]["checks"][0]["argv"],
            "required_ids_manifest": ".harness/required_tests.json", "protected_paths": ["tests"]}), encoding="utf-8")
        demo.create_boundary(self.project)
        self.tasks = self.root / "tasks.json"
        self.tasks.write_text(json.dumps(tasks), encoding="utf-8")
        self.runs = self.root / "runs"
        config = dict(project=str(self.project), spec="SPEC.md", tasks_file=str(self.tasks),
                      builder_model="FAKE-sol", reviewer_model="FAKE-terra", max_repairs=3,
                      stage_timeout_seconds=60, total_timeout_seconds=180,
                      codex_command=[sys.executable, str(self.wrapper)],
                      protected_paths=["tests"], run_root=str(self.runs))
        self.config = self.project / "automation/codex-loop/config.json"
        self.config.write_text(json.dumps(config), encoding="utf-8")
        self.command = [sys.executable, "-B", str(self.project / "run_harness.py"), "loop"]

    def stop_server(self):
        self.release.touch()
        subprocess.run(["tmux", "kill-server"], env=self.env, capture_output=True, timeout=10)

    def tmux(self, *args, env=None, check=True):
        return subprocess.run(["tmux"] + list(args), env=env or self.env, capture_output=True,
                              text=True, timeout=10, check=check)

    def wait_for(self, predicate, description, timeout=30):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            value = predicate()
            if value:
                return value
            time.sleep(.05)
        panes = self.tmux("capture-pane", "-p", check=False)
        self.fail("Timed out waiting for " + description + "\n" + panes.stdout + panes.stderr)

    def rows(self, path):
        return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

    def started(self):
        self.wait_for(lambda: self.rows(self.metadata), "fake worker startup")

    def completed_once(self):
        self.release.touch()
        def finished():
            states = list(self.runs.glob("*/state.json"))
            if not states:
                return None
            state = json.loads(states[0].read_text())
            return state if state["status"] in ("COMPLETED", "STOPPED") else None
        state = self.wait_for(finished, "workflow completion")
        self.assertEqual(state["status"], "COMPLETED", state)
        self.assertEqual(len(list(self.runs.glob("*/state.json"))), 1)
        calls = self.rows(self.trace)
        self.assertEqual([row["role"] for row in calls], ["builder", "reviewer", "builder", "reviewer"])
        self.assertEqual(len({row["context"]["run_id"] for row in calls}), 1)
        self.assertEqual(len(self.rows(self.metadata)), 4)
        for row in self.rows(self.metadata):
            self.assertEqual(row["cwd"], str(self.project))
            self.assertTrue(row["tmux"])
            self.assertEqual(row["virtual_env"], str(self.project / ".venv"))
            self.assertEqual(row["which_python"], str(self.project / ".venv/bin/python"))
            self.assertIsNone(row["pythonhome"])
        self.assertFalse(any(self.root.rglob("TMUX_INJECTION")))

    def launch(self, args=(), env=None, expected=0):
        result = subprocess.run(self.command + list(args), cwd=str(self.root), env=env or self.env,
                                capture_output=True, text=True, timeout=20)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        return result

    def minimal_path(self):
        directory = self.root / "no tmux bin"
        directory.mkdir()
        for name in ("bash", "dirname", "basename", "cat", "date"):
            (directory / name).symlink_to(shutil.which(name))
        return dict(self.env, PATH=str(directory))

    def test_headless_default_config_and_literal_project_path(self):
        result = self.launch()
        self.assertIn("Session: codex-loop-", result.stdout)
        self.assertIn("Reattach: tmux attach-session", result.stdout)
        self.started()
        sessions = self.tmux("list-sessions", "-F", "#{session_name}").stdout.splitlines()
        self.assertEqual(len(sessions), 1)
        self.assertEqual(self.tmux("display-message", "-p", "#{pane_current_path}").stdout.strip(), str(self.project))
        self.completed_once()

    def test_interactive_pty_attaches_and_detaches(self):
        import pty
        child, master = pty.fork()
        if child == 0:
            os.chdir(str(self.root))
            os.execve(sys.executable, self.command, self.env)
        def close_child():
            try:
                os.kill(child, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                os.waitpid(child, 0)
            except ChildProcessError:
                pass
            os.close(master)
        self.addCleanup(close_child)
        def attached():
            if select.select([master], [], [], 0)[0]:
                os.read(master, 65536)
            return self.tmux("list-clients", "-F", "#{session_name}", check=False).stdout.strip()
        session = self.wait_for(attached, "interactive tmux client")
        self.assertTrue(session.startswith("codex-loop-"), session)
        self.started()
        self.assertEqual(len(self.tmux("list-sessions", "-F", "#S").stdout.splitlines()), 1)
        self.completed_once()
        # Actual keyboard detach proves the launcher handed the terminal to tmux.
        os.write(master, b"\x02d")
        exited = self.wait_for(lambda: os.waitpid(child, os.WNOHANG)[0], "PTY launcher exit")
        self.assertEqual(exited, child)
        self.assertEqual(self.tmux("list-clients", check=False).stdout.strip(), "")

    def test_existing_tmux_session_runs_once_without_nested_session(self):
        command = shlex.join(self.command) + "; exec /bin/sleep 120"
        self.tmux("new-session", "-d", "-s", "existing", "-c", str(self.root), command)
        self.started()
        self.assertEqual(self.tmux("list-sessions", "-F", "#S").stdout.splitlines(), ["existing"])
        self.completed_once()

    def test_preexisting_server_preserves_selected_venv_and_literal_config(self):
        stale = dict(self.env, PATH="/usr/bin:/bin", VIRTUAL_ENV="/stale/venv", PYTHONHOME="/stale/python")
        self.tmux("new-session", "-d", "-s", "old-server", "/bin/sleep 120", env=stale)
        self.tmux("set-option", "-g", "default-shell", "/bin/sh")
        alternate = self.root / "config O'Brien $HOME; $(touch TMUX_INJECTION).json;"
        shutil.copyfile(self.config, alternate)
        self.launch(["--config=" + str(alternate)])
        self.started()
        self.assertEqual(len(self.tmux("list-sessions", "-F", "#S").stdout.splitlines()), 2)
        self.completed_once()

    def test_missing_tmux_refuses_work_without_fallback(self):
        result = self.launch(env=self.minimal_path(), expected=2)
        self.assertIn("requires tmux", result.stderr)
        self.assertFalse(self.metadata.exists())
        self.assertFalse(self.runs.exists())

    def test_help_and_preflight_need_no_tmux_and_make_no_model_calls(self):
        env = self.minimal_path()
        self.launch(["--help"], env=env)
        self.launch(["--preflight"], env=env)
        self.assertFalse(self.metadata.exists())
        self.assertFalse(self.trace.exists())
        self.assertTrue(self.rows(self.calls))
        self.assertTrue(all("--help" in args or args[:2] == ["login", "status"] for args in self.rows(self.calls)))
        self.assertFalse((self.socket / ("tmux-" + str(os.getuid())) / "default").exists())


if __name__ == "__main__":
    unittest.main()
