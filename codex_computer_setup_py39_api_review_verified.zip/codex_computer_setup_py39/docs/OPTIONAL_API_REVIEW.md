# 선택형 API 결과물 검수

이 기능은 하네스로 만든 HTTP 백엔드 결과물을 추가 검사합니다. 기본 설치·프로젝트 연결·개발 loop에는 Schemathesis나 Hurl이 필요하지 않습니다. 필요한 프로젝트에서만 도구를 따로 설치하고 `verify`에 추가 검사로 연결합니다. 기존 공통 인수검사와 필수 테스트 ID는 그대로 유지합니다.

Schemathesis 4.4.4는 OpenAPI에서 검사 입력을 만들고, Hurl 8.1.0은 사용자가 준비한 업무 시나리오를 실행합니다. 도구 버전과 Python 의존성을 고정합니다. Schemathesis 최신판의 예제나 옵션을 이 구버전에 그대로 적용하지 마세요. Hurl은 Python 패키지가 아닌 운영체제별 실행파일입니다. 이 키트의 도구 설치 대상은 Windows/Linux x86_64이며, 다른 아키텍처를 지원한다고 가정하지 않습니다.

Schemathesis는 `coverage,fuzzing` 단계로 실행합니다. 명세의 예제가 없다는 이유로 실행한 검사와 스킵이 하나의 JUnit 결과에 섞이지 않게 범위를 명시합니다. 이 설정에서 예제 단계나 자동 상태 전이 검사를 실행했다고 주장하지 않습니다. 요청 순서와 승인·재시도 등 업무 흐름은 고정 Hurl 시나리오 및 기존 인수검사가 담당합니다.

## 별도 도구 환경 설치

Python 3.9가 설치된 상태에서 키트 폴더를 기준으로 실행합니다. 도구 폴더는 키트 및 대상 프로젝트 바깥에 둡니다. 가상환경과 실행파일은 다른 운영체제로 복사하지 않고 각 컴퓨터에서 다시 설치합니다.

Windows PowerShell:

```powershell
py -3.9 optional/api-review/setup_tools.py install --tools-dir "D:\tools\harness-api-review"
```

Linux:

```bash
python3.9 optional/api-review/setup_tools.py install --tools-dir ../harness-api-review-tools
```

이 명령은 선택한 폴더에만 도구용 Python 3.9 가상환경과 Hurl을 준비합니다. 애플리케이션의 가상환경과 전역 Python 패키지를 변경하지 않습니다. 최초 설치에는 공식 PyPI/GitHub 배포 파일을 받기 위한 네트워크가 필요합니다. 고정된 해시를 확인하고 실제 도구 버전을 검사합니다. 설치가 실패하면 API 검수가 성공했다고 기록하지 않습니다.

Windows Hurl은 Microsoft Visual C++ 런타임이 필요할 수 있고, Linux 바이너리는 호환되는 libc와 동적 라이브러리가 필요합니다. 누락된 시스템 구성 요소는 설치 오류로 안내하며 전역 설치를 자동 실행하지 않습니다. 자세한 배포 조건은 [Hurl 설치 문서](https://hurl.dev/docs/installation.html)를 참고하세요.

## 대상 프로젝트 준비

먼저 일반 `setup_env.py attach`로 하네스를 연결하고, 앱 명세·경계 질문/실제 답변·필수 테스트·공통 검사기를 준비합니다. API 검사만으로 미완성 인수검사를 대체할 수 없습니다.

프로젝트별로 아래 항목을 준비합니다.

- 서버 실행 명령: 현재 프로젝트의 Python 3.9로 실행하며 포트를 인자로 받을 수 있어야 합니다.
- 준비 확인 주소와 OpenAPI JSON 주소.
- 필수 업무 흐름을 검사하는 `.hurl` 파일 목록. 단순히 HTTP 200만 확인하지 말고 응답 값과 금지한 동작까지 확인합니다.
- 테스트용 저장소 및 외부 연동 설정. DB·업로드·로그 등 런타임 파일은 `{work}` 아래에 쓰도록 앱을 설정합니다. 서버 앱 자체의 외부 서비스 호출도 프로젝트에서 테스트용으로 설정해야 합니다.

다음은 형식 예시입니다. 실제 서버 명령과 파일 이름으로 바꿔 UTF-8 JSON 파일에 저장합니다. 예시 서버·업무 테스트를 자동 생성하는 기능은 아닙니다.

```json
{
  "version": 1,
  "server": {
    "argv": ["{python}", "server.py", "--port", "{port}", "--data-dir", "{work}"],
    "readiness_path": "/health",
    "timeout_seconds": 15
  },
  "schema_path": "/openapi.json",
  "scenarios": ["tests/api/approval.hurl", "tests/api/retry.hurl"],
  "timeout_seconds": 60,
  "max_examples": 20
}
```

`{python}`은 앱 프로젝트의 실행 인터프리터, `{port}`는 로컬 검사에 선택한 포트, `{work}`는 이번 실행의 격리된 결과 폴더입니다. 셸 명령 문자열 대신 인수 배열을 사용합니다. 서버가 위 인수를 지원하지 않으면 프로젝트에 작은 실행 스크립트를 준비합니다. 비밀값을 설정 파일·명령 인수·Hurl 파일에 하드코딩하지 마세요. 검수에는 가짜 데이터와 테스트용 인증 정보를 사용합니다.

최상위 `timeout_seconds`는 Schemathesis 실행 1회와 각 Hurl 파일 실행에 각각 적용하는 제한입니다. 전체 `verify` 등록 시간은 시나리오 수·서버 준비 시간·정리 여유를 합산합니다. 서버 준비 제한은 `server.timeout_seconds`입니다. 시간 초과는 통과가 아니며 실행기가 시작한 자식 프로세스를 종료하고 기다립니다.

Hurl의 모든 요청은 `{{base_url}}`을 사용합니다. 응답에서 실제 ID를 추출해 후속 요청에 전달할 수 있습니다. 검사할 경로와 기대값은 앱 명세에 맞춰 작성해야 합니다. 필수 API가 OpenAPI에서 누락되면 자동 생성 검사만으로는 누락을 판단할 수 없으므로, 명세상 필수 동작은 고정된 Hurl 시나리오와 기존 필수 테스트로 확인합니다.

## 선택한 프로젝트에 연결

키트 폴더에서 실행합니다. `--config`는 앞서 작성한 파일의 경로입니다.

```powershell
py -3.9 optional/api-review/setup_tools.py enable --project "D:\projects\my-app" --tools-dir "D:\tools\harness-api-review" --config "D:\projects\my-app\api-review-config.json"
```

```bash
python3.9 optional/api-review/setup_tools.py enable --project /workspaces/my-app --tools-dir ../harness-api-review-tools --config /workspaces/my-app/api-review-config.json
```

연결하면 선택한 프로젝트에 `.harness/api-review/check_api.py`, `.harness/api-review.json`, `.harness/api-tools.json`이 준비되고, 기존 `.harness/checks.json`에 API 검사 명령이 추가됩니다. 기존 검사·설정·사용자 문서를 보존합니다. 검사기·설정·고정 시나리오는 보호 경로에 등록합니다. 존재하지 않는 시나리오나 다른 내용의 설치 파일 충돌은 무시하고 진행하지 않습니다.

`api-tools.json`은 해당 컴퓨터의 도구 경로를 담습니다. Windows/Linux로 작업 환경을 옮기면 그 환경에 별도 도구를 설치하고 같은 `enable` 명령에 해당 환경의 경로를 명시해 다시 연결합니다. 이후 변경된 설정과 현재 코드로 재검증합니다.

## 실행 및 기록

대상 프로젝트 폴더에서 기존 명령을 사용합니다.

```text
python3.9 run_harness.py verify
```

Windows에서는 `python3.9` 대신 `py -3.9`를 사용합니다. API 검사 등록 이후에는 `verify`가 기존 검사와 추가 API 검수를 실행합니다. 개발 loop의 매 라운드에 API 검사를 자동 등록하거나 추가 자동 수정 루프를 시작하지 않습니다. 기존 검사가 먼저 실패해 API 검사가 실행되지 않았다면 미실행으로 남깁니다.

검수기는 새 로컬 서버와 격리된 실행 폴더를 준비하고 Schemathesis와 Hurl을 실행한 뒤 자신이 시작한 프로세스를 정리합니다. 검사 결과와 원본 로그는 `.harness/work/api-review/`에 남습니다. 이 경로는 기존 하네스의 런타임 기록 경로입니다. 프로젝트 소스에 결과 파일을 만들거나 변경 감지를 끄지 않습니다. 실제 소스가 바뀌면 검수 결과를 유효하게 처리하지 않습니다.

검사 0개, 전부 스킵, 필수 시나리오 누락, 도구/서버 준비 실패, 잘못된 보고서는 통과가 아닙니다. JUnit 테스트 케이스 수와 생성 입력 수·HTTP 요청 수를 같은 수치로 표현하지 않습니다. 오류가 없는 응답 형식도 업무 정답이나 모든 경로의 검증 완료를 뜻하지 않습니다.

`docs/progress.md`에는 실제 실행 결과와 원본 근거가 연결됩니다. `docs/review-score.md`는 기존 리뷰 점수와 후속 API 검수의 범위를 구분합니다. 검수 성공으로 점수를 자동 가산하거나 독립 리뷰를 다시 호출하지 않습니다. 다음에 허용된 독립 리뷰가 유효한 검사 근거를 참고해 실제로 검토한 항목만 평가합니다. 이전 API 실행은 리뷰어가 이번 세션에서 직접 실행한 명령으로 취급하지 않습니다.

원본 로그가 바뀌거나 삭제되거나 검사한 소스가 달라지면 이전 API 근거를 현재 유효한 근거로 사용하지 않습니다. 기록 MD는 직접 수정하지 않습니다. `check_api.py`를 단독 실행하는 것은 진단용이며 stdout 결과만 출력합니다. 자동 MD 기록은 `verify` 컨트롤러가 수행합니다.

## 포함 범위

키트에는 연결 코드·고정 버전 정보·자체 테스트만 포함됩니다. 앱 구현이나 실제 문제 풀이, 가상환경, 다운로드한 도구 실행파일은 포함하지 않습니다. 선택형 도구의 설치와 실제 양OS 검증 범위는 ZIP의 `VALIDATION.txt` 및 `validation/`를 참고하세요.
