# 컴퓨터별 사전 준비

키트 설치는 기존 Python 3.9로 가상환경을 만드는 작업입니다. 운영체제에 필요한 도구가 없다면 먼저 준비한 뒤 `setup_env.py doctor`로 다시 확인하세요.

Schemathesis 4.4.4와 Hurl 8.1.0은 기본 환경에 설치하지 않습니다. 필요한 HTTP API 프로젝트에서만 [선택형 API 검수](OPTIONAL_API_REVIEW.md)에 따라 별도 도구 환경을 준비하고 `verify`에 연결합니다.

가상환경의 실제 폴더 이름은 `.venv`입니다. 다른 운영체제에서 만든 환경이나 Python 버전이 다른 환경이 이미 있으면 자동 삭제하지 않고 중단합니다. 기존 환경이 필요한지 확인한 뒤 별도로 보관하고 이 컴퓨터에서 다시 준비하세요.

## Python 3.9와 Git

Windows PowerShell:

```powershell
py -3.9 --version
git --version
```

Linux / Codespaces:

```bash
python3.9 --version
python3.9 -m venv --help
git --version
```

Python 버전이 `3.9.x`여야 합니다. Linux에서는 사용 중인 배포판이나 Codespaces 이미지에 맞게 Python 3.9와 `venv` 지원을 준비하세요. Codespaces에 기본 제공되는 `python`이 3.9라고 가정하지 마세요. Git은 터미널의 `PATH`에서 실행 가능해야 합니다.

이미 설치한 Python을 찾지 못한다면 다음처럼 실행 파일을 지정할 수 있습니다. 예시 경로는 실제 설치 위치로 바꿉니다.

```powershell
& "C:\Python39\python.exe" setup_env.py install --python39 "C:\Python39\python.exe"
```

```bash
/opt/python39/bin/python3.9 setup_env.py install --python39 /opt/python39/bin/python3.9
```

## Codex CLI와 로그인

Codex CLI는 [OpenAI 공식 설치 안내](https://learn.chatgpt.com/docs/codex/cli)에 따라 준비합니다. Node.js/npm이 있는 환경에서는 `npm install -g @openai/codex`로 설치할 수 있습니다. 다른 설치 경로는 공식 안내를 따르세요. npm 설치 명령은 [공식 Cookbook의 설치 예시](https://developers.openai.com/cookbook/examples/codex/using_goals_in_codex)에서도 확인할 수 있습니다.

설치 후 새 터미널에서 확인합니다.

```text
codex --version
codex login
codex login status
```

`codex login`은 사용자가 로그인하는 단계입니다. 키트는 계정을 대신 만들거나 로그인 정보를 복사하지 않습니다. [OpenAI 공식 인증 안내](https://learn.chatgpt.com/docs/auth)

Codespaces처럼 원격 환경에서 브라우저 로그인 연결이 어려우면 `codex login --device-auth`를 사용할 수 있습니다. 계정이나 워크스페이스에서 기기 코드 로그인이 허용되어 있어야 합니다. [원격 환경 인증 안내](https://learn.chatgpt.com/docs/auth#login-on-headless-devices)

Windows에서 `codex.ps1` 실행이 PowerShell 정책에 막히면 npm 설치의 `codex.cmd --version`, `codex.cmd login`을 사용할 수 있습니다. Python 실행기는 npm의 Windows 래퍼를 처리합니다. Codex 자체의 Windows 샌드박스가 아직 준비되지 않았다면 [공식 Windows 안내](https://learn.chatgpt.com/docs/windows/windows-sandbox)를 따르세요.

## 준비 완료의 의미

`attach`는 대상 프로젝트에 `docs/progress.md`와 `docs/review-score.md`를 미착수·미산정 상태로 준비합니다. 기존 사용자 문서를 덮어쓰지 않습니다. 진행 기록과 점수는 이후 하네스 작업·검사·독립 리뷰 결과에 따라 생성하며, 설치만으로 구현이나 리뷰를 수행하지 않습니다.

`doctor`와 `loop --preflight`는 로컬 준비 상태를 검사합니다. 로그인 성공은 특정 모델의 사용 권한이나 실제 작업 성공을 보장하지 않습니다. 정확한 모델 ID는 자신의 Codex에서 사용 가능한 값으로 설정해야 합니다.

프로젝트 연결 뒤에는 선택한 앱 명세와 실제 `builder_model`을 설정하고 `run_harness.py clarify`로 모호한 조건을 확인합니다. 분석은 실제 모델을 호출하지만 소스 구현은 하지 않습니다. 출력된 질문의 실제 담당자 답변을 UTF-8 파일로 준비하여 `clarify --answer Q-001 --answer-file answer.txt`로 기록하고 다시 `clarify`를 실행합니다. 모든 질문에 실제 답변이 있고 재분석에서 미해결 조건이 없어야 `clarify --check-ready`가 통과합니다. `--answer`, `--status`, `--check-ready`는 로컬 명령이며 모델을 호출하지 않습니다.

그다음 `docs/CROSS_PLATFORM.md`에 따라 `.harness/acceptance.json`, 고정 필수 테스트 ID 목록, 실제 인수테스트·기준 자료를 준비합니다. `boundary_tests`에는 실제 답변이 있는 모든 질문 ID와 이를 검사하는 필수 테스트 ID를 연결합니다. 이 등록이 없거나 경계 질문이 미해결이면 작업 준비 점검과 최종 검증이 실패합니다. 공통 검사기와 별도 프로젝트 라이브러리는 해당 프로젝트에서 준비하며, 설치 단계가 업무별 테스트를 자동으로 만들어 주지는 않습니다. 기존 `AGENTS.md`는 독립된 프로젝트 지침으로 유지됩니다.

`install`, `doctor`, `attach`, `clarify`와 `loop --help`, `loop --preflight`, `loop --probe-models`는 tmux 세션을 만들지 않습니다. `clarify` 분석과 `--probe-models`는 실제 모델을 호출합니다. `--probe-models`는 일반적인 준비 점검에는 붙이지 마세요. 실제 loop 전에 `--preflight`로 질문/답변·필수 테스트 매핑과 실행 환경을 함께 점검하세요.

## Linux / Codespaces의 tmux 준비

Linux / Codespaces에서 실제 `run_harness.py loop` 작업에는 tmux가 필요합니다. Windows에서는 같은 명령이 현재 터미널에서 실행되므로 tmux를 설치할 필요가 없습니다.

Linux에서 설치 여부를 확인합니다.

```bash
tmux -V
```

Debian / Ubuntu 기반 환경이나 해당 Codespaces 이미지에서 tmux가 없다면 사용자가 다음 시스템 설치 명령을 실행할 수 있습니다. 관리자 권한과 패키지 저장소 연결이 필요합니다. 다른 배포판은 해당 패키지 관리자를 사용하세요.

```bash
sudo apt update
sudo apt install tmux
```

키트는 시스템 도구를 자동 설치하지 않습니다. tmux가 없는 Linux에서 실제 `loop`를 실행하면 설치 안내와 함께 중단합니다. 이미 tmux 안에서 실행하면 현재 패널을 사용하고 중첩 세션을 만들지 않습니다.

같은 `loop` 명령이 실제 운영체제를 감지하므로 별도의 Windows/Linux 선택은 필요하지 않습니다. Codespaces의 Python·권한·로그인·tmux 상태는 그 환경에서 확인해야 하며, 이 안내만으로 실제 Codespaces 실행이 검증된 것은 아닙니다. 배포본 검증 결과는 키트 루트의 `VALIDATION.txt`에 있습니다.
