"""Identical source, native Python 3.9; no actual model calls."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading
import time

def hashes(root):
    return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()
            and not set(p.relative_to(root).parts)&{'.git','.venv','__pycache__','work'}}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage',type=Path,required=True)
    parser.add_argument('--evidence',type=Path,required=True)
    parser.add_argument('--parallel',action='store_true')
    parser.add_argument('--tools',type=Path,required=True)
    parser.add_argument('--retry-api',action='store_true',help='Rerun API jobs after changes confined to optional/api-review; prove all retained inputs unchanged')
    args=parser.parse_args()
    assert sys.version_info[:2]==(3,9),sys.version
    root=args.stage.resolve()/'codex_computer_setup_py39'
    evidence=args.evidence.resolve()
    evidence.mkdir(parents=True,exist_ok=True)
    platform='windows' if os.name=='nt' else 'linux'
    env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONPATH',None)
    env['HARNESS_API_TOOLS_DIR']=str(args.tools.resolve())
    report=dict(platform=sys.platform,python=sys.version,status='running',results=[],live_model_calls=0,started_at=time.time())
    before=hashes(root)
    if args.retry_api:
        old=json.loads((evidence/(platform+'-results.json')).read_text(encoding='utf-8'))
        previous=json.loads((evidence/(platform+'-source-sha256.json')).read_text(encoding='utf-8'))
        assert old['status']=='failed', 'Only retry a completed failing matrix'
        changed=sorted(name for name in set(previous)|set(before) if previous.get(name)!=before.get(name))
        assert changed and all(name.startswith('optional/api-review/') for name in changed), changed
        assert {row['name'] for row in old['results']}=={'optional-api','api-workflow','setup-and-tmux','harness','loop','report-workflow'}
        rerun={'optional-api','api-workflow'}|{row['name'] for row in old['results'] if not row['passed']}
        retained=[row for row in old['results'] if row['name'] not in rerun]
        assert all(row['passed'] for row in retained), retained
        history=evidence/'initial-validation'/platform
        history.mkdir(parents=True,exist_ok=False)
        for name in [platform+'-results.json',platform+'-source-sha256.json']+[row['log'] for row in old['results']]:
            shutil.copy2(evidence/name,history/name)
        for suffix in ('-api-workflow','-api-workflow.json'):
            path=evidence/(platform+suffix)
            if path.is_dir():
                shutil.move(str(path),str(history/path.name))
            elif path.is_file():
                shutil.move(str(path),str(history/path.name))
        report['results']=retained
        report['retest']={'changed_files':changed,'retained_jobs':[row['name'] for row in retained],
                          'rerun_jobs':sorted(rerun),'retained_source_files_identical':True,
                          'initial_evidence':str(history.relative_to(evidence))}
    lock=threading.Lock()
    def save():
        (evidence/(platform+'-results.json')).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    def run(name,command,cwd,unit=False):
        print('START '+name,flush=True)
        started=time.time()
        log=platform+'-'+name+'.log'
        with (evidence/log).open('w',encoding='utf-8') as stream:
            stream.write(json.dumps(dict(argv=command,cwd=str(cwd)))+'\n')
            stream.flush()
            result=subprocess.run(command,cwd=str(cwd),env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=1800)
        raw=(evidence/log).read_text(encoding='utf-8',errors='replace')
        item=dict(name=name,exit_code=result.returncode,passed=result.returncode==0,seconds=round(time.time()-started,3),log=log)
        if unit:
            ran=re.search(r'Ran (\d+) tests? in',raw)
            skip=re.search(r'(?:OK|FAILED)[^\n]*skipped=(\d+)',raw)
            item.update(tests_run=int(ran.group(1)) if ran else 0,skipped=int(skip.group(1)) if skip else 0)
            item['passed']=item['passed'] and item['tests_run']>item['skipped']
        with lock:
            report['results'].append(item)
            save()
        print('END '+name+': '+str(item),flush=True)
        if not item['passed']:
            raise AssertionError(name+'\n'+raw[-18000:])
    jobs=[('optional-api',[sys.executable,'-B','-m','unittest','discover','-s','tests','-v'],root/'optional/api-review',True),
          ('api-workflow',[sys.executable,'-B',str(Path(__file__).with_name('api_integration.py')),'--kit',str(root),'--tools',str(args.tools.resolve()),'--evidence',str(evidence)],root,False),
          ('setup-and-tmux',[sys.executable,'-B','-m','unittest','discover','-s','tests','-v'],root,True),
          ('harness',[sys.executable,'-B','-m','unittest','discover','-s','.harness/tests','-v'],root/'template',True),
          ('loop',[sys.executable,'-B','-m','unittest','discover','-s','tests','-v'],root/'template/automation/codex-loop',True),
          ('report-workflow',[sys.executable,'-B',str(Path(__file__).with_name('integration_checks.py')),
                              '--kit',str(root),'--evidence',str(evidence)],root,False)]
    if args.retry_api:
        jobs=[job for job in jobs if job[0] in rerun]
    (evidence/(platform+'-source-sha256.json')).write_text(json.dumps(before,indent=2)+'\n')
    try:
        for path in root.rglob('*.py'):
            compile(path.read_bytes(),str(path),'exec')
        if args.parallel and not (args.retry_api and os.name == 'nt'):
            with ThreadPoolExecutor(max_workers=3) as pool:
                pending=[pool.submit(run,*job) for job in jobs]
                for future in pending:
                    future.result()
        else:
            for job in jobs:
                run(*job)
        assert before==hashes(root),'Source changed during validation'
        report['status']='passed'
    except BaseException as exc:
        report['status']='failed'
        report['error']=repr(exc)
        raise
    finally:
        report['finished_at']=time.time()
        save()

if __name__=='__main__':
    main()
