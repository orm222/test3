"""Real pinned API tools and HTTP, with a simulated reviewer only."""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--kit', type=Path, required=True)
    parser.add_argument('--tools', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    assert sys.version_info[:2] == (3, 9)
    kit, tools = args.kit.resolve(), args.tools.resolve()
    label = 'windows' if os.name == 'nt' else 'linux'
    normal_timeout = 60 if os.name == 'nt' else 30
    evidence = args.evidence.resolve() / (label + '-api-workflow')
    evidence.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
    results = []
    started = time.time()
    temporary = tempfile.TemporaryDirectory(prefix='api final workflow ')
    base = Path(temporary.name).resolve()
    project = base / 'project with spaces'
    project.mkdir()

    def write(name, value):
        path = project / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value, encoding='utf-8')

    def invoke(name, argv, expected=0, timeout=240):
        result = subprocess.run(argv, cwd=str(project), env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True, encoding='utf-8', timeout=timeout)
        (evidence / (name + '.log')).write_text(json.dumps(argv) + '\n' + result.stdout + result.stderr, encoding='utf-8')
        assert result.returncode == expected, (name, result.returncode, result.stdout, result.stderr)
        return result

    def cli(name, action, expected=0):
        return invoke(name, [sys.executable, '-B', str(project / 'run_harness.py'), action], expected)

    def record(name):
        results.append(dict(case=name, passed=True))
        print('PASS ' + name, flush=True)

    def config(mode='good', timeout=normal_timeout):
        return {'version': 1, 'server': {'argv': ['{python}', 'server.py', '--port', '{port}',
                '--work', '{work}', '--mode', mode], 'readiness_path': '/health',
                'timeout_seconds': 0.5 if mode == 'notready' else 15},
                'schema_path': '/openapi.json', 'scenarios': ['tests/api/smoke.hurl'],
                'timeout_seconds': timeout, 'max_examples': 5}

    def enable(mode='good', timeout=normal_timeout):
        supplied = base / 'api-config.json'
        supplied.write_text(json.dumps(config(mode, timeout)), encoding='utf-8')
        invoke('enable-' + mode, [sys.executable, '-B', str(kit / 'optional/api-review/setup_tools.py'),
               'enable', '--project', str(project), '--tools-dir', str(tools), '--config', str(supplied)])

    def api_receipt():
        paths = sorted((project / '.harness/work').glob('verify-*/receipt.json'))
        receipt = json.loads(paths[-1].read_text(encoding='utf-8'))
        row = next(row for row in receipt['results'] if row['name'] == 'api-review')
        return receipt, json.loads((project / row['log']).read_text(encoding='utf-8'))

    def stopped(report):
        server = report.get('server')
        if server and server.get('base_url'):
            port = int(server['base_url'].rsplit(':', 1)[1])
            with socket.socket() as connection:
                connection.settimeout(0.5)
                assert connection.connect_ex(('127.0.0.1', port)) != 0, 'Owned server still listening'
        if server and server.get('pid'):
            assert not verification.check_process_running(server['pid']), 'Owned server still running'

    try:
        write('AGENTS.md', 'Existing user instructions must be preserved.\n')
        write('SPEC.md', '# Test fixture\nExact integer addition. Local API GET /ping returns JSON message hello; no production data.\n')
        write('calc.py', 'def add(a,b):\n    return a+b\n')
        write('tests/test_calc.py', 'import unittest\nfrom calc import add\nclass Addition(unittest.TestCase):\n'
              ' def test_values(self):\n  self.assertEqual([add(2,3),add(-2,3),add(0,0)],[5,1,0])\n')
        write('server.py', (kit / 'optional/api-review/tests/api_fixture.py').read_text(encoding='utf-8'))
        write('tests/api/smoke.hurl', 'GET {{base_url}}/ping\nHTTP 200\n[Asserts]\njsonpath "$.message" == "hello"\n')
        invoke('attach', [sys.executable, '-B', str(kit / 'setup_env.py'), 'attach', '--project', str(project),
                         '--spec', 'SPEC.md', '--python39', sys.executable])
        assert not (project / '.harness/api-review.json').exists()
        assert not (project / '.harness/api-review').exists()
        assert not any('api-review' in str(row) for row in json.loads((project / '.harness/checks.json').read_text())['checks'])
        record('default-attach-has-no-api-tool-install-or-registration')
        write('.harness/required_tests.json', json.dumps({'version': 1, 'required_test_ids': ['test_calc.Addition.test_values']}))
        write('.harness/acceptance.json', json.dumps({'version': 1,
              'checker_argv': ['{python}', '-B', '.harness/check_unittest.py'],
              'required_ids_manifest': '.harness/required_tests.json', 'protected_paths': ['tests']}))
        write('.harness/checks.json', json.dumps({'checks': [{'name': 'acceptance', 'command': ['{python}', '-B', '.harness/check_unittest.py']}]}))
        boundary = load('api_workflow_boundary', project / '.harness/boundary.py')
        state = boundary.create_state(project, 'SPEC.md')
        boundary.complete_analysis(project, state, {'version': 1, 'questions': [], 'unresolved': [], 'references': []})
        verification = load('api_workflow_verification', project / '.harness/verification.py')
        initial_tasks = (project / 'automation/codex-loop/tasks.json').read_bytes()
        enable()
        enable()
        assert (project / 'automation/codex-loop/tasks.json').read_bytes() == initial_tasks
        assert (project / 'AGENTS.md').read_text() == 'Existing user instructions must be preserved.\n'
        registrations = json.loads((project / '.harness/checks.json').read_text())['checks']
        assert [row['name'] for row in registrations].count('api-review') == 1
        assert any(row['name'] == 'acceptance' for row in registrations)
        record('explicit-enable-is-idempotent-preserves-checks-tasks-and-user-files')
        cli('good-verify', 'verify')
        receipt, report = api_receipt()
        assert receipt['passed'] and report['status'] == 'passed'
        assert report['source_hash'] == report['source_hash_after']
        assert [row['id'] for row in report['checks']] == ['schemathesis', 'hurl']
        assert all(row['status'] == 'PASS' and row['counts']['passed'] > 0 for row in report['checks'])
        stopped(report)
        (evidence / 'good-api-result.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
        shutil.copytree(project / '.harness/work/api-review' / report['run_id'], evidence / 'good-raw-logs')
        cli('good-status', 'status')
        record('real-schemathesis-and-hurl-pass-with-raw-evidence-and-stopped-server')

        # Review plumbing is simulated; the referenced API checks above are real.
        fake = base / 'fake-review.py'
        rows = [{'criterion_id': prefix + '%02d' % number, 'status': 'UNVERIFIED',
                 'reason': 'Simulated reviewer did not verify this criterion.', 'evidence_refs': []}
                for prefix in ('COR', 'TEST', 'REL', 'MEAS', 'HAND') for number in range(1, 5)]
        next(row for row in rows if row['criterion_id'] == 'TEST01').update(status='PARTIAL',
             reason='Simulated review consumes two real completed API-check receipts; no broader coverage claim.',
             evidence_refs=['api-check:schemathesis', 'api-check:hurl'])
        answer = dict(summary='SIMULATED review of real API evidence', reviewed_files=['server.py'], findings=[],
                      limitations=['No actual model review was invoked.'], criterion_scores=rows)
        fake.write_text('import json,sys\nfrom pathlib import Path\n'
                        'args=sys.argv[1:]\n'
                        'if args==["login","status"]: raise SystemExit(0)\n'
                        'prompt=sys.stdin.read()\n'
                        'Path(' + repr(str(evidence / 'SIMULATED-review-prompt.txt')) + ').write_text(prompt,encoding="utf-8")\n'
                        'Path(args[args.index("--output-last-message")+1]).write_text(json.dumps(' + repr(answer) + '),encoding="utf-8")\n'
                        'print(json.dumps({"type":"turn.completed"}))\n', encoding='utf-8')
        with patch.object(sys, 'path', [str(project / '.harness'), *sys.path]):
            harness = load('api_workflow_harness', project / '.harness/harness.py')
        stream = io.StringIO()
        with patch.object(harness, 'codex_command', return_value=[sys.executable, str(fake)]), contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
            code = harness.review(project, 'Check recorded API evidence, simulation only', timeout=60,
                                  remaining_seconds=600, reserve_seconds=60)
        (evidence / 'SIMULATED-review.log').write_text(stream.getvalue(), encoding='utf-8')
        assert code == 0, stream.getvalue()
        assert 'api-check:schemathesis' in (evidence / 'SIMULATED-review-prompt.txt').read_text(encoding='utf-8')
        score = (project / 'docs/review-score.md').read_text(encoding='utf-8')
        assert 'PARTIAL' in score and 'api-check:schemathesis' in score
        for name in ('progress.md', 'review-score.md'):
            shutil.copy2(project / 'docs' / name, evidence / ('SIMULATED-' + name))
        record('real-api-evidence-reaches-simulated-review-with-no-fabricated-automatic-score')

        artifact = next(row for row in report['checks'][0]['artifacts'] if row['path'].endswith('.xml'))
        target = Path(artifact['path'])
        if not target.is_absolute():
            target = project / target
        original = target.read_bytes()
        target.write_bytes(b'<forged/>')
        cli('tampered-api-evidence', 'status', expected=1)
        assert '점수 미산정' in (project / 'docs/review-score.md').read_text(encoding='utf-8')
        target.write_bytes(original)
        record('altered-api-xml-invalidates-current-receipt-and-review-evidence')

        for mode, timeout in (('wrongbody', normal_timeout), ('server500', normal_timeout),
                              ('notready', normal_timeout), ('slow', 0.5), ('mutate', normal_timeout)):
            # The installer was exercised twice above. Change only the fixture's
            # server mode here; the existing whole-check budget covers these cases.
            write('.harness/api-review.json', json.dumps(config(mode, timeout)))
            cli(mode + '-verify', 'verify', expected=1)
            receipt, report = api_receipt()
            assert not receipt['passed'] and report['status'] in ('failed', 'error')
            if mode == 'wrongbody':
                assert report['checks'][0]['status'] == 'PASS' and report['checks'][1]['status'] == 'FAIL'
            if mode == 'server500':
                assert report['checks'][0]['status'] == 'FAIL'
            if mode == 'notready':
                assert all(row['status'] == 'NOT_RUN' for row in report['checks'])
            if mode == 'mutate':
                assert report['source_hash'] != report['source_hash_after']
            stopped(report)
            (evidence / (mode + '-api-result.json')).write_text(json.dumps(report, indent=2), encoding='utf-8')
            if report.get('run_id'):
                shutil.copytree(project / '.harness/work/api-review' / report['run_id'], evidence / (mode + '-raw-logs'))
            record(mode + '-is-not-accepted-and-owned-server-is-stopped')
        assert 'api-review' in (project / 'docs/progress.md').read_text(encoding='utf-8')
    except BaseException:
        # Keep diagnostics even when an unexpected assertion aborts this fixture.
        work = project / '.harness/work'
        if work.is_dir():
            shutil.copytree(work, evidence / 'unexpected-failure-work')
        raise
    finally:
        # All owned processes were waited for; scanners can briefly retain Windows handles.
        deadline = time.monotonic() + 5
        while True:
            try:
                temporary.cleanup()
                break
            except PermissionError as exc:
                if os.name != 'nt' or getattr(exc, 'winerror', None) not in (5, 32) or time.monotonic() >= deadline:
                    raise
                time.sleep(.05)
    summary = dict(status='passed', python=sys.version, live_model_calls=0, real_api_tools=True,
                   seconds=round(time.time()-started, 3), results=results)
    (args.evidence / (label + '-api-workflow.json')).write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
