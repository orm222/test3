"""User-facing entrypoint workflow using fake models and real checks, no business example."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

WRAPPER = '''import io,json,runpy,sys
from pathlib import Path
prompt=sys.stdin.read()
if 'BOUNDARY_CLARIFICATION_CONTEXT\\n' in prompt:
    context=json.loads(prompt.split('BOUNDARY_CLARIFICATION_CONTEXT\\n',1)[1])
    q=[] if context['actual_answers'] else [dict(template='T06',question='Should negative integer inputs use exact addition?',decides='Negative integer behavior',follow_up_to=None)]
    report=dict(version=1,questions=q,unresolved=['Negative integer behavior'] if q else [],references=['RULES.md'])
    Path(sys.argv[sys.argv.index('--output-last-message')+1]).write_text(json.dumps(report),encoding='utf-8')
else:
    sys.stdin=io.StringIO(prompt)
    runpy.run_path(FAKE_PATH,run_name='__main__')
'''

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--kit',type=Path,required=True)
    parser.add_argument('--evidence',type=Path,required=True)
    args=parser.parse_args()
    kit=args.kit.resolve()
    label='windows' if os.name=='nt' else 'linux'
    folder=args.evidence/(label+'-report-workflow')
    folder.mkdir(exist_ok=True)
    results=[]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
    with tempfile.TemporaryDirectory(prefix='boundary workflow ') as temporary:
        base=Path(temporary).resolve()
        project=base/'project spaces'
        project.mkdir()
        def write(name,value):
            path=project/name
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_text(value,encoding='utf-8')
        def write_json(name,value):
            write(name,json.dumps(value,indent=2)+'\n')
        def invoke(name,argv,expected=0,timeout=180):
            result=subprocess.run(argv,cwd=str(project),env=env,capture_output=True,text=True,encoding='utf-8',timeout=timeout)
            (folder/(name+'.log')).write_text(json.dumps(argv)+'\n'+result.stdout+result.stderr,encoding='utf-8')
            assert result.returncode==expected,(name,result.returncode,result.stdout,result.stderr)
            results.append(dict(case=name,passed=True,exit_code=result.returncode))
            return result
        def cli(name,*argv,expected=0):
            return invoke(name,[sys.executable,'-B',str(project/'run_harness.py'),*argv],expected)
        write('AGENTS.md','Existing project instructions stay unchanged.\n')
        write('SPEC.md','# Addition\nImplement integer addition; consult RULES.md. Negative-input policy needs an actual answer.\n')
        write('RULES.md','Positive and zero integers use exact addition.\n')
        invoke('attach',[sys.executable,'-B',str(kit/'setup_env.py'),'attach','--project',str(project),'--spec','SPEC.md','--python39',sys.executable])
        assert (project/'AGENTS.md').read_text()=='Existing project instructions stay unchanged.\n'
        assert not (project/'.harness/boundary.json').exists()
        assert not (project/'BOUNDARY_ANSWERS.md').exists()
        assert '미산정' in (project/'docs/review-score.md').read_text(encoding='utf-8')
        assert '미착수' in (project/'docs/progress.md').read_text(encoding='utf-8')
        results.append(dict(case='initial-managed-documents-without-fabricated-history',passed=True))
        wrapper=base/'fake_cli.py'
        fake=kit/'template/automation/codex-loop/tests/fake_codex.py'
        wrapper.write_text('FAKE_PATH='+repr(str(fake))+'\n'+WRAPPER,encoding='utf-8')
        conf_path=project/'automation/codex-loop/config.json'
        conf=json.loads(conf_path.read_text(encoding='utf-8'))
        conf.update(builder_model='SIMULATED-sol',reviewer_model='SIMULATED-terra',
                    codex_command=[sys.executable,str(wrapper)],run_root=str(base/'external-runs'),
                    stage_timeout_seconds=30,total_timeout_seconds=240)
        write_json('automation/codex-loop/config.json',conf)
        cli('question','clarify',expected=2)
        cli('pending-readiness','clarify','--check-ready',expected=2)
        cli('pending-loop','loop',expected=2)
        answer='Negative integer inputs must use exact addition; add(-2, 3) is 1.'
        answer_file=base/'actual-answer.txt'
        answer_file.write_text(answer,encoding='utf-8')
        cli('actual-answer','clarify','--answer','Q-001','--answer-file',str(answer_file))
        cli('answer-needs-reanalysis','clarify','--check-ready',expected=2)
        cli('reanalysis','clarify')
        cli('ready','clarify','--check-ready')
        assert answer in (project/'BOUNDARY_ANSWERS.md').read_text(encoding='utf-8')
        tests='import unittest\nfrom calc import add\n\nclass TestAdd(unittest.TestCase):\n'
        for name,a,b,total in [('positive',2,3,5),('zero',0,0,0),('negative',-2,3,1)]:
            tests+='    def test_{}(self):\n        self.assertEqual(add({}, {}), {})\n'.format(name,a,b,total)
        write('tests/test_calc.py',tests)
        write('calc.py','def add(a, b):\n    return a + b\n')
        required=['test_calc.TestAdd.test_'+name for name in ('positive','zero','negative')]
        write_json('.harness/required_tests.json',dict(version=1,required_test_ids=required))
        contract=dict(version=1,checker_argv=['{python}','-B','.harness/check_unittest.py'],
                      required_ids_manifest='.harness/required_tests.json',protected_paths=['tests'],boundary_tests={})
        write_json('.harness/acceptance.json',contract)
        write_json('.harness/checks.json',dict(checks=[dict(name='acceptance',command=contract['checker_argv'])]))
        tasks=json.loads((kit/'template/automation/codex-loop/tasks.example.json').read_text(encoding='utf-8'))
        write_json('automation/codex-loop/tasks.json',tasks)
        proc=cli('missing-test-mapping','verify',expected=1)
        assert 'boundary' in (proc.stdout+proc.stderr).lower()
        contract['boundary_tests']={'Q-001':[required[2]]}
        write_json('.harness/acceptance.json',contract)
        cli('preflight','loop','--preflight')
        trace=base/'worker-trace.jsonl'
        env['CODEX_LOOP_FAKE_TRACE']=str(trace)
        env['CODEX_LOOP_FAKE_MODE']='repair'
        python=project/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
        # Real tmux launcher is separately exercised by the Linux setup-and-tmux suite.
        argv=([sys.executable,'-B',str(project/'run_harness.py'),'loop'] if os.name=='nt' else
              [str(python),'-B',str(project/'automation/codex-loop/run.py'),'--config',str(conf_path)])
        invoke('loop-repair-review-completed',argv)
        calls=[json.loads(line) for line in trace.read_text(encoding='utf-8').splitlines()]
        assert {call['role'] for call in calls}=={'builder','reviewer'}
        for call in calls:
            assert answer in call['context']['boundary_context']
            assert call['context']['boundary_tests']==contract['boundary_tests']
            assert len(call['context']['review_criteria']['axes'])==5
            assert sum(len(axis['criteria']) for axis in call['context']['review_criteria']['axes'])==20
            assert 'prior_progress' in call['context']
        events_dir=project/'.harness/work/reporting/events'
        history={path.name:path.read_bytes() for path in events_dir.glob('*.json')}
        scored=[json.loads(value) for value in history.values()
                if isinstance(json.loads(value).get('data',{}).get('review'),dict)]
        assert len(scored)>=2, 'Failed and repaired reviews must both remain in history'
        assert any(item['status']=='REVIEW_FAILED' for item in scored)
        latest=max(scored,key=lambda item:item['sequence'])
        assert len(latest['data']['review']['rows'])==20
        assert next(row for row in latest['data']['review']['rows'] if row['criterion_id']=='HAND02')['status']=='UNVERIFIED'
        progress=(project/'docs/progress.md').read_text(encoding='utf-8')
        for marker in ('REPAIRING','REVIEW_FAILED','COMPLETED','Builder self-report'):
            assert marker in progress,marker
        results.append(dict(case='criteria-before-code-and-review-history-after-repair',passed=True))
        cli('verify','verify')
        cli('status','status')
        for name,value in history.items():
            assert (events_dir/name).read_bytes()==value, 'Historical event was rewritten'
        score=(project/'docs/review-score.md').read_text(encoding='utf-8')
        for axis in ('의도','인지','기술','정직성','소통'):
            assert axis in score
        assert '현재 코드와 일치' in score and 'PARTIAL' in score and 'UNVERIFIED' in score
        for name in ('progress.md','review-score.md'):
            (folder/('SIMULATED-'+name)).write_bytes((project/'docs'/name).read_bytes())
        results.append(dict(case='verify-keeps-current-score-and-immutable-prior-events',passed=True))
        score_bytes=(project/'docs/review-score.md').read_bytes()
        (project/'docs/review-score.md').write_text('Forged full score',encoding='utf-8')
        cli('manual-score-tampering','status',expected=1)
        (project/'docs/review-score.md').write_bytes(score_bytes)
        cli('restored-original-rendering','status')
        # The factual test receipt remains valid, while damaged review evidence becomes unscored.
        entry=latest['data']['review']['evidence']['file:docs/progress.md']
        raw=Path(entry['path'])
        if not raw.is_absolute():
            raw=project/raw
        raw.write_text('Deliberately changed archived evidence',encoding='utf-8')
        cli('damaged-review-evidence','status')
        assert '점수 미산정' in (project/'docs/review-score.md').read_text(encoding='utf-8')
        results.append(dict(case='damaged-review-evidence-invalidates-current-score-only',passed=True))
        write('RULES.md','Changed source rule invalidates prior analysis.\n')
        cli('stale-reference','clarify','--check-ready',expected=2)
        cli('stale-receipt','status',expected=1)
        assert (project/'AGENTS.md').read_text()=='Existing project instructions stay unchanged.\n'
    (args.evidence/(label+'-report-workflow.json')).write_text(json.dumps(dict(status='passed',live_model_calls=0,results=results),indent=2)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':
    main()
