#!/usr/bin/env python3
"""Prepare a Python 3.9 harness environment; never starts an implementation/review."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TEMPLATE = ROOT / "template"
WHEEL = "tomli-2.2.1-py3-none-any.whl"
WHEEL_SHA256 = "cb55c73c5f4408779d0cf3eef9f762b9c9f147a77de7b258bef0a5628adc85cc"
_spec = importlib.util.spec_from_file_location("setup_processes", TEMPLATE / ".harness/verification.py")
_processes = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_processes)


class SetupError(Exception):
    pass


def environment(python=None):
    env = dict(os.environ)
    for key in ("PYTHONHOME", "PYTHONPATH"):
        env.pop(key, None)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    if python:
        env["PATH"] = str(Path(python).parent) + os.pathsep + env.get("PATH", "")
    return env


def run(command, timeout=30, cwd=None):
    process = _processes.start_process(command, cwd=str(cwd or ROOT), env=environment(),
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        start_new_session=os.name != "nt",
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0)
    try:
        stdout, stderr = process.communicate(timeout=timeout)
        return subprocess.CompletedProcess(command, process.returncode,
            stdout.decode("utf-8", errors="replace"), stderr.decode("utf-8", errors="replace"))
    except (subprocess.TimeoutExpired, KeyboardInterrupt):
        _processes.stop_process(process)
        raise
    finally:
        _processes.finish_process(process)


def python_info(command):
    code = ("import importlib.util,json,sys;print(json.dumps({"
            "'executable':sys.executable,'version':list(sys.version_info[:3]),"
            "'prefix':sys.prefix,'tomli':importlib.util.find_spec('tomli') is not None}))")
    result = run(command + ["-I", "-B", "-c", code], timeout=15)
    if result.returncode:
        raise SetupError("Python could not start: " + command[0])
    try:
        info = json.loads(result.stdout)
        if info["version"][:2] != [3, 9]:
            raise SetupError("Python 3.9 is required; found " + ".".join(map(str, info["version"])))
        return info
    except (ValueError, KeyError, TypeError) as exc:
        raise SetupError("Invalid Python interpreter response") from exc


def find_python(explicit=None):
    if explicit:
        return Path(python_info([explicit])["executable"])
    candidates = [[str(venv_python(ROOT))], [sys.executable], ["python3.9"]]
    if os.name == "nt":
        candidates.insert(2, ["py", "-3.9"])
    candidates += [["python3"], ["python"]]
    for command in candidates:
        try:
            return Path(python_info(command)["executable"])
        except (SetupError, OSError, subprocess.SubprocessError):
            continue
    raise SetupError("Python 3.9 was not found. Install it first, then use --python39 PATH. See docs/SETUP.md.")


def venv_python(directory):
    return directory.resolve() / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def check_venv(directory):
    python = venv_python(directory)
    info = python_info([str(python)])
    if Path(info["prefix"]).resolve() != (directory / ".venv").resolve():
        raise SetupError("The selected interpreter does not belong to " + str(directory / ".venv"))
    return info


def prepare_venv(directory, python):
    directory = directory.resolve()
    wheel = ROOT / "vendor" / WHEEL
    if not wheel.is_file() or hashlib.sha256(wheel.read_bytes()).hexdigest() != WHEEL_SHA256:
        raise SetupError("Bundled tomli wheel is missing or damaged; extract the setup ZIP again.")
    folder = directory / ".venv"
    if folder.is_symlink() or folder.resolve() != folder.absolute():
        raise SetupError("Refusing a redirected/symlink .venv: " + str(folder))
    if folder.exists():
        if not venv_python(directory).is_file():
            raise SetupError("An incomplete or foreign-OS .venv exists; recreate it on this computer: " + str(folder))
        check_venv(directory)
    else:
        directory.mkdir(parents=True, exist_ok=True)
        result = run([str(python), "-I", "-B", "-m", "venv", str(folder)], timeout=180)
        if result.returncode:
            raise SetupError("venv creation failed. Python 3.9 needs venv/ensurepip support; see docs/SETUP.md.\n" + result.stderr[-1500:])
    selected = venv_python(directory)
    result = run([str(selected), "-I", "-m", "pip", "--isolated", "--disable-pip-version-check",
                  "install", "--no-index", "--no-deps", "--no-cache-dir", str(wheel)], timeout=120)
    if result.returncode:
        raise SetupError("Offline tomli installation failed:\n" + result.stderr[-1500:])
    if not check_venv(directory)["tomli"]:
        raise SetupError("tomli import is unavailable in the prepared environment")
    return selected


def codex_command():
    path = shutil.which("codex")
    if not path:
        raise SetupError("Codex CLI not found. Install it, open a new terminal, and run doctor again.")
    if os.name == "nt" and Path(path).suffix.lower() in (".cmd", ".bat"):
        entry = Path(path).parent / "node_modules/@openai/codex/bin/codex.js"
        node = shutil.which("node.exe")
        if not node or not entry.is_file():
            raise SetupError("Use native codex.exe or npm Codex with node.exe; unknown batch wrappers are not executed.")
        return [node, str(entry)]
    return [path]


def doctor(explicit=None, as_json=False):
    checks = []
    def record(name, ok, detail, required=True):
        checks.append(dict(name=name, ok=bool(ok), detail=detail, required=required))
    try:
        selected = find_python(explicit)
        info = python_info([str(selected)])
        record("python39", True, str(selected) + " (" + ".".join(map(str, info["version"])) + ")")
    except (SetupError, OSError, subprocess.SubprocessError) as exc:
        record("python39", False, str(exc))
    try:
        info = check_venv(ROOT)
        record("kit_venv", info["tomli"], str(venv_python(ROOT)))
    except (SetupError, OSError, subprocess.SubprocessError):
        record("kit_venv", False, "Run setup_env.py install to prepare this computer's local .venv.")
    try:
        git = run(["git", "--version"])
        record("git", git.returncode == 0, git.stdout.strip() or "Git unavailable")
    except (OSError, ValueError, subprocess.SubprocessError):
        record("git", False, "Install Git and reopen the terminal.")
    command = None
    try:
        command = codex_command()
        result = run(command + ["exec", "--help"], timeout=15)
        flags = ("--output-schema", "--output-last-message", "--json", "--model", "--sandbox", "--skip-git-repo-check")
        record("codex_cli", result.returncode == 0 and all(x in result.stdout for x in flags),
               "CLI command/required flags checked; no model invoked.")
    except (SetupError, OSError, ValueError, subprocess.SubprocessError) as exc:
        record("codex_cli", False, str(exc))
    if command:
        try:
            result = run(command + ["login", "status"], timeout=15)
            record("codex_login", result.returncode == 0,
                   "Logged in; model access not tested." if result.returncode == 0 else "Run codex login yourself, then doctor again.")
        except (OSError, ValueError, subprocess.SubprocessError):
            record("codex_login", False, "Login status check could not finish; run codex login status yourself.")
    else:
        record("codex_login", False, "Install the CLI, then run codex login yourself.")
    linux = sys.platform.startswith("linux")
    tmux = shutil.which("tmux") if linux else None
    if linux:
        detail = ("Linux loops automatically run in tmux." if tmux else
                  "Linux loops require tmux. Install it using your Linux package manager, "
                  "then run doctor again; see docs/SETUP.md.")
    else:
        detail = "Not used on this platform; loops run in the current terminal."
    record("tmux", bool(tmux), detail, required=linux)
    ready = all(x["ok"] for x in checks if x["required"])
    report = dict(platform=sys.platform, python_requirement="3.9.x", ready=ready,
                  model_calls=0, checks=checks)
    if as_json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("Platform: " + sys.platform + " | Required runtime: Python 3.9.x")
        for check in checks:
            label = "OK" if check["ok"] else "MISSING" if check["required"] else "OPTIONAL"
            print("[{}] {}: {}".format(label, check["name"], check["detail"]))
        print("Setup check complete. No Sol/Terra work has started.")
    return 0 if ready else 1


def inside(path, parent):
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def payload_files():
    for source in sorted(TEMPLATE.rglob("*")):
        relative = source.relative_to(TEMPLATE)
        if not source.is_file() or any(p in ("tests", "__pycache__", ".venv", "work") for p in relative.parts):
            continue
        if source.name == "demo.py" or source.name.endswith(".example.json"):
            continue
        yield source, relative


def git_root(project):
    existing = project
    while not existing.exists():
        existing = existing.parent
    result = run(["git", "-C", str(existing), "rev-parse", "--show-toplevel"])
    if result.returncode == 0:
        top = Path(result.stdout.strip()).resolve()
        if top != project:
            raise SetupError("Use the Git repository root as --project: " + str(top))
        return top
    return None


def attach(project_name, spec_name, explicit=None):
    project = Path(project_name).expanduser().resolve()
    if inside(project, ROOT.resolve()) or inside(ROOT.resolve(), project):
        raise SetupError("The setup-kit folder and project folder must be separate, with neither inside the other.")
    if project.exists() and not project.is_dir():
        raise SetupError("--project must be a directory")
    spec = Path(spec_name)
    if spec.is_absolute() or ".." in spec.parts or not spec.parts or not inside((project / spec).resolve(), project):
        raise SetupError("--spec must be a file path relative to the target project")
    selected = find_python(explicit or (str(venv_python(ROOT)) if venv_python(ROOT).is_file() else None))
    repository = git_root(project)
    payload = list(payload_files())
    for source, relative in payload:
        target = project / relative
        for parent in target.parents:
            if parent == project:
                break
            if parent.is_symlink() or parent.resolve() != parent.absolute():
                raise SetupError("Refusing a redirected installation directory: " + str(parent))
            if parent.exists() and not parent.is_dir():
                raise SetupError("A file blocks an installation directory: " + str(parent))
        if not inside(target.resolve(), project) or target.is_symlink():
            raise SetupError("Refusing an outside/symlink destination: " + str(target))
        if target.exists() and (not target.is_file() or source.read_bytes() != target.read_bytes()):
            raise SetupError("Existing file differs; nothing has been overwritten: " + str(target))
    # Check all conflicts before creating the project environment or copying files.
    for relative in (".harness/checks.json", ".harness/acceptance.json", "automation/codex-loop/config.json", "automation/codex-loop/tasks.json", ".gitignore"):
        target = project / relative
        if target.is_symlink() or not inside(target.resolve(), project) or (target.exists() and not target.is_file()):
            raise SetupError("Unsafe configuration destination: " + str(target))
    # Validate report ownership before creating an environment or copying any files.
    _processes.reports.precheck(project)
    ignore = project / ".gitignore"
    content = ignore.read_text(encoding="utf-8") if ignore.exists() else ""
    prepare_venv(project, selected)
    if repository is None:
        result = run(["git", "init", str(project)])
        if result.returncode:
            raise SetupError("git init failed: " + result.stderr[-1500:])
    for source, relative in payload:
        target = project / relative
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(source), str(target))
    identifier = project.name + "-" + hashlib.sha256(str(project).encode("utf-8")).hexdigest()[:8]
    generated = {
        ".harness/checks.json": {"checks": []},
        ".harness/acceptance.json": {"version": 1, "checker_argv": [], "required_ids_manifest": "", "protected_paths": [], "boundary_tests": {}},
        "automation/codex-loop/tasks.json": [],
        "automation/codex-loop/config.json": {
            "project": "../..", "spec": spec.as_posix(), "tasks_file": "tasks.json",
            "builder_model": "SET_ACTUAL_SOL_MODEL_ID", "reviewer_model": "SET_ACTUAL_TERRA_MODEL_ID",
            "review_not_applicable": {},
            "codex_command": ["codex"], "max_repairs": 3,
            "stage_timeout_seconds": 900, "total_timeout_seconds": 7200,
            "run_root": "../../../.codex-loop-runs/" + identifier,
            "protected_paths": ["run_harness.py", "requirements-harness.txt", ".harness/harness.py",
                ".harness/acceptance.py", ".harness/check_unittest.py", ".harness/acceptance.json",
                ".harness/boundary.py", ".harness/clarify.py", ".harness/clarify.schema.json",
                ".harness/clarify_prompt.md", "BOUNDARY_QUESTION_TEMPLATE.md",
                ".harness/reports.py", ".harness/review_criteria.json",
                ".harness/verification.py", ".harness/checks.json", ".harness/review_instructions.md",
                ".harness/review.schema.json", ".codex/agents/kty-reviewer.toml"],
            "exclude_dirs": [".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache", ".ruff_cache", ".mypy_cache", ".harness/work"]}}
    for name, value in generated.items():
        path = project / name
        if not path.exists():
            path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    entries = ["/.venv/", "/.harness/work/", "__pycache__/", ".pytest_cache/"]
    missing = [entry for entry in entries if entry not in content.splitlines()]
    if missing:
        with ignore.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(("\n" if content and not content.endswith("\n") else "") + "\n".join(missing) + "\n")
    _processes.reports.initialize(project)
    print("Project harness prepared: " + str(project))
    print("Next: supply " + spec.as_posix() + " and run run_harness.py clarify with the actual analysis model ID. Record answers and reanalyze until ready.")
    print("Then map every answered question in acceptance.json boundary_tests to required test IDs, configure checks/tasks and actual model IDs. See docs/CROSS_PLATFORM.md.")
    print("Automatic records: docs/progress.md and docs/review-score.md (initially not started / not reviewed).")
    print("No application code was generated and no model was invoked.")
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command")
    for name in ("install", "doctor", "attach"):
        child = commands.add_parser(name)
        child.add_argument("--python39", help="Path to an installed Python 3.9 executable")
        if name == "doctor":
            child.add_argument("--json", action="store_true")
        if name == "attach":
            child.add_argument("--project", required=True)
            child.add_argument("--spec", default="FUNCTIONAL_SPEC.md")
    args = parser.parse_args(argv)
    try:
        if args.command == "install":
            selected = prepare_venv(ROOT, find_python(args.python39))
            print("Python 3.9 environment installed locally: " + str(selected))
            return doctor(str(selected))
        if args.command == "doctor":
            return doctor(args.python39, args.json)
        if args.command == "attach":
            return attach(args.project, args.spec, args.python39)
        parser.print_help()
        print("Order: install -> doctor -> attach -> clarify and answers -> acceptance/checks/tasks -> explicit run_harness.py loop")
        return 0
    except (SetupError, OSError, ValueError, subprocess.SubprocessError) as exc:
        print("SETUP STOPPED: " + str(exc), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
