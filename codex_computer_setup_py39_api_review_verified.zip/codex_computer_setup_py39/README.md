# Windows / Linux Python 3.9 하네스 준비 키트

컴퓨터에 공통 작업 환경을 준비하고, 나중에 원하는 프로젝트에 하네스와 Sol/Terra 반복 작업기를 연결하는 키트입니다. 설치와 프로젝트 연결만으로 모델 작업이 시작되지는 않습니다.

진행 순서는 **환경 준비 → 프로젝트·명세 준비 → 경계 질문과 실제 답변 → 재분석 → 필수 테스트 연결 → 작업 → 최종 검증**입니다.

프로젝트를 연결하면 `docs/progress.md`와 `docs/review-score.md`가 생성됩니다. 작업과 검증을 실행하면 진행 기록과 독립 리뷰 점수가 자동으로 갱신됩니다. 구현자와 리뷰어는 같은 판정 기준을 전달받습니다.

HTTP API 결과물을 추가 검수할 프로젝트에서는 [선택형 API 검수 안내](docs/OPTIONAL_API_REVIEW.md)에 따라 Schemathesis 4.4.4와 Hurl 8.1.0을 별도 설치해 최종 `verify`에 연결할 수 있습니다. 기본 설치와 개발 loop에는 필요하지 않습니다. 실행 결과는 진행 기록 및 이후 리뷰의 근거로 연결하며 점수를 자동 가산하지 않습니다.

## 1. 이 컴퓨터의 환경 준비

ZIP을 작업할 프로젝트와 별개의 폴더에 풉니다. 아래 명령은 ZIP을 푼 폴더에서 실행합니다. Python 3.9.x와 Git은 미리 설치되어 있어야 합니다. Codex CLI와 로그인은 모델 작업 전에 준비합니다. Linux / Codespaces에서는 실제 `loop` 작업 전에 tmux도 설치해야 합니다. 설치 방법은 `docs/SETUP.md`를 참고하세요.

Windows PowerShell:

```powershell
py -3.9 setup_env.py install
py -3.9 setup_env.py doctor
```

Linux / Codespaces:

```bash
python3.9 setup_env.py install
python3.9 setup_env.py doctor
```

`install`은 키트의 `.venv`에 Python 3.9 환경과 동봉한 `tomli` 패키지를 오프라인으로 준비한 뒤 진단합니다. **Python 자체, Git, Codex CLI, tmux를 자동 설치하는 명령은 아닙니다.** `doctor`는 실제 운영체제, Python, Git, Codex CLI와 로그인 상태를 확인하며 모델을 호출하지 않습니다. `install`, `doctor`, `attach`는 tmux 세션을 시작하지 않습니다. Linux 진단에서는 tmux가 없으면 준비 미완료로 표시합니다.

Git, Codex CLI 또는 로그인이 준비되지 않으면 설치 마지막 진단이 종료 코드 1을 반환합니다. 이미 생성한 가상환경은 유지됩니다. 안내된 도구를 준비한 뒤 `doctor`를 다시 실행하세요.

Python 3.9 실행 파일을 직접 지정해야 한다면 `install --python39 "실행파일의 전체 경로"`를 사용합니다. 선택한 파일도 실제로 3.9.x인지 확인합니다.

## 2. 실제 프로젝트 연결

나중에 작업할 프로젝트가 정해지면 키트 폴더에서 실행합니다. 경로는 자신의 프로젝트로 바꾸세요.

Windows:

```powershell
py -3.9 setup_env.py attach --project "D:\projects\my-project"
```

Linux / Codespaces:

```bash
python3.9 setup_env.py attach --project /workspaces/my-project
```

`attach`는 대상에 공통 하네스, 반복 작업기, 설정 파일과 `.venv`를 준비합니다. 대상 폴더가 없으면 만들고, Git 저장소가 아니면 로컬 저장소를 초기화합니다. 기존 저장소에서는 최상위 폴더를 지정해야 합니다. Git은 필요하지만 이 단계에 Codex 로그인은 필요하지 않습니다.

키트와 대상 프로젝트는 서로 겹치지 않는 별개 폴더여야 합니다. 같은 경로에 내용이 다른 관리 파일이 있으면 덮어쓰지 않고 중단합니다. 프로젝트의 앱 코드·데이터·실행 결과는 이 키트에 포함하지 않습니다.

앱 명세의 이름이 다르면 `--spec "docs/MY_SPEC.md"`를 추가합니다. 이 경로는 대상 프로젝트 기준입니다. 첨부했던 워크플로 기술 명세는 `automation/codex-loop/WORKFLOW_SPEC.md`에 보존되며 앱 명세와 역할이 다릅니다.

## 3. 명세의 모호한 조건부터 확인

대상 프로젝트에 실제 앱 명세를 준비하고 `automation/codex-loop/config.json`의 `spec`가 그 파일을 가리키게 합니다. 기본값은 `FUNCTIONAL_SPEC.md`이며 `attach --spec`으로 바꿀 수 있습니다. `builder_model`에는 계정에서 사용할 수 있는 정확한 Sol 모델 ID를 설정합니다.

아래 명령은 대상 프로젝트에서 실행합니다. Windows는 `python3.9` 대신 `py -3.9`를 사용하세요.

```text
python3.9 run_harness.py clarify
```

이 명령은 **실제 모델을 호출**해 선택한 명세와 공통 `BOUNDARY_QUESTION_TEMPLATE.md`를 읽고, 결정되지 않은 조건을 한 번에 1~3개 질문합니다. 명확한 명세라면 질문 없이 준비 상태가 될 수 있습니다. 질문의 답을 모델이 대신 만들지는 않습니다. 기존 `AGENTS.md`는 별도로 유지됩니다.

담당자의 실제 답변을 UTF-8 텍스트 파일에 저장한 뒤 출력된 질문 ID로 기록합니다. 다음은 실제로 `Q-001`이 나온 경우의 명령입니다.

```text
python3.9 run_harness.py clarify --answer Q-001 --answer-file answer.txt
python3.9 run_harness.py clarify
python3.9 run_harness.py clarify --check-ready
```

여러 질문이면 각각 답변을 기록한 뒤 재분석합니다. 답변이 여전히 모호하면 추가 질문이 나옵니다. 모든 질문에 실제 답변이 있고 재분석에서 미해결 조건이 없어야 준비가 완료됩니다. `--answer`, `--status`, `--check-ready`는 모델을 호출하지 않습니다. 질문을 기다리는 상태에서 `clarify`나 `--status`가 종료 코드 2를 반환하는 것은 아직 작업을 시작할 수 없다는 뜻입니다.

질문과 실제 답변은 `.harness/boundary.json`에 저장되고 `BOUNDARY_ANSWERS.md`로 표시됩니다. 이 파일을 직접 편집해 준비 상태를 만들지 마세요. 명세·질문 템플릿·참조 문서나 실제 답변이 바뀌면 재분석이 필요합니다. `clarify --spec`을 사용할 때도 이후 loop가 읽는 `config.json`의 `spec`와 같은 경로를 선택해야 합니다.

## 4. 답변을 필수 테스트에 연결한 다음 시작

대상 프로젝트에서 다음 항목을 준비합니다.

1. 선택한 앱 명세와 준비가 완료된 경계 질문·실제 답변.
2. `.harness/acceptance.json`: 공통 검사기, 고정 필수 테스트 ID 목록, 보호할 인수테스트·정답 자료, `boundary_tests` 질문별 필수 테스트 매핑.
3. `.harness/checks.json`: 최종 검증에 실행할 실제 검사. 공통 검사기와 같은 명령을 등록.
4. `automation/codex-loop/tasks.json`: 작업별 요구사항과 확인할 검사.
5. `automation/codex-loop/config.json`: 계정에서 사용할 수 있는 정확한 Sol/Terra 모델 ID.

처음 생성된 검사·작업·공통 검사 계약은 비어 있습니다. 모델 이름도 자리표시자이므로 실제 작업을 설정하기 전에는 실행할 수 없습니다. 구체적인 형식은 `docs/CROSS_PLATFORM.md`를 참고하세요. 이 문서는 연결한 프로젝트에도 복사됩니다.

`boundary_tests`는 실제 답변이 있는 모든 질문 ID를 하나 이상의 고정 필수 테스트 ID에 연결합니다. 질문이 없으면 빈 객체 또는 생략이 가능합니다. 실제 답변의 내용은 Sol 구현과 Terra 리뷰에 함께 전달됩니다.

loop의 최종 완료와 verify는 같은 검사기의 실제 테스트 ID별 결과를 확인합니다. 미해결 질문, 답변과 테스트의 연결 누락, 테스트 0개, 필수 검사 누락·skip, 개수만 맞춘 대체 검사는 통과하지 않습니다. 일반 unittest용 검사기를 제공하며, 업무별 측정·평가 로직은 프로젝트에서 정의합니다. 검사기는 stdout JSON과 stderr 로그를 출력하고 실행기가 기록을 저장합니다. 명세·질문/답변·고정 검사·정답·검사기는 보호하며 앱 구현과 별도 개발 테스트는 수정할 수 있습니다.

설정한 뒤 **대상 프로젝트 폴더**에서 Windows는 `py -3.9`, Linux는 `python3.9`로 실행합니다.

```text
python3.9 run_harness.py loop --preflight
python3.9 run_harness.py loop
```

`--preflight`는 준비 상태를 점검하며 실제 검사·모델 호출·tmux 실행을 하지 않습니다. 그다음 같은 `loop` 명령을 실행하면 운영체제를 자동 판단합니다.

| 실행 환경 | 실제 `loop` 실행 방식 |
|---|---|
| Windows | 현재 터미널에서 실행 |
| Linux / Codespaces | tmux 세션에서 실행. 이미 tmux 안이면 현재 패널을 사용 |

Linux에 tmux가 없으면 설치 안내와 함께 중단합니다. 별도의 OS 선택 명령이나 채팅 힌트는 필요하지 않습니다. `clarify`와 `loop --help`, `loop --preflight`, `loop --probe-models`는 tmux를 사용하지 않습니다. 단, `clarify` 분석과 `--probe-models`는 실제 모델을 호출합니다. 실제 loop는 경계 질문의 준비 상태를 확인한 뒤 tmux를 시작합니다.

`loop`가 시작되면 Sol 구현 → 검사 → Terra 리뷰 → 필요 시 제한 횟수 수정이 진행됩니다. 새 tmux 세션은 결과를 보여준 뒤 Enter를 누를 때까지 유지됩니다. 작업 중 화면만 분리하려면 `Ctrl+B`를 누른 뒤 `D`를 누릅니다. 대화형 터미널이 없는 실행에서는 세션 이름과 재접속 명령을 출력합니다. **세션 시작 성공은 작업 완료를 뜻하지 않습니다.** 재접속하거나 출력된 기록 경로의 상태와 로그로 완료 결과를 확인하세요.

작업 완료를 확인한 뒤 최종 검증을 실행합니다.

```text
python3.9 run_harness.py verify
python3.9 run_harness.py status
```

## 자동 진행 기록과 리뷰 점수

두 파일은 키트를 연결한 **대상 프로젝트**의 `docs/`에 있습니다. 별도로 진행 프롬프트를 붙이거나 MD를 읽으라고 요청하지 않아도 됩니다.

| 파일 | 내용 |
|---|---|
| `docs/progress.md` | 현재 상태, 구현·수정 메모, 실제 검사 결과와 로그, 실패·미확인 사항, 다음 작업과 인계 |
| `docs/review-score.md` | 리뷰 대상과 코드 상태, 의도·인지·기술·정직성·소통의 축별 점수, 항목별 판정·근거, 과거 회차 |

처음에는 미착수·리뷰 미산정 상태입니다. 과거 작업이나 담당자 수용을 만들어 기록하지 않습니다. 기존 동명 파일이 하네스 관리 파일이 아니면 덮어쓰지 않고 연결을 중단합니다. 기존 파일을 별도로 보관한 뒤 연결하세요.

진행 문서의 구현자 메모는 설명이며 검증 증거와 구분합니다. 명령·종료 코드·실제 결과는 실행 로그에 연결합니다. 작업 시작과 구현·검사·리뷰·수정·중단·완료 시점에 기록하며, 실패 이력을 성공으로 바꾸어 덮어쓰지 않습니다. 기존 `HANDOFF.md`가 있으면 상세 내용을 중복 작성하지 않고 참조합니다.

공통 기준은 `.harness/review_criteria.json`에 있습니다. 목표·실제 경계 답변·요구사항 추적 외에 잘못된 순서와 오류 주입, 통과/실패/스킵/미실행, 업로드·폴링·폴백, timeout의 결과 반환/작업 중단/프로그램 종료, 비밀정보·누수·개인 경로, 측정 조건·원시 결과·지표 구분, 실패 기록, 새 세션의 인계 문서 이해, 다른 환경의 README 실행을 확인합니다.

점수는 충족 2·부분충족 1·미충족 또는 미확인 0으로 항목별 판정에서 계산하고, 각 축을 100점으로 환산합니다. 실제 검사나 새 세션 확인을 하지 않았다면 확인했다고 쓰지 않습니다. 코드의 설명이 맞는지 평가하며 사람의 이해도나 담당자 수용을 AI가 대신 확정하지 않습니다. 점수는 내부 참고 평가로, 기존 필수 검사 실패나 요구사항 리뷰의 `UNVERIFIED`를 덮지 못합니다.

검사나 리뷰 중에는 모델이 이 두 문서를 직접 수정하지 않습니다. 실행기가 검증한 기록을 바탕으로 생성합니다. 문서를 수동으로 고쳐 점수나 통과 상태를 바꾸지 마세요. 코드·명세·기준이 바뀌면 다음 작업·검증·상태 확인 때 이전 리뷰의 유효성을 다시 확인합니다. 백그라운드 파일 감시 기능은 없으며 하네스 밖에서 한 수정의 판단 이유를 자동으로 추측하지 않습니다.

관련 설정과 증거·해당 없음 처리 규칙은 `docs/CROSS_PLATFORM.md`를 참고하세요.

Windows와 Linux를 바꿀 때 가상환경은 각 컴퓨터에서 다시 만듭니다. Windows에는 tmux가 필요하지 않으며, Linux / Codespaces의 실제 작업 실행에는 tmux가 필요합니다.

실제 계정의 모델 접근 권한과 실모델 작업 성공 여부는 설치/진단만으로 확인되지 않습니다. Codespaces 안내는 Linux 실행 방식에 따른 것이며 실제 Codespaces에서의 실행 검증을 뜻하지 않습니다. 이 배포본의 검증 범위는 `VALIDATION.txt`를 확인하세요.
